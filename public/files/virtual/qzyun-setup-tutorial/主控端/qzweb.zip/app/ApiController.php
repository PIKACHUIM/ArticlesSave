<?php
declare (strict_types = 1);

namespace app;

/**
 * 控制器基础类
 */
class ApiController extends  BaseController
{
    protected function initialize(){
        $input=file_get_contents("php://input");
        $header = $this->request->header();
        if(isset($header['content-type'])){
            if(stristr($header['content-type'],"json")!==false){
                $data = json_decode($input,true);
                $this->request->input($data);
            }
        }
    }
}