<?php
declare (strict_types = 1);

namespace app\admin\controller;

class Base extends \app\BaseController
{
}
