<?php
declare (strict_types = 1);

namespace app\admin\controller;

use app\common\model\NewVersion;
use think\facade\Request;

class Config extends Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];
    public $new_ver_url ='http://www.qzsystem.com/home/version/now_version?ver=v2';
    // 系统配置
    public function index(){
        if(Request::isPost()){
           set_web(Request::post('','','strip_tags'));
           return  $this->success('保存成功',Request::root().'/config/index');
        }

        //当前版本
        $new_version = new NewVersion();
        $now_ver = $new_version->where('id=1')->find();

        //最新版本
        $new_version = file_get_contents($this->new_ver_url);
        $new_version =  \GuzzleHttp\json_decode($new_version,true);
        return $this->fetch('',[
            'data' => config('web'),
            'now_ver'=>$now_ver,
            'new_version'=>$new_version,
        ]);
    }
}
