<?php

declare (strict_types = 1);
namespace app\admin\controller;

use app\common\model\NewVersion;
use think\Db;
use think\Exception;

/**
 * 升级
 *
 * @icon fa fa-dashboard
 * @remark 用于展示当前系统中的统计数据、统计报表及重要实时数据
 */
class Update extends Base
{
    public $check_ver_url ='http://www.qzsystem.com/home/version?ver=';

    /**
     * 查看
     */
    public function index(){
        //new_version
      echo 'ok';
    }
    public function update()
    {
        if (!class_exists('ZipArchive')) {
            $this->error("服务器缺少php-zip组件，无法进行还原操作");
        }

        $rootPath =  $this->app->getRootPath();
        //当前版本
        $new_version = new NewVersion();
        $now_ver = $new_version->where('id=1')->find();
        //最新版本
        //获取版本列表
        $version_list = file_get_contents($this->check_ver_url.$now_ver['version']);
        $version_list =  \GuzzleHttp\json_decode($version_list,true);
        $zipDir = $rootPath . 'update'.DS.'zip';
        $dir =  $rootPath . 'update'.DS.'unzip';

        foreach ($version_list as  $k=>$v){
            $url = pathinfo($v['downloadurl']);
            $file_name =$url['basename'];
            $fp_input = fopen($v['downloadurl'], 'r');
            file_put_contents($zipDir.DS.$file_name, $fp_input);
            $ver =$v['ver'];
            $file =$zipDir.DS.$file_name;
            try {
                if (!is_dir($dir)) {
                    mkdir($dir, 0755);
                }
                $zip = new \ZipArchive();
                if ($zip->open($file) !== true) {
                    throw new Exception(__('Can not open zip file'));
                }
                if (!$zip->extractTo($dir)) {
                    $zip->close();
                    throw new Exception(__('Can not unzip file'));
                }
                $zip->close();
                recurse_copy($dir.DS.$ver.DS.'code',$rootPath);
                $sqlFile = $dir.DS.$ver.DS.'sql'.DS.'update.sql';
                if (is_file($sqlFile)) {
                    $filesize = filesize($sqlFile);
                    $list = \think\facade\Db::query('SELECT @@global.max_allowed_packet');
                    if (isset($list[0]['@@global.max_allowed_packet']) && $filesize >= $list[0]['@@global.max_allowed_packet']) {
                        Db::execute('SET @@global.max_allowed_packet = ' . ($filesize + 1024));
                        //throw new Exception('备份文件超过配置max_allowed_packet大小，请修改Mysql服务器配置');
                    }
                    $sql = file_get_contents($sqlFile);

                    //必须重连一次
                    \think\facade\Db::connect(null, true)->query("select 1");
                    \think\facade\Db::getPdo()->exec($sql);
                }
                $now_ver->where(['id'=>$now_ver['id']])->update(['version'=>$ver,'update_time'=>date('Y-m-d H:i:s')]); //更新版本库
            } catch (Exception $e) {
                echo $e->getMessage();
                // $this->error($e->getMessage());
            } catch (PDOException $e) {
                echo $e->getMessage();
            }
        }
        $this->success('更新成功');

    }

}
