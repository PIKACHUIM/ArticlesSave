<?php
declare (strict_types = 1);

namespace app\admin\controller\baremetal;

use app\common\model\BaremetalCabinet;
use app\common\model\BaremetalIpGroup;
use app\common\model\BaremetalNode;
use app\common\model\BaremetalSeat;
use app\common\model\ServersArea;
use think\facade\Request;
use app\common\service\BaremetalBusiness as S;
use app\common\model\BaremetalBusiness as M;

class Business extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    public function initialize()
    {
        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();

        $baremetalIpGroupModel = new BaremetalIpGroup();
        $ip_group = $baremetalIpGroupModel->select();
        $this->assign('area_list',$area_list);
        $this->assign('ip_group_list',$ip_group);
    }

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch();
    }

    // 状态
    public function status($id){
        return $this->getJson(S::goStatus(Request::post('status'),$id));
        }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
    }
}