<?php
declare (strict_types = 1);

namespace app\admin\controller\baremetal;

use app\common\model\ServersArea;
use app\common\validate\BaremetalCabinet as V;
use think\facade\Request;
use app\common\service\BaremetalCabinet as S;
use app\common\model\BaremetalCabinet as M;

class Cabinet extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();
        return $this->fetch('',['area_list' => $area_list]);
    }

    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();
        return $this->fetch('', ['area_list' => $area_list]);
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }

        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();
        return $this->fetch('',['model' => M::find($id),'area_list' => $area_list]);
    }


    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
    }

}
