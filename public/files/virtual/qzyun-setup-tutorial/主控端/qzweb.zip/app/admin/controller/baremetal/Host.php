<?php
declare (strict_types = 1);

namespace app\admin\controller\baremetal;

use app\common\model\BaremetalCabinet;
use app\common\model\BaremetalIpGroup;
use app\common\model\BaremetalNode;
use app\common\model\BaremetalSeat;
use app\common\model\ServersArea;
use app\common\service\BaremetalSwitch;
use app\common\util\QzcloudTool;
use think\facade\Request;
use app\common\service\BaremetalHost as S;
use app\common\model\BaremetalHost as M;

class Host extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    public function initialize()
    {
        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();

        $baremetalIpGroupModel = new BaremetalIpGroup();
        $ip_group = $baremetalIpGroupModel->select();
        $this->assign('area_list',$area_list);
        $this->assign('ip_group_list',$ip_group);
        $this->assign('funs',S::$fun);
    }

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch();
    }

    public function ajax_cabinet($area_id){
        $cabinetModel = new BaremetalCabinet();
        $list = $cabinetModel->where(['area_id'=>$area_id])->select();
        return $this->getJson(['data'=>empty($list)?[]:$list->toArray()]);
    }

    public function ajax_seat($cabinet_id,$value=0){
        $seatModel = new BaremetalSeat();
        $node = [];
        if($value==0){
            $list = $seatModel->where(['cabinet_id'=>$cabinet_id,'isused'=>0])->select();
        }else{
            $list = $seatModel->where(['cabinet_id'=>$cabinet_id])->where(function ($query)use($value){
                //'isused'=>0
                $query->whereOr(['isused'=>0,'id'=>$value]);
            })->select();
        }

        foreach ($list as $k=>&$v){
            if($v['node']!=1){
                $node[] = $v['number'];
                $v['number']= $v['number'].'-'.$v['node'];
            }
        }
        unset($v);
        foreach ($list as $k=>&$v){
            if(in_array($v['number'],$node)){
                $v['number']= $v['number'].'-'.$v['node'];
            }
        }
        unset($v);
        return $this->getJson(['data'=>empty($list)?[]:$list->toArray()]);
    }

    public function ajax_node($area_id){
        $cabinetModel = new BaremetalNode();
        $list = $cabinetModel->where(['area_id'=>$area_id,'state'=>1])->select();
        return $this->getJson(['data'=>empty($list)?[]:$list->toArray()]);
    }
    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        return $this->fetch();
    }

    public function getMacList(){
        if (Request::isAjax()) {
            return $this->getJson(S::getMacList(Request::post()));
        }
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }
        $info =  M::find($id);
        $cabinetModel = new BaremetalCabinet();
        $cabinetlist = $cabinetModel->where(['area_id'=>$info['area_id']])->select(); //关联机柜
        $seatModel = new BaremetalSeat();
        $seatList = $seatModel->where(['cabinet_id'=>$info['cabinet_id']])->where(function ($query)use($info){
            //'isused'=>0
            $query->whereOr(['isused'=>0,'id'=>$info['seat_id']]);
        })->select();
        $node = [];
        foreach ($seatList as $k=>&$v){
            if($v['node']!=1){
                $node[] = $v['number'];
                $v['number']= $v['number'].'-'.$v['node'];
            }
        }
        unset($v);
        foreach ($seatList as $k=>&$v){
            if(in_array($v['number'],$node)){
                $v['number']= $v['number'].'-'.$v['node'];
            }
        }
        $ip_group_list = explode(',',$info['ip_group_id']);
        $funs_list = explode(',',$info['funs']);
        //控制器
        $nodelist = (new BaremetalNode())->where(['area_id'=>$info['area_id']])->select(); //关联控制器

        //交换机
        $switchList = BaremetalSwitch::switchList($info['cabinet_id']);
        $switchPort = BaremetalSwitch::switchPort($info['switch_id'],$info['switch_port']);
        //交换机端口
        unset($v);
        return $this->fetch('',[
            'model' =>$info,
            'cabinetlist'=>$cabinetlist,
            'seatList'=>$seatList,
            'nodelist'=>$nodelist,
            'ip_group_list_id'=>$ip_group_list,
            'funs_list'=>$funs_list,
            'switchList'=>$switchList['data'],
            'switchPort'=>$switchPort['data'],
        ]);
    }

    // 状态
    public function status($id){
        return $this->getJson(S::goStatus(Request::post('status'),$id));
        }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
    }

    // 批量删除
    public function batchRemove(){
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
    }

    public function ip($id=0){
        if (Request::isAjax()) {
            return $this->getJson(S::goIPList($id));
        }
        $groupIpModel = new \app\common\model\BaremetalIpGroup();
        if ($id>0){
            $host =  M::find($id);
            $gid = explode(',',$host['ip_group_id']);
            $ipgroupList = $groupIpModel->whereIn('id',$gid)->select();
        }else{
            $ipgroupList = $groupIpModel->select();
        }

        return $this->fetch('',['hostid'=>$id,'ipgroupList'=>$ipgroupList]);
    }

    public function business($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goAllotBusiness(Request::post()));
        }
        $host =  M::find($id);
        $open_time = date('Y-m-d H:i:s');
        $end_time = date('Y-m-d H:i:s',strtotime('+1 month',strtotime($open_time)));
        $user = QzcloudTool::getUniqueStr("baremetal",10,"");
        $passwd = QzcloudTool::generatePassword(10);
        return $this->fetch('',['host'=>$host,'open_time'=>$open_time,'end_time'=>$end_time,'user'=>"Server".$user,'passwd'=>$passwd]);
    }

    public function switchList($cabinet_id){
        if (Request::isAjax()) {
            return $this->getJson(BaremetalSwitch::switchList($cabinet_id));
        }
    }

    public function switchPort($switch_id){
        if (Request::isAjax()) {
            return $this->getJson(BaremetalSwitch::switchPort($switch_id));
        }
    }

    public function cancelAuto(){
        if (Request::isAjax()) {
            return $this->getJson(S::cancelAuto(Request::post()));
        }
    }

    public function settingIp($id){
        if (Request::isAjax()) {
            return $this->getJson(S::settingIp($id));
        }
    }

    public function upShelves($id){
        if (Request::isAjax()) {
            return $this->getJson(S::upShelves($id));
        }
    }
    public function downShelves($id){
        if (Request::isAjax()) {
            return $this->getJson(S::downShelves($id));
        }
    }
    public function closeNetwork($id){
        if (Request::isAjax()) {
            return $this->getJson(S::closeNetwork($id));
        }
    }
    public function openNetwork($id){
        if (Request::isAjax()) {
            return $this->getJson(S::openNetwork($id));
        }
    }

    public function upBandwidth($id){
        if (Request::isAjax()) {
            return $this->getJson(S::upBandwidth(Request::param()));
        }
        $model =  M::find($id);
        return $this->fetch('',['model'=>$model]);
    }

}