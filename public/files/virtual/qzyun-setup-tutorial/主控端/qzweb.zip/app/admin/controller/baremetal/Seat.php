<?php
declare (strict_types = 1);

namespace app\admin\controller\baremetal;

use app\common\model\BaremetalCabinet;
use app\common\model\ServersArea;
use think\facade\Request;
use app\common\service\BaremetalSeat as S;
use app\common\model\BaremetalSeat as M;

class Seat extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    public function initialize()
    {
        $cabinetModel = new BaremetalCabinet();
        $all_cabinet_list = $cabinetModel->select();
        $cabinet_list = [];
        foreach ($all_cabinet_list as $k=>$v){
            if($v['state'] ==1){
                $cabinet_list[$k] = $v;
            }
        }
        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();
        $this->assign('area_list',$area_list);
        $this->assign('cabinet_list' ,$cabinet_list);
        $this->assign('all_cabinet_list',$cabinet_list);
    }

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch();
    }

    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        return $this->fetch();
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }
        return $this->fetch('',['model' => M::getInfoById($id)]);
    }

    // 状态
    public function status($id){
        return $this->getJson(S::goStatus(Request::post('status'),$id));
        }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
    }

}
