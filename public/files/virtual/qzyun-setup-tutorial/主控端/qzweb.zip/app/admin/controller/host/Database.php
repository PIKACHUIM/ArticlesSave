<?php
declare (strict_types = 1);

namespace app\admin\controller\host;

use app\common\model\VirhostNode;
use app\common\util\QzcloudTool;
use think\facade\Request;
use app\common\service\HostDatabase as S;
use app\common\model\VirhostDatabase as M;

class Database extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch();
    }

    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        $nodeModel = new VirhostNode();
        $nodeList = $nodeModel->select();
        $endtime =  QzcloudTool::getDateMonth(date("Y-m-d"),1);
        return $this->fetch('',['nodeList'=>$nodeList,'endtime'=>$endtime]);
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }
        return $this->fetch('',['model' => M::find($id)]);
    }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
        }

}
