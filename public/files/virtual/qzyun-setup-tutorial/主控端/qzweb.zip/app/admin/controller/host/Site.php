<?php
declare (strict_types = 1);

namespace app\admin\controller\host;

use app\common\model\VirhostDatabase;
use app\common\model\VirhostNode;
use app\common\model\VirhostPhpver;
use app\common\util\QzcloudTool;
use think\facade\Request;
use app\common\service\HostSite as S;
use app\common\model\HostSite as M;

class Site extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch();
    }

    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        //php版本
        $phpverModel = new VirhostPhpver();
        $phplist = $phpverModel->select();
        //默认首页
        $nodeModel = new VirhostNode();
        $nodeList = $nodeModel->select();
        $endtime =  QzcloudTool::getDateMonth(date("Y-m-d"),1);
        return $this->fetch('',['phpver'=>$phplist,'nodeList'=>$nodeList,'endtime'=>$endtime]);
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }
        //php版本
        $phpverModel = new VirhostPhpver();
        $phplist = $phpverModel->select();
        //默认首页
        $nodeModel = new VirhostNode();
        $nodeList = $nodeModel->select();

        //自己关联数据库
        $database_model = new VirhostDatabase();
        $self_database_list = $database_model->where('site_id='.$id)->select();
        if($self_database_list){
            $self_database_list = $self_database_list->toArray();
        }
        $mysql = '';
        $mssql = '';
        foreach ($self_database_list as $k=>$v){
            if($v['datatype'] ==1){
                $mysql = $v['dataname'];
            }

            if($v['datatype'] ==2){
                $mssql = $v['dataname'];
            }
        }
        //系统未关联
        $database_model = new VirhostDatabase();
        $database_list = $database_model->where('site_id=0 or site_id='.$id)->select();

        return $this->fetch('',['model' => M::find($id),
            'phpver'=>$phplist,
            'nodeList'=>$nodeList,
            'mssql'=>$mssql,
            'mysql'=>$mysql,
            'database_list'=>$database_list,
        ]);
    }

    // 状态
    public function status($id){
        return $this->getJson(S::goStatus(Request::post('status'),$id));
        }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
        }

    // 批量删除
    public function batchRemove(){
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
        }

    // 回收站
    public function recycle(){
        if (Request::isAjax()) {
            return $this->getJson(S::goRecycle());
        }
        return $this->fetch();
    }

}
