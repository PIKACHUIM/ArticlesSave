<?php
declare (strict_types=1);

namespace app\admin\controller\host;

use app\common\model\HostVps;
use app\common\model\HostVps as M;
use app\common\model\ServersIpv4;
use app\common\model\ServersIpv4Nat;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\service\Ecs;
use app\common\util\BaseConst;
use app\common\util\QzcloudTool;
use think\facade\Request;
use app\common\service\HostVps as S;


class Vps extends \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck', 'AdminPermission'];

    // 列表
    public function index()
    {
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        $nodeModel = new ServersNode();
        $node = $nodeModel->select();
        return $this->fetch('',['node'=>$node]);
    }

    // 添加
    public function add()
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        $passwd = QzcloudTool::generatePassword(10);;
        $endtime =  QzcloudTool::getDateMonth(date("Y-m-d"),1);
        $panelpasswd = QzcloudTool::generatePassword(8);
        $line = ServersLine::getAllList(['state' => 1]);
        $GPU_CAPACITY = BaseConst::GPU_CAPACITY;
        $GPU_RESOLUTION = BaseConst::GPU_RESOLUTION;
        return $this->fetch('', ['line' => $line['data'],
            'GPU_RESOLUTION' => $GPU_RESOLUTION,
            'GPU_CAPACITY' => $GPU_CAPACITY,
            'endtime' => $endtime,
            'panelpasswd' => $panelpasswd,
            'passwd' => $passwd
        ]
        );
    }

    // 编辑
    public function edit($id)
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(), $id));
        }
        $line = ServersLine::getAllList(['state' => 1]);
        $GPU_CAPACITY = BaseConst::GPU_CAPACITY;
        $GPU_RESOLUTION = BaseConst::GPU_RESOLUTION;
        $model = M::find($id);
        $nodeinfo = (new ServersNode())->find($model->node_id);
        $nodelist = (new ServersNode())->where(['line_id'=>$nodeinfo->line_id])->select();
        return $this->fetch('', ['line' => $line['data'],'node_list'=>$nodelist,'model' => $model, 'GPU_RESOLUTION' => $GPU_RESOLUTION, 'GPU_CAPACITY' => $GPU_CAPACITY,'nodeinfo'=>$nodeinfo]);
    }

    // 状态
    public function status($id)
    {
        return $this->getJson(S::goStatus(Request::post('status'), $id));
    }

    // 删除
    public function remove($id)
    {
        return $this->getJson(S::goRemove($id));
    }

    // 删除
    public function delete($id)
    {
        return $this->getJson(S::goDelete($id));
    }

    //云主机重建
    public function vm_recreate($id)
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goRecreate($id));
        }
    }
    //开机
    public function vm_start($id){
        return $this->getJson(S::goStart($id));
    }

    //关机
    public function vm_close($id){
        return $this->getJson(S::goClose($id));
    }

    //重启
    public function vm_restart($id){
        return $this->getJson(S::goRestart($id));
    }

    //电源
    public function vm_power($id){
        return $this->getJson(S::goPower($id));
    }

    //锁定
    public function vm_lock($id){
        return $this->getJson(S::goLock($id));
    }

    //解锁
    public function vm_unlock($id){
        return $this->getJson(S::goUnlock($id));
    }

    public function iplist($id){
        $hostModel = new HostVps();
        $host= $hostModel->find($id);
        if (Request::isAjax()) {
            if($host->host_name==""){
                return $this->getJson(['code'=>200]);
            }
            $model = new ServersIpv4();
            if($host->is_nat==1){
                $model = new ServersIpv4Nat();
            }
            if($this->request->param('ip_pool_id')!=""){
                return $this->getJson($model::getList());
            }
            return $this->getJson($model::getPage());

        }

        return $this->fetch('',['v_name'=>$host->host_name,'id'=>$host->id,'is_nat'=>$host->is_nat]);
    }

    public function set_masterip($id){
        if (Request::isAjax()) {
            $ip = $this->request->param('ip');
            $hostModel = new HostVps();
            $host= $hostModel->find($id);
            $ipv4model = new ServersIpv4();
            $oldip = $ipv4model->where(['ip'=>$host->ip])->find();
            $oldmac = $oldip->mac;
            $newip = $ipv4model->where(['ip'=>$ip])->find();
            $newmac = $newip->mac;
            $oldip->mac = $newmac;
            $newip->mac = $oldmac;
            $newip->save();
            $oldip->save();
            return $this->getJson(S::goEdit(['ip'=>$ip],$id));
        }
    }

    public function remove_ip($id){
        if (Request::isAjax()) {
           $ip = $this->request->param('ip');
            return $this->getJson(S::goRemoveIp(['ip'=>$ip],$id));
        }
    }

    public function addip($hostid){
        $hostModel = new HostVps();
        $host= $hostModel->find($hostid);
        $nodeModel = new ServersNode();
        $node = $nodeModel->find($host->node_id);
        if (Request::isAjax()) {
            $ids = Request::post('ids');
            return $this->getJson(S::goAddIp(['ids'=>$ids],$hostid));
        }
        return $this->fetch('',['id'=>$host->id,'ip_pool_id'=>$node->ip_pool_id]);
    }

    public function ajax_node_image()
    {
        if (Request::isAjax()) {
            $line_id = Request::param('line_id');
            if (empty($line_id)) {
                return $this->getJson(['code' => 201, 'msg' => '线路id为空']);
            }
            return $this->getJson(S::node_image($line_id));
        }
    }

    public function editendtime($id){
        $hostModel = new HostVps();
        $host= $hostModel->find($id);

        if (Request::isAjax()) {
            $hostModel->where(['id'=>$id])->save( ['end_time'=>$this->request->param('end_time')]);
            Ecs::do_overdue($id);
            return $this->getJson(['code'=>200]);
        }
        return $this->fetch('',['id'=>$host->id,'host'=>$host]);
    }

    public function reset_network($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goResetNetwork($id));
        }
    }
}
