<?php
declare (strict_types = 1);

namespace app\admin\controller\servers;

use app\common\model\ServersIpPool;
use think\facade\Request;
use app\common\service\ServersIpv4 as S;
use app\common\model\ServersIpv4 as M;

class Ipv4 extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        $poolModel = new ServersIpPool();
        $pool_list = $poolModel->select();
        return $this->fetch('',['pool_list' => $pool_list]);
    }

    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        $poolModel = new ServersIpPool();
        $pool_list = $poolModel->select();
        return $this->fetch('',['pool_list' => $pool_list]);
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }
        $poolModel = new ServersIpPool();
        $pool_list = $poolModel->select();
        return $this->fetch('',['model' => M::find($id),'pool_list' => $pool_list]);
    }

    // 状态
    public function status($id){
        return $this->getJson(S::goStatus(Request::post('state'),$id));
        }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
        }

    // 批量删除
    public function batchRemove(){
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
        }

    // 回收站
    public function recycle(){
        if (Request::isAjax()) {
            return $this->getJson(S::goRecycle());
        }
        return $this->fetch();
    }

}
