<?php
declare (strict_types=1);

namespace app\admin\controller\servers;

use app\common\model\ServersArea;
use app\common\model\ServersImageConfig;
use app\common\model\ServersImageLine;
use think\facade\Request;
use app\common\service\ServersLine as S;
use app\common\model\ServersLine as M;

class Line extends \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck', 'AdminPermission'];

    // 列表
    public function index()
    {
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch();
    }

    // 添加
    public function add()
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();

        $imageModel = new ServersImageConfig();
        $image_list = $imageModel->select();
        return $this->fetch('', ['area_list' => $area_list, 'image_list' => $image_list]);
    }

    // 编辑
    public function edit($id)
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(), $id));
        }

        $areaModel = new ServersArea();
        $area_list = $areaModel->where('state=1')->select();

        $imageModel = new ServersImageConfig();
        $image_list = $imageModel->select();

        $imageLineModel = new ServersImageLine();
        $image_list_selectd = $imageLineModel->where(['line_id'=>$id])->select();
        $image_selectd = [];
        if($image_list_selectd){
            $image_selectd = $image_list_selectd->toArray();
            $image_selectd = array_column($image_selectd,'config_id');
        }
        return $this->fetch('', ['model' => M::find($id),'area_list' => $area_list,
            'image_list' => $image_list,'image_selectd'=>$image_selectd]);
    }

    // 状态
    public function status($id)
    {
        return $this->getJson(S::goStatus(Request::post('state'), $id));
    }

    // 删除
    public function remove($id)
    {
        return $this->getJson(S::goRemove($id));
    }

    // 批量删除
    public function batchRemove()
    {
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
    }
    //获取线路ajax
    public function ajax_getlist(){
        if (Request::isAjax()) {
            return $this->getJson(M::getAllList(['state'=>1]));
        }
    }

}
