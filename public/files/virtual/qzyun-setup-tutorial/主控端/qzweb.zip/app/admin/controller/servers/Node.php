<?php
declare (strict_types=1);

namespace app\admin\controller\servers;

use app\common\model\HostVps;
use app\common\model\ServersIpPool;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\model\ServersNode as M;
use app\common\service\Ecs;
use think\facade\Request;
use app\common\service\ServersNode as S;

class Node extends \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck', 'AdminPermission'];

    // 列表
    public function index()
    {
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        $LineModel = new ServersLine();
        $line = $LineModel->where(['state' => 1])->select()->toArray();

        //获取ip池
        $ipPoolModel = new ServersIpPool();
        $pool = $ipPoolModel->select()->toArray();
        return $this->fetch('', ['line' => $line, 'pool' => $pool]);
    }

    // 添加
    public function add()
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        //获取线路
        $LineModel = new ServersLine();
        $line = $LineModel->where(['state' => 1])->select()->toArray();

        //获取ip池
        $ipPoolModel = new ServersIpPool();
        $pool = $ipPoolModel->select()->toArray();

        //虚拟化类型
        $node_type = ServersNode::$node_type;
        return $this->fetch('', ['line' => $line, 'pool' => $pool, 'node_type' => $node_type]);
    }

    // 编辑
    public function edit($id)
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(), $id));
        }

        $LineModel = new ServersLine();
        $line = $LineModel->where(['state' => 1])->select()->toArray();

        //获取ip池
        $ipPoolModel = new ServersIpPool();
        $pool = $ipPoolModel->select()->toArray();
        return $this->fetch('', ['model' => M::find($id), 'line' => $line, 'pool' => $pool]);
    }

    // 状态
    public function status($id)
    {
        return $this->getJson(S::goStatus(Request::post('state'), $id));
    }

    // 删除
    public function remove($id)
    {
        return $this->getJson(S::goRemove($id));
    }

    // 批量删除
    public function batchRemove()
    {
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
    }

    public function ajax_getInfo()
    {
        if (Request::isAjax()) {
            return $this->getJson(S::getInfo(Request::post('node_id')));
        }
    }

    //监控母鸡
    public function monitor_node(){
        $id = $this->request->param('id');
        if($this->request->isAjax()){
            return $this->getJson(Ecs::monitorCompany(['node_id'=>$id]));
        }
        $node = \app\common\service\ServersNode::getInfo($id);
        return $this->fetch('',['node'=>$node['data']]);
    }


    public function hostlist(){
        $hostModel = new HostVps();
        if (Request::isAjax()) {
            return $this->getJson($hostModel::getList());
        }
        return $this->fetch('',['node_id'=>$this->request->param('node_id')]);
    }

    public function forwardip(){
        $id = $this->request->param('id');
        $forward_url = $this->request->param('forward_url');
        if($this->request->isAjax()){
            return $this->getJson(S::forwardip($forward_url,$id));
        }
        return $this->fetch('',['model' => M::find($id)]);
    }

    public function resetForwardPort(){
        $id = $this->request->param('id');
        if($this->request->isAjax()){
            return $this->getJson(S::resetForwardPort($id));
        }
    }

    public function vmlist(){
        if (Request::isAjax()) {
            $param = $this->request->param();
            return $this->getJson(S::vmlist($param));
        }
        return $this->fetch('',['id'=>$this->request->param('id')]);
    }

}
