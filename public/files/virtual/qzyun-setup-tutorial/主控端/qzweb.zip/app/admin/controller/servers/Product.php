<?php
declare (strict_types=1);

namespace app\admin\controller\servers;

use app\common\util\BaseConst;
use think\facade\Request;
use app\common\service\Product as S;
use app\common\model\Product as M;

class Product extends \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck', 'AdminPermission'];

    // 列表
    public function index()
    {
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        return $this->fetch('');
    }

    // 添加
    public function add()
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        $GPU_CAPACITY = BaseConst::GPU_CAPACITY;
        $GPU_RESOLUTION = BaseConst::GPU_RESOLUTION;
        return $this->fetch('',[
            'GPU_RESOLUTION' => $GPU_RESOLUTION,
            'GPU_CAPACITY' => $GPU_CAPACITY,]);
    }

    // 编辑
    public function edit($id)
    {
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(), $id));
        }
        $GPU_CAPACITY = BaseConst::GPU_CAPACITY;
        $GPU_RESOLUTION = BaseConst::GPU_RESOLUTION;
        return $this->fetch('',[
            'GPU_RESOLUTION' => $GPU_RESOLUTION,
            'GPU_CAPACITY' => $GPU_CAPACITY,'model' => M::find($id)]);
    }

    // 删除
    public function remove($id)
    {
        return $this->getJson(S::goRemove($id));
    }

    // 批量删除
    public function batchRemove()
    {
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
    }

}
