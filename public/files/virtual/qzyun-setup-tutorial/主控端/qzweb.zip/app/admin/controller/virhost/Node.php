<?php
declare (strict_types = 1);

namespace app\admin\controller\virhost;

use app\common\model\ServersLine;
use app\common\model\VirhostPhpver;
use think\facade\Request;
use app\common\service\VirhostNode as S;
use app\common\model\VirhostNode as M;

class Node extends  \app\admin\controller\Base
{
    protected $middleware = ['AdminCheck','AdminPermission'];

    // 列表
    public function index(){
        if (Request::isAjax()) {
            return $this->getJson(M::getList());
        }
        //获取线路
        $LineModel = new ServersLine();
        $line = $LineModel->select()->toArray();
        return $this->fetch('', ['line' => $line]);
    }

    // 添加
    public function add(){
        if (Request::isAjax()) {
            return $this->getJson(S::goAdd(Request::post()));
        }
        //获取线路
        $LineModel = new ServersLine();
        $line = $LineModel->select()->toArray();

        $phpModel = new VirhostPhpver();
        $php = $phpModel->select()->toArray();
        return $this->fetch('', ['line' => $line,'php' => $php]);
    }

    // 编辑
    public function edit($id){
        if (Request::isAjax()) {
            return $this->getJson(S::goEdit(Request::post(),$id));
        }

        //获取线路
        $LineModel = new ServersLine();
        $line = $LineModel->select()->toArray();
        $phpModel = new VirhostPhpver();
        $php = $phpModel->select()->toArray();
        $model =  M::find($id);
        $model->phpselect = explode(',',$model->phpver);
        return $this->fetch('',['model' =>$model,'line' => $line,'php' => $php]);
    }

    // 状态
    public function status($id){
        return $this->getJson(S::goStatus(Request::post('sate'),$id));
        }

    // 删除
    public function remove($id){
        return $this->getJson(S::goRemove($id));
        }

    // 批量删除
    public function batchRemove(){
        return $this->getJson(S::goBatchRemove(Request::post('ids')));
        }

    // 回收站
    public function ajax_getInfo(){
        if (Request::isAjax()) {
            return $this->getJson(S::getInfo(Request::post('node_id')));
        }
        return $this->fetch();
    }

}
