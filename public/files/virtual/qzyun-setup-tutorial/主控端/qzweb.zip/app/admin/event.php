<?php
// 事件定义文件
return [
    'bind'    =>    [
        // 更多事件绑定
    ],
    'listen'  =>    [
        'AdminLog'    =>    ['app\common\listener\AdminAdminLog']
        // 更多事件监听
    ],
];