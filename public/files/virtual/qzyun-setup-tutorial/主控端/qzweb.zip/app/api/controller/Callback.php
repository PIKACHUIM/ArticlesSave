<?php

namespace app\api\controller;

use app\ApiController;
use app\BaseController;
use app\common\model\BackupVps;
use app\common\model\HostVps;
use app\common\model\ServersNode;
use app\common\model\SnapshotVps;
use app\common\model\Task;
use app\common\service\Ecs;
use \think\facade\Log;
/**
 * 首页接口
 */
class Callback extends ApiController
{
    private $publickey ='-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA39KGJloywY5qmv9Dd27h
jyrHKfonzb01sWbnbC7l6HImgHGGSVyw+VMI8SY34K2YgIBX+07qeQWFXOLgY4YB
yPqazXJWym4kI7gc/bSXy8Anda/kQcEq6Z8LA5vxB6ho98yeFBSh++Kjp7G/lINL
oAsQIxn10I7rvSOhFNWQvNFM+EXAN+3y+Q8nkxwLadli27mVJJCO1EN8GSTlgOev
C2pvua2tYRB8OPumEQgvch8+BgxhnTqUcSwRiQ20Bh8iZMpA4L7/WaMp1KcwElqC
QHZVLDPMUhfzDnV8bvP356vKhOhJq8iLvKwR3R3s70u/zrRmJp8GmxyYPcamJUED
hQIDAQAB
-----END PUBLIC KEY-----';

    protected function initialize(){
        parent::initialize();
        $sign= $this->request->param("sign");
        $timestamp= $this->request->param("timestamp");
        $ok = openssl_verify($timestamp, base64_decode($sign), $this->publickey);
        if($ok!=true){
            return  $this->json('sign error');
        }
    }

    public function index(){
        $action = $this->request->param('action');
        $data = $this->request->param('data');
        $data = json_decode($data,true);
        $data['callback_param'] = $this->request->param('callback_param');
        if(empty( $data['callback_param'] )){
            return ;
        }
        \think\facade\Log::info("node Callback master API post=".var_export($this->request->param(),true));
        switch($action){
            case 'create_vps': //创建
                $this->createVps($data);
                break;
            case 'recreate_vps': //重新创建
                $this->createVps($data);
                break;
            case 'update_vps':
                $this->createVps($data);
                break;
            case 'remove_vps':
                $this->removeVps($data);
                break;
            case 'reinstall':
                $this->reinstallVps($data);
                break;
            case 'create_snapshot':
                $this->createSnapshotVps($data);
                break;
            case 'create_backup':
                $this->createBackupVps($data);
                break;
            case 'restore_snapshot':
                $this->restoreSnapshotVps($data);
                break;
            case 'restore_backup':
                $this->restoreBackupVps($data);
                break;
            case 'remove_snapshot':
                $this->removeSnapshotVps($data);
                break;
            case 'remove_backup':
                $this->removeBackupVps($data);
                break;
            case 'downISOFile':
            case 'importISO':
                $this->importIso($data);
                break;
            case 'installOS':
                $this->installOS($data);
                break;
            case 'rescue':
            case 'changePasswd':
                $this->rescue($data);
                break;

            default:;
        }
    }

    private function createVps($data){
        $host_model = new HostVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        $host_state =2;
        if($data['code']!=200){
            $state = 3;
            $host_state =11;
        }
        $msg = isset($data['msg'])?$data['msg']:'';
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s"),'remark'=>$msg]);
        $host_model->where($task['param'])->update(['state'=>$host_state,'update_time'=>date("Y-m-d H:i:s")]);
        return  $this->json('ok');
    }

    private function removeVps($data){
        $host_model = new HostVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        if($data['code']!=200){
            $state = 3;
        }

        $msg = isset($data['msg'])?$data['msg']:'';

        $node_model = new ServersNode();
        $host = $host_model->where($task['param'])->find();
        $node = $node_model->where(['id' =>$host->node_id])->find();
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s"),'remark'=>$msg]);

        $node_model->where(['id' =>$host->node_id])->update(['vm_number'=>$node['vm_number']-1]);
        $host_model->where($task['param'])->delete();
        return  $this->json('ok');

    }

    private function reinstallVps($data){
        $host_model = new HostVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        $host_state =2;
        $msg = isset($data['msg'])?$data['msg']:'';
        if($data['code']!=200){
            $state = 3;
            $host_state =5;
        }
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s"),'remark'=>$msg]);
        $host_model->where($task['param'])->update(['state'=>$host_state,'update_time'=>date("Y-m-d H:i:s")]);
        return  $this->json('ok');
    }

    private function createSnapshotVps($data){
        $snapshot_model = new SnapshotVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        $snapshot_state =2;
        if($data['code']!=200){
            $state = 3;
            $snapshot_state =3;
        }
        $snapshot = $snapshot_model->where($task['param'])->find();
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);

        //$snapshot_model->where(['host_id'=>$snapshot->host_id])->update(['current'=>1]);
        $snapshot_model->where(['id'=>$snapshot->id])->save(['state'=>$snapshot_state]);
        return  $this->json('ok');
    }

    private function restoreSnapshotVps($data){
        $snapshot_model = new SnapshotVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        $snapshot_state =2;
        if($data['code']!=200){
            $state = 3;
            //$snapshot_state =11;
        }

        $snapshot = $snapshot_model->where($task['param'])->find();
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);
        $snapshot_model->where(['id'=>$snapshot->id])->save(['state'=>$snapshot_state]);
        return  $this->json('ok');
    }

    private function removeSnapshotVps($data){
        $snapshot_model = new SnapshotVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        if($data['code']!=200){
            $state = 3;
        }
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);
        $snapshot = $snapshot_model->where($task['param'])->find();
        $snapshot_model->where(['id'=>$snapshot->id])->delete();
        return  $this->json('ok');
    }

    private function createBackupVps($data){
        $backup_model = new BackupVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        $backup_state =2;
        if($data['code']!=200){
            $state = 3;
            $backup_state =3;
        }
        $backup = $backup_model->where($task['param'])->find();
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);
        $backup_model->where(['id'=>$backup->id])->save(['state'=>$backup_state]);
        return  $this->json('ok');
    }

    private function restoreBackupVps($data){
        $backup_model = new BackupVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        $backup_state =2;
        if($data['code']!=200){
            $state = 3;
        }

        $backup = $backup_model->where($task['param'])->find();
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);
        $backup_model->where(['id'=>$backup->id])->save(['state'=>$backup_state]);
        return  $this->json('ok');
    }

    private function removeBackupVps($data){
        $backup_model = new BackupVps();
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }
        $state =2;
        if($data['code']!=200){
            $state = 3;
        }
        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);
        $backup = $backup_model->where($task['param'])->find();
        $backup_model->where(['id'=>$backup->id])->delete();
        return  $this->json('ok');
    }

    private function importIso($data){
        $taskid = $data['callback_param'];
        $code = $data['code'];
        $result = $data['data'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }


        $state =2;
        if ($code!=200){
            $data = ['os_dir'=>'','state'=>2];
        }else{
            $state = 3;
            $data = ['os_dir'=>$result,'state'=>3];
        }

        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);

        $data['update_time'] = date("Y-m-d H:i:s");
        $MirrorsDetail = new \app\common\model\BaremetalMirrorsDetail();
        $MirrorsDetail->where(['id'=>$task['param']])->save($data);
        return  $this->json('ok');
    }

    private function installOS($data){
        $taskid = $data['callback_param'];
        $code = $data['code'];

        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }

        $state =1;
        if ($code!=200){
            $state = 4;
        }

        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);

        $upd['update_time'] = date("Y-m-d H:i:s");
        $upd['state'] = $state;
        $hostModel = new \app\common\model\BaremetalHost();
        $hostModel->where(['id'=>$task['param']])->save($upd);
        return  $this->json('ok');
    }

    private function rescue($data){
        $taskid = $data['callback_param'];
        $task_model =  new Task();
        $task = $task_model->where(['id'=>$taskid,'is_delete'=>1])->find();
        if(empty($task)){
            return  $this->json('ok');
        }
        if(!in_array($task['state'],[0,1])){
            return  $this->json('ok');
        }

        $state =1;

        $task_model->where(['id'=>$taskid,'is_delete'=>1])->update(['state'=>$state,'end_time'=>date("Y-m-d H:i:s")]);

        $upd['update_time'] = date("Y-m-d H:i:s");
        $upd['state'] = $state;
        $hostModel = new \app\common\model\BaremetalHost();
        $hostModel->where(['id'=>$task['param']])->save($upd);
        return  $this->json('ok');
    }

}
