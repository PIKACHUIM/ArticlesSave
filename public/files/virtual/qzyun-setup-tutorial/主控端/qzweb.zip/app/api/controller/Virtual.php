<?php

namespace app\api\controller;

use app\ApiController;
use app\BaseController;
use app\common\model\BackupVps;
use app\common\model\FirewallVps;
use app\common\model\ForwardPortVps;
use app\common\model\HostVps;
use app\common\model\Product;
use app\common\model\ServersArea;
use app\common\model\ServersImageConfig;
use app\common\model\ServersIpv4;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\model\SnapshotVps;
use app\common\model\Task;
use app\common\service\Ecs;
use app\common\util\BaseConst;
use app\common\util\QzcloudTool;
use app\home\controller\cart;
use think\Exception;
use think\exception\HttpResponseException;
use think\facade\Db;
use \think\facade\Log;
use think\facade\Request;
use think\Response;

/**
 * 首页接口
 */
class Virtual extends ApiController
{

    protected function initialize(){
        parent::initialize();
        $signature_remote= $this->request->param("signature");
        $random= $this->request->param("random");
        $time= $this->request->param("time");
        Log::write('post-initialize-param=###'.json_encode($this->request->param()).'##action=##'.json_encode($this->request->action()));
        $site = config('web');
        $localapikey = $site['apikey'];
        if(empty($site['apikey'])){
            return  $this->json('apikey null',-1);
        }

        $data['timeStamp'] = $time;
        $data['randomStr'] = $random;
        $data['token'] = $localapikey;
        sort($data,SORT_STRING);
        $str = implode($data);
        $signature = md5($str);
        $signature = strtoupper($signature);    //最终得到加密后全大写的签名

        if($signature!=$signature_remote){
             return  $this->json('sign error',-1);
        }

        if($time+10<$time){
            return  $this->json('sign timeout',-1);
        }
    }

    public function area(){
        $this->json('ok',0);
    }

    public function create_host(){
        $post = $this->request->param();

        $lineModel = new ServersLine(); //线路
        $nodeModel = new ServersNode();//物理节点信息

        if (!isset($post['areas_id'])){
            return  $this->json('areas_id empty',-1);
        }

        $line = $lineModel->where(['id' => $post['areas_id']])->find();
        if(isset($post['nodes_id'])){
            $node = $nodeModel->where(['id'=>$post['nodes_id']])->find();
        }else{
            $node = Ecs::getNodeid($post['areas_id']);
            if (!$node) {
                return  $this->json('No nodes available',-1);
            }
        }

        $areaModel = new ServersArea();//地区信息
        $area = $areaModel->where(['id' => $line['area_id']])->find();

        $template_model = new ServersImageConfig();
        $template = $template_model->where(['id'=>$post['templates_id']])->find();
        if(empty($template)){
            return  $this->json('image template not found',-1);
        }
        $param = [];
        $param['cpu'] = $post['core'];
        $param['product_name'] = $post['cpu_mode'];
        $param['user_id'] =  $post['users_id'];
        $param['memory'] = ceil($post['memory']/1024);
        if(isset($post['sys_disk_iops']))$param['os_disk_maxiops'] = $post['sys_disk_iops'];
        if(isset($post['sys_disk_iops']))$param['os_read'] =$post['sys_disk_read'];
        if(isset($post['sys_disk_iops']))$param['os_write'] = $post['sys_disk_write'];
        $param['hard_disks'] = $post['data_disk_size'];
        if(isset($post['sys_disk_iops']))$param['data_disk_maxiops'] = $post['data_disk_iops'];
        if(isset($post['sys_disk_iops']))$param['data_read'] = $post['data_disk_read'];
        if(isset($post['sys_disk_iops']))$param['data_write'] = $post['data_disk_write'];
        $param['bandwidth'] = ceil($post['net_out']/1024);
        // $param['virtual_type'] = $post['net_in'];
        $param['snapshot_num'] = $post['snapshoot'];
        $param['backup_num'] = $post['backups'];
        $param['os_password'] = $post['sys_pwd'];
        $param['vnc_password'] = $post['vnc_pwd'];
        $param['max_reinstall_num'] = (isset($post['max_reinstall_num'])&&!empty($post['max_reinstall_num']))?$post['max_reinstall_num']:$line['reinstall_num'];

        $param['end_time'] = $post['expire_time'];
        $param['ipnum'] = $post['ip_num'];
        $param['traffic'] = $post['flow_limit'];
        $param['port_num'] = $post['nat_acl_limit'];
        $param['domain_num'] = $post['nat_web_limit'];
        $param['os_name'] = $template->os_name;
        $param['is_nat'] = isset($post['is_nat'])?$post['is_nat']:($param['port_num']>0?1:0);

        $param['area_name'] = $area['area_name'];

        $param['area_id'] = $area['id'];
        $param['line_name'] = $line['line_name'];
        $param['line_id'] = $line['id'];
        $param['node_name'] = $node['node_name'];
        $param['node_id'] = $node['id'];

        $param['buy_time'] = date("Y-m-d H:i:s");

        try {
            Db::startTrans();
            $result = Ecs::createVps($param);
            Db::commit();
            $data = [];
            $ip = $result['ip'].','.$result['add_ip'];
            $ip =  array_filter(array_unique(explode(',',$ip)));
            $ipv4Model  = new ServersIpv4();
            $iplist = $ipv4Model->whereIn('ip',$ip)->select();
            $ipaddrid = 0;
            $publicIp = [];
            foreach ($iplist as $k=>$v){
                if($v['ip']==$result['ip']){
                    $ipaddrid = $v['id'];
                    $publicIp[] = ['id'=>$v['id'],'ip'=>$v['ip'],'ip_pools_id'=>$v['ip_pool_id']];
                }

            }
            if($param['is_nat']==1){
                $forwardPortModel= new ForwardPortVps();
                $port = $template->os_type==1?3389:22;
                $ip = $forwardPortModel->where(['host_id'=>$result['id'],'sys'=>2,'dport'=>$port])->find();
                $ipaddrid = 1;
                $publicIp[] = ['id'=>1,'ip'=>$ip['api_url'].":".$ip['sport'],'ip_pools_id'=>0];
            }
            $data['id']= $result['host_id'];
            $data['name']= $result['host_name'];
            $data['nodes_id']= $param['node_id'];
            $data['public_ip']= $publicIp;
            $data['private_ip']= $result['local_ip'];
            $data['vnc_port']= $result['vnc_port'];
            $data['ip_address_id']= $ipaddrid;
            return   $this->json('succ',0,$data);
        }catch (\Exception $e){
            Db::rollback();
            $this->json($e->getMessage(),-1);
        }

    }

    public function remove_host($id){
        try{
            Ecs::delete_host(['hostid'=>$id]);
            $this->json('删除命令执行成功',0);
        }catch (Exception $e){
            $this->json($e->getMessage(),-1);
        }

    }

    public function update_host($id){
        try{
            $post= $this->request->param();
            $hostModel = new HostVps();
            $hostinfo = $hostModel->where(['id'=>$id])->find();
            if(!$hostinfo){
                $this->json("ret=云主机不存在",1);
            }

            $param['id'] =$id;
            $param['cpu'] = $post['core'];
            $param['memory'] = $post['memory'];
            $param['hard_disks'] = $post['data_disk_size'];
            $param['bandwidth'] = $post['net_out'];
            $param['ip_num'] = $post['ip_num']; //暂时不处理ip数量升级
            $param['traffic'] = $post['flow_limit'];

            $param['host_name'] = $hostinfo['host_name'];
            Ecs::updateVps($param,$hostinfo);
            $this->json($hostinfo['host_name']."更改配置成功",0);
        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }
    }

    public function host_info($id){
        $hostModel = new HostVps();
        $hostinfo = $hostModel->where(['id'=>$id])->find();
        if(!$hostinfo){
            $this->json("ret=云主机不存在",1);
        }
        $hostinfo->vnc_pwd = $hostinfo->vnc_password;
        $hostinfo->users_id = $hostinfo->user_id;
        $hostinfo->sys_pwd = $hostinfo->os_password;

        $info = Db::table('cloud_bind_virtual_security_groups')->where(['virtuals_id'=>$id])->find();
        $bind_security_group = $info;
        if(!empty($info)){
            $groups = Db::table('cloud_security_groups')->where(['id'=>$info['virtual_security_groups_id']])->find();

            if(!empty($groups)){
                $list = Db::table('cloud_security_group_acls')->where(['virtual_security_groups_id'=>$groups['id'],'erasable'=>0])->select();
                $groups['security_group_acl'] =$list;
            }

            $bind_security_group['bind_security_group'] = $groups;
        }

        $hostinfo->bind_security_group = $bind_security_group;
        //$ip = $hostinfo['ip'].','.$hostinfo['add_ip'];
        //$ip =  array_filter(array_unique(explode(',',$ip)));

        $ip_model = new ServersIpv4();
        $iplist = $ip_model->where(['v_name'=>$hostinfo->host_name])->select();
        $iplist = $iplist->toArray();

        $ipaddrid = 0;
        $publicIp = [];
        foreach ($iplist as $k=>$v){
            if($v['ip']==$hostinfo['ip']){
                $ipaddrid = $v['id'];
                $publicIp[] = ['id'=>$v['id'],'ip'=>$v['ip'],'ip_pools_id'=>$v['ip_pool_id']];
            }

        }

        $hostinfo->ip_address_id= $ipaddrid;
        $hostinfo->ip_list=$publicIp;

        $hostinfo->private_ips=[];

        $this->json('success',0,$hostinfo->toArray());
    }

    public function reset_os($id,$templateid){
        try{
            $hostModel = new HostVps();
            $hostinfo = $hostModel->where(['id'=>$id])->find();
            if(!$hostinfo){
                $this->json("ret=云主机不存在",1);
            }

            $param['os_id'] =$templateid;
            $param['hostid'] = $id;
            $param['password'] = $hostinfo['os_password'];
            $result = Ecs::reinstallTask($param);
            if($result['code']==200){
                $this->json("系统重装已放入队列运行",0);
            }else{
                $this->json($result['msg'],1);
            }
        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }
    }

    public function monitoring_host($id){
        try{
            $hostModel = new HostVps();
            $hostinfo = $hostModel->where(['id'=>$id])->find();
            if(!$hostinfo){
                $this->json("ret=云主机不存在",1);
            }
            $data = Ecs::monitorHost(['hostid'=>$id]);
            if($data['code']==200){
                $io = [];
                $io['metric'] = 'disk_Kbps';
                if(isset($data['data']['IO'])){
                    foreach ($data['data']['IO'] as $k=>$v){
                        $io[$k]= $v;
                    }
                }
                $this->json('success',0,[
                    'id'=>$hostinfo->id,
                    'Type'=>'virtual machine',
                    'Name'=>$hostinfo->host_name,
                    'Cpu'=>["metric"=>"cpu_precent","value"=>$data['data']['CpuStats']],
                    'Network'=>["in"=>$data['data']['NetworkStats']['BytesReceivedPersec'],"out"=>$data['data']['NetworkStats']['BytesSentPersec']],
                    'Disk'=>$io,
                    'CreatedAt'=>date('Y-m-d H:i:s'),
                ]);
            }else{
                $this->json($data['msg'],1);
            }
        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }
    }

    public function nat_acl_add(){
        try {
            $logic = new \app\common\service\Ecs();
            $post = $this->request->param();
            $portlist = $logic->find_port(['hostid'=>$post['virtual'],'keywords'=>false]);
            if(!$portlist){
                $this->json('分配端口失败',1);
            }

            $param['hostid']  = $post['virtual'];
            $param['name']  = $post['name'];
            $param['dport']  = $post['interior_port'];
            $param['sport']  = $portlist[0] ;

            $result = $logic->add_forward_port($param);
            if($result['code']==200){
                $this->json('规则添加成功',0);
            }else{
                $this->json($result['msg'],1);
            }
        } catch (Exception $e) {
            $this->json($e->getMessage(),1);
        }
    }

    public function nat_acl_del($id){
        try {
            $post = $this->request->param();

            $port_model = new ForwardPortVps();
            $portinfo = $port_model->find($id);
            $param['hostid']  =$portinfo['host_id'];
            $param['id']  = $id;

            $result = ecs::remove_forward_port($param);
            if($result['code']==200){
                $this->json('规则删除成功',0);
            }else{
                $this->json($result['msg'],1);
            }
        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }

    }

    public function nat_acl_update($virtual_id){
        $host_model = new HostVps();//virtual_id
        $post = $this->request->param();
        $host_model->where(['id'=>$virtual_id])->save(['port_num'=>$post['nat_acl_limit']]);
        $this->json('操作成功',0);
    }

    public function nat_acl_list($virtual_id){
        $forwardPortModel= new ForwardPortVps();
        $list = $forwardPortModel->where(['host_id'=>$virtual_id])->select();
        $data = [];
        foreach ($list as $k=>$v){
            $data[$k] = [
                'id'=>$v['id'],
                'name'=>$v['name'].('('.(($v['sys']==2)?'系统':'自定义').')'),
                'exterior_port'=>$v['api_url'].':'.$v['sport'],
                'interior_port'=>$v['dip'].':'.$v['dport'],
                'type'=>$v['port_type'],
                'virtuals_id'=>$v['host_id'],
                'created_at'=>'',
                'updated_at'=>''
            ];
        }
        $this->json('操作成功',0,$data);
    }

    public function snapshot_add(){
        $post = $this->request->param();
        $data = Ecs::createSnapshotHost(['hostid'=>$post['virtual']]);
        if($data['code']==200){
            $this->json('操作成功',0,[
                'id'=>$data['data']['id'],
                'virtuals_id'=>$post['virtual'],
                'name'=>$data['data']['name'],
            ]);
        }else{
            $this->json($data['msg'],1);
        }
    }

    public function snapshot_del($id){
        $snapshotHostModel = new SnapshotVps();
        $snapshot = $snapshotHostModel->find($id);
        $data = Ecs::removeSnapshotHost(['hostid'=>$snapshot['host_id'],'id'=>$id]);
        if($data['code']==200){
            $this->json('删除快照成功',0);
        }else{
            $this->json($data['msg'],1);
        }
    }

    public function snapshot_restore($id){
        $snapshotHostModel = new SnapshotVps();
        $snapshot = $snapshotHostModel->find($id);
        $data = Ecs::restoreSnapshotHost(['hostid'=>$snapshot['host_id'],'id'=>$id]);
        if($data['code']==200){
            $this->json('恢复快照成功',0);
        }else{
            $this->json($data['msg'],1);
        }
    }

    public function snapshot_list($virtual_id){
        $snapshotHostModel = new SnapshotVps();
        $list = $snapshotHostModel->where(['host_id'=>$virtual_id])->select();//
        $data = [];
        foreach ($list as $k=>$v){
            $data[] = ['id'=>$v['id'],'virtuals_id'=>$v['host_id'],'name'=>$v['name'],'created_at'=>$v['create_time']];
        }
        $this->json('获取快照成功',0,$data);
    }

    public function snapshot_edit($virtual_id){
        $host_model = new HostVps();//virtual_id
        $post = $this->request->param();
        $host_model->where(['id'=>$virtual_id])->save(['snapshot_num'=>$post['snapshot']]);
        $this->json('修改快照配置成功',0);
    }

    public function backups_add(){
        $post = $this->request->param();
        $data = Ecs::createBackupHost(['hostid'=>$post['virtual']]);
        if($data['code']==200){
            $this->json('操作成功',0,[
                'id'=>$data['data']['id'],
                'virtuals_id'=>$post['virtual'],
                'name'=>$data['data']['name'],
            ]);
        }else{
            $this->json($data['msg'],1);
        }
    }

    public function backups_del($id){
        $backupVpsModel = new BackupVps();
        $backupVps = $backupVpsModel->find($id);
        $data = Ecs::removeBackupHost(['hostid'=>$backupVps['host_id'],'id'=>$id]);
        if($data['code']==200){
            $this->json('删除备份成功',0);
        }else{
            $this->json($data['msg'],1);
        }
    }

    public function backups_restore($id){
        $backupVpsModel = new BackupVps();
        $backupVps = $backupVpsModel->find($id);
        $data = Ecs::restoreBackupHost(['hostid'=>$backupVps['host_id'],'id'=>$id]);
        if($data['code']==200){
            $this->json('恢复备份成功',0);
        }else{
            $this->json($data['msg'],1);
        }
    }

    public function backups_list($virtual_id){
        $backupVpsModel = new BackupVps();
        $list = $backupVpsModel->where(['host_id'=>$virtual_id])->select();//
        $data = [];
        foreach ($list as $k=>$v){
            $data[] = ['id'=>$v['id'],'virtuals_id'=>$v['host_id'],'name'=>$v['name'],'created_at'=>$v['create_time']];
        }
        $this->json('获取备份成功',0,$data);
    }

    public function backups_edit($virtual_id){
        $host_model = new HostVps();//virtual_id
        $post = $this->request->param();
        $host_model->where(['id'=>$virtual_id])->save(['backup_num'=>$post['backups']]);
        $this->json('修改备份配置成功',0);
    }

    public function virtual_power($virtual_id,$type){
        try {
            if($type=='start'){
                $result = Ecs::startHost(['hostid'=>$virtual_id]);
            }elseif($type=='shut'){
                $result =  Ecs::closeHost(['hostid'=>$virtual_id]);
            }elseif($type=='compel_shut'){
                $result = Ecs::powerHost(['hostid'=>$virtual_id]);
            }elseif($type=='restart'){
                $result = Ecs::restartHost(['hostid'=>$virtual_id]);
            }elseif($type=='compel_restart'){
                $result = Ecs::powerHost(['hostid'=>$virtual_id]);
                if($result['code']==200){
                    $result = Ecs::startHost(['hostid'=>$virtual_id]);
                }
            }
            if($result['code']==200){
                $this->json('执行成功',0);
            }else{
                $this->json($result['msg'],0);
            }

        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }

    }

    public function mirror_image(){
        $image_model = new ServersImageConfig();
        $list = $image_model->select();
        $data = [];
        foreach ($list as $k=>$v){
            $data[] = [
                'id'=>$v['id'],
                'name'=>$v['os_name'],
                'type'=>$v['os_type_name'],
                'desc'=>$v['remark'],
            ];
        }
        $this->json('',0,$data);
    }

    public function virtual_pause($virtual_id){
        try {
            $result = Ecs::lockHost(['hostid'=>$virtual_id]);
            if($result['code']==200){
                $this->json('执行成功',0);
            }else{
                $this->json($result['msg'],0);
            }

        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }
    }

    public function virtual_restore_pause($virtual_id){
        try {
            $result = Ecs::unlockHost(['hostid'=>$virtual_id]);
            if($result['code']==200){
                $this->json('执行成功',0);
            }else{
                $this->json($result['msg'],0);
            }

        }catch (Exception $e){
            $this->json($e->getMessage(),1);
        }
    }

    public function virtual_run_status($virtual_id){
        $data = Ecs::getStateHost(['hostid'=>$virtual_id]);
        $state = 0;
        if($data['code']==200){
            if($data['data']['state']=='Running'){
                $state=1;
            }else{
                $state=2;
            }

        }
        $this->json('',0,['code'=>$state]);
    }

    public function virtual_reset_password($virtual_id){
        $password = $this->request->post('password');
        $result = Ecs::update_password_host(['hostid'=>$virtual_id,'password'=>$password]);
        if($result['code']==200){
            $this->json('操作成功',0);

        }else{
            $this->json($result['msg'],1);
        }

    }

    public function virtual_link_vnc($virtual_id){
        $token = token('__token__'.$virtual_id);
        $this->json('ok',0,['token'=>$token]);
    }

    public function virtual_link_vnc_view($virtual_id,$vnc_token){
        Request::setMethod('post');
        $false = Request::checkToken('__token__'.$virtual_id,['__token__'.$virtual_id=>$vnc_token]);
        if($false== false){
            // $this->json('token error',1);
            //return;
        }
        $data = Ecs::guidHost(['hostid'=>$virtual_id]);
        if($data['code']==0){
            $this->json($data['msg'],1);
        }
        if(strstr($data['data']['url'],'vnc')!=false){
            $url = $data['data']['url'].'&host='.$data['data']['host'].'&host_name='.$data['data']['host_name'].'&password='.$data['data']['vnc_password'];
        }else{
            $url = $data['data']['url'];
        }
        header('Location: '.$url);
        exit;
    }

    public function security_group_add(){
        $post = $this->request->param();
        $data['users_id'] = $post['users_id'];
        $data['desc'] = $post['desc'];
        $data['name'] = $post['name'];
        $data['created_at'] = date('Y-m-d H:i:s');
        $data['updated_at'] = date('Y-m-d H:i:s');

        Db::table('cloud_security_groups')->save($data);
        $this->json('安全组添加成功',0);
    }

    public function security_group_edit($id){
        $post = $this->request->post();
        $data['name'] = $post['name'];
        $data['desc'] = $post['desc'];
        Db::table('cloud_security_groups')->where(['id'=>$id])->save($data);
        $this->json('安全组编辑成功',0);
    }

    public function security_group_del($id){
        $info = Db::table('cloud_bind_virtual_security_groups')->where(['virtual_security_groups_id'=>$id])->find();
        if(!empty($info)){
            $this->json('云主机应用中无法删除',0);
        }
        Db::table('cloud_security_groups')->where(['id'=>$id])->delete();
        $this->json('安全组删除成功',0);
    }

    public function security_group_list($userid){
        $list = Db::table('cloud_security_groups')->where(['users_id'=>$userid,'erasable'=>0])->select();
        $this->json('success',0,$list->toArray());
    }

    public function security_group_acl_list($gid){
        $list = Db::table('cloud_security_group_acls')->where(['virtual_security_groups_id'=>$gid,'erasable'=>0])->select();
        $this->json('success',0,$list->toArray());
    }

    public function security_group_apply($gid){
        $nodes = $this->request->param('nodes');
        $res = Ecs::security_group_apply(['hostid'=>$nodes[0],'security_groups_id'=>$gid]);
        if($res['code']==200){
            $this->json('应用成功',0,[]);
        }else{
            $this->json($res['msg'],1,[]);
        }

    }

    public function security_group_acl_del($id){

        $info = Db::table('cloud_security_group_acls')->find($id);
        if($info){
            $info = Db::table('cloud_bind_virtual_security_groups')->where(['virtual_security_groups_id'=>$info['virtual_security_groups_id']])->find();
            if($info){
                $this->json('删除失败，当前组正在应用',1,[]);
            }else{
                 Db::table('cloud_security_group_acls')->delete($id);
            }
        }
        $this->json('应用成功',0,[]);
    }

    public function security_group_cur($virtual_id){
        $info = Db::table('cloud_bind_virtual_security_groups')->where(['virtuals_id'=>$virtual_id])->find();
        if($info){
            $info = Db::table('cloud_security_groups')->where(['id'=>$info['virtual_security_groups_id']])->find();
            $this->json('success',0,[$info]);
        }else{
            $this->json('success',0,[]);
        }
    }

    public function security_group_acl_add(){
        $post = $this->request->param();
        Ecs::security_group_acl_add($post);
        $this->json('添加策略成功',0,[]);
    }

    public function cd_rom($virtual_id=0){

        $this->json('',0,[]);
    }

    public function security_acl_add($id){
        $post = $this->request->param();
        Ecs::add_firewall_host($post);
    }
    public function security_acl_del($id){
        Ecs::remove_firewall_host(['id'=>$id]) ;
    }
    public function security_acl_list($id){
        $list = (new FirewallVps())->where(['hostid'=>$id])->find();
        $this->json('',0,$list);
    }

    /**
     * 格式化返回Json数据
     * @param string|null $msg
     * @param int         $code
     * @param array       $data
     * @param array       $extend
     * @param int         $httpCode
     * @return object
     */
    public function json (string $msg = null,int $code = 200,array $data = [],$extend = [],int $httpCode = 200): object
    {
        $result = [
            'message'=>$msg,
            'code'  => $code,
            'time' => time(),

        ];
        if(isset($data['token'])){
            $result['vnc_token'] = $data['token'];
        }
        if (!empty($data)) {
            $result['data'] = $data;
        }
        if (!empty($extend)) {
            foreach ($extend as $k => $v) {
                $result[$k] = $v;
            }
        }
        header('Content-Type:application/json; charset=utf-8');
        $str = json_encode($result);
        exit($str);
    }



}
