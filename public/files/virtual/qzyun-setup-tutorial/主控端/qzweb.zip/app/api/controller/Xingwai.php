<?php

namespace app\api\controller;

use app\ApiController;
use app\common\model\ServersArea;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\model\HostVps;
use app\common\model\Product;
use app\common\service\Ecs;
use app\common\util\QzcloudTool;
use think\Exception;
use think\facade\Db;

/**
 * 首页接口
 */
class Xingwai extends ApiController
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    protected function initialize()
    {
        $token= $this->request->param('userstr');
        $action= $this->request->param('action');
        $site = config('web');
        $apikey = $site['apikey'];
        if(empty($site['apikey'])){
            echo ("ret=err apikey");die;
        }
        if(md5($apikey.'7i24.com')!=$token&&md5($apikey.'150cn.com')!=$token&&$action!=""){
            echo ("ret=err apikey");die;
        }
    }

    public function main(){
        $action= $this->request->param('action');
        $action = strtolower($action);
        $this->$action();
    }

    public function activate(){
        try{
            $line_id=$this->request->param("idc");
            $userid=$this->request->param("userid");
            $userid_arr=explode('|',$userid);
            $other_info = $this->request->param("vpsname");
            $os_name = $userid_arr[0];
            $virtual_type = $userid_arr[1];
            $product_id = $this->request->param("productid");
            $os_password = $this->request->param("VPSpassword");
            $panel_password = $this->request->param("VPSpassword");
            $buy_time = $this->request->param("year"); //ret 0.1 0.25 0.5 1 2 3 4 5
            //
            $date = ['0.1'=>1,'0.25'=>3,'0.5'=>6,'1'=>12,'2'=>'24','3'=>36,'4'=>48,'5'=>60];
            $date2 = ['0.083'=>1,'0.249'=>3,'0.498'=>6,'0.996'=>12,'1.992'=>'24','2.988'=>36,'3.984'=>48,'4.98'=>60];
            $productModel = new Product();
            if(!$product_id){
                echo ("ret=product_id is null");die;
            }
            $product = $productModel->where(['id'=>$product_id])->find();
            if(!$product){
                $this->wirteline("ret=product does not exist");
            }

            //拼装主机列表参数
            $lineModel = new ServersLine(); //线路
            $nodeModel = new ServersNode();//物理节点信息
            $areaModel = new ServersArea();//地区信息
            $line = $lineModel->where(['id' => $line_id])->find();
            if($line['line_type']==2){
                $this->wirteline("ret=暂时不支持开通上级代理商产品");
            }
            
            $node = Ecs::getNodeid($line_id);
            if (!$node) {
                $this->wirteline("ret=No nodes available");
            }

            $area = $areaModel->where(['id' => $line['area_id']])->find();
            $param = [];

            $param['product_id'] = $product['id'];
            $param['product_name'] = $product['product_name'];
            $param['user_id'] = 0;
            $param['orderid'] = 0;
            $param['area_name'] = $area['area_name'];
            $param['area_id'] = $area['id'];
            $param['other_info'] =$other_info;
            $param['host_name'] = $other_info;
            $param['line_name'] = $line['line_name'];
            $param['line_id'] = $line['id'];
            $param['node_name'] = $node['node_name'];
            $param['node_id'] = $node['id'];
            $param['virtual_type'] = $node['virtual_type'];
            $param['from_type'] = 1; //自生产
            $param['buy_time'] = date("Y-m-d H:i:s");
            $param['end_time'] = QzcloudTool::getDateMonth(date("Y-m-d"),$date[$buy_time]);

            //显卡
            $param['gpu_capacity'] = $product['gpu_capacity'];
            $param['resolution'] = $product['gpu_resolution'];
            //裸金
            $param['metal'] = $product['metal']==1?2:1;

            $param['ipnum'] = $product['ipnum'];
            //$param['virtual_type'] = $virtual_type=='h'?'hyper-v':'kvm';

            $param['cpu'] = $product['host_cpu'];
            $param['memory'] = $product['host_ram'];
            $param['hard_disks'] = $product['host_data'];
            $param['bandwidth'] = $product['bandwidth'];
            $param['os_name'] = $os_name ;
            $param['os_password'] =$os_password;
            $param['panel_password'] = $panel_password;
            $param['memory_dynamic'] = $node['memory_dynamic'];
            $param['ram_start'] = $node['memory_dynamic']==1?$node['ram_start']:0;
            $param['cpu_limit'] = $node['cpu_limit'];
            $param['state'] = 1;//创建中
            $param['is_agent'] =  0;
            //$param['os_disk_path'] = $node['os_disk_path'];
            $param['os_disk_maxiops'] = $node['os_iops_max'];
            $param['data_disk_path'] = $node['data_path'];
            $param['data_disk_maxiops'] = $node['data_iops_max'];
            $param['is_nat'] = $product['is_nat'];
            if ($product['is_nat'] == 1) { //挂机宝订单
                $param['port_num'] = $product['nat_port_num'];
                $param['domain_num'] = $product['nat_domain_num'];
            }
            $param['snapshot_num'] = $product['snapshot_num'];
            $param['backup_num'] = $product['backup_num'];
            $param['max_reinstall_num'] = $line['reinstall_num'];
            $param['remark'] = '7i24.com';
            Db::startTrans();
            Ecs::createVps($param);
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            $this->wirteline('ret=line:'.$e->getLine().'msg：'.$e->getMessage());
        }
        $this->wirteline('ret=ok');
    }
//http://127.0.0.1/idc/public/index.php/api/cloudapi.asp?action=update&vpsname=22222&&productid=3

    public function update(){
        $productid= $this->request->param('productid');
        $vpsname= $this->request->param("vpsname");
        $hostModel = new HostVps();
        $productModel = new Product();
        $product = $productModel->where(['id'=>$productid])->find();
        $hostinfo = $hostModel->where(['other_info'=>$vpsname])->find();
        if($product['is_nat']!=$hostinfo['is_nat']){
            $this->wirteline("ret=套餐之间不能互相转换");
        }
        if(!$product){
            $this->wirteline("ret=product does not exist");
        }

        $param['id'] = $hostinfo->id;
        $param['cpu'] = $product['host_cpu'];
        $param['memory'] = $product['host_ram'];
        $param['hard_disks'] = $product['host_data'];
        $param['bandwidth'] = $product['bandwidth'];
        $param['domain_num'] = $product['nat_domain_num'];
        $param['backup_num'] = $product['backup_num'];
        $param['port_num'] = $product['nat_port_num'];
        $param['snapshot_num'] = $product['snapshot_num'];
        $param['host_name'] = $hostinfo['host_name'];
        Ecs::updateVps($param,$hostinfo);
        $this->wirteline('ret=ok');
    }
    public function getinfo(){
        $host_name= $this->request->param('vpsname');
        $hostModel = new HostVps();
        $hostinfo = $hostModel->where(['other_info'=>$host_name])->find();
        if(!$hostinfo){
            echo ("ret=err");die;
        }//p.Ctx.WriteString("et=&vpspassword="+hostPanelPassword+"&ip="+ip+"&endtime="+endtime)
        $this->wirteline("ret=&vpspassword=".$hostinfo['panel_password']."&ip=".$hostinfo['ip']."&endtime=".$hostinfo['end_time'])."MaXRam=".$hostinfo['memory']."&
        cpunum=".$hostinfo['cpu']."&maxspace=".$hostinfo['hard_disks']."&MaxMbps8=".$hostinfo['bandwidth'];
    }

//http://127.0.0.1/idc/public/index.php/api/cloudapi.asp?action=renew&vpsname=22222&&year=0.25

    public function renew(){
        $host_name= $this->request->param('vpsname');
        $year= $this->request->param('year');
        $hostModel = new HostVps();
        $date = ['0.1'=>1,'0.25'=>3,'0.5'=>6,'1'=>12,'2'=>'24','3'=>36,'4'=>48,'5'=>60];
        $hostinfo = $hostModel->where(['other_info'=>$host_name])->find();
        if(!$hostinfo){
            $this->wirteline("ret=err host not found");
        }
        $hostinfo->save(['end_time'=>QzcloudTool::getDateMonth($hostinfo['end_time'],$date[$year])]);
        Ecs::unlockHost(['hostid'=>$hostinfo['id']]);
        $this->wirteline('ret=ok');
    }
//http://127.0.0.1/idc/public/index.php/api/cloudapi.asp?action=activate&idc=8&userid=centos6.8|h&productid=1&VPSpassword=1234567890&year=0.1

    public function panel(){
        $vpsname= $this->request->param('vpsname');
        $panel_password = $this->request->param("vpspassword");
        $hostModel = new HostVps();
        $hostinfo = $hostModel->where(['other_info'=>$vpsname])->find();
        $site = config('web');
        $domian = isset($site['apiurl'])?$site['apiurl']:'';
        $forward_url = url('control/ecs/login');
        if($domian){
            $forward_url = ltrim($forward_url,'http://');
            $index = strpos($forward_url,'/');
            $forward_url = 'http://'.$domian.substr($forward_url,$index,strlen($forward_url));
        }

        header('Location: '.$forward_url.'?host_name='.$hostinfo['host_name'].'&panel_password='.$panel_password);

    }

    public function checkvpsname(){
        $host_name= $this->request->param('vpsname');
        $hostModel = new HostVps();
        $hostinfo = $hostModel->where(['other_info'=>$host_name])->find();
        if(!$hostinfo){
            $this->wirteline('ok');
        }else{
            $this->wirteline("et=err");
        }
    }

    public function wirteline($msg){
         exit(iconv('utf-8','GBK',$msg));
}
}
