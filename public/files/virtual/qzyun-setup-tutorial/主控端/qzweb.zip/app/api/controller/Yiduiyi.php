<?php

namespace app\api\controller;

use app\ApiController;
use app\common\model\HostVps;
use app\common\model\Product;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\model\ServersArea;
use app\common\service\Ecs;
use app\common\util\QzcloudTool;
use think\facade\Db;
use think\Log;

/**
 * 首页接口
 */
class Yiduiyi extends ApiController
{
    protected $noNeedLogin = ['*'];
    protected $noNeedRight = ['*'];

    protected function initialize()
    {
        $site = config('web');
        $apikey = $site['apikey'];
        $token= $this->request->param('checksum');
        $action= $this->request->param('method');
        $client= $this->request->param('client');
        $checkTime= $this->request->param('checkTime');
        $key= md5($client.md5($apikey) .$action .$checkTime);
        if(empty($site['apikey'])){
            $this->ysvymsg("0","apikey error");
        }
        if($key!=$token&&$action!=""){
            $this->ysvymsg("0","apikey error");
        }
    }

    public function main(){
        $action= $this->request->param('method');
        $action = strtolower($action);
        $this->$action();
    }

    //http://127.0.0.1/idc/public/index.php/api/yvsy?action=create&ProductCode=8|1|centos7|h&ordersid=222222&period=2
    public function create(){
        try{
            $productCode = $this->request->param("ProductCode"); //数据中心|产品id|镜像|虚拟化类型
            $os_password = $this->request->param("VPSpassword");
            $panel_password = $this->request->param("VPSpassword");
            $buy_time = $this->request->param("period"); //
            $ordersid =$this->request->param("ordersid");
			$ftpname = $this->request->param("ftpname"); //
            $date = ['month'=>1,'season'=>2,'half'=>3,'1'=>12,'2'=>'24','3'=>36,'4'=>48,'5'=>60];
            $productModel = new Product();
            $product_config = explode('|',$productCode);
            if(!$product_config[1]){
                echo ("ret=product_id is null");die;
            }

            $product = $productModel->where(['id'=>$product_config[1]])->find();
            if(!$product){
                $this->ysvymsg("0","product does not exist");
            }

            //拼装主机列表参数
            $lineModel = new ServersLine(); //线路
            $nodeModel = new ServersNode();//物理节点信息
            $areaModel = new ServersArea();//地区信息
            $line = $lineModel->where(['id' => $product_config[0]])->find();
            if($line['line_type']==2){
                $this->ysvymsg("0","暂时不支持开通上级代理商产品");
            }
           // $node = $nodeModel->where("line_id = '" . $product_config[0]  . "' and vm_number<max_vm_number")->order('weight desc')->find();

            $node = Ecs::getNodeid($product_config[0]);
            if (!$node) {
                $this->wirteline("ret=No nodes available");
            }

            $area = $areaModel->where(['id' => $line['area_id']])->find();
            if (!$node) {
                $this->ysvymsg("0","No nodes available");
            }
            $param = [];

            $param['product_id'] = 0;
            $param['product_name'] = $product['product_name'];
            $param['user_id'] = 0;
            $param['orderid'] = 0;
            $param['area_name'] = $area['area_name'];
            $param['area_id'] = $area['id'];
            $param['line_name'] = $line['line_name'];
            $param['line_id'] = $line['id'];
            $param['node_name'] = $node['node_name'];
            $param['node_id'] = $node['id'];
            $param['virtual_type'] = $node['virtual_type'];
            $param['from_type'] = 1; //自生产
            $param['buy_time'] = date("Y-m-d H:i:s");
            $param['end_time'] = QzcloudTool::getDateMonth(date("Y-m-d"),$date[$buy_time]);
            $param['other_info'] = $ordersid;
            if($ftpname)$param['host_name'] = $ftpname;
            //显卡
            $param['gpu_capacity'] = $product['gpu_capacity'];
            $param['resolution'] = $product['gpu_resolution'];
            //裸金
            $param['metal'] = $product['metal']==1?2:1;

            $param['ipnum'] = $product['ipnum'];
           // $param['virtual_type'] = isset($product_config[3])&&$product_config[3]=='k'?'kvm':'hyper-v';

            $param['cpu'] = $product['host_cpu'];
            $param['memory'] = $product['host_ram'];
            $param['hard_disks'] = $product['host_data'];
            $param['bandwidth'] = $product['bandwidth'];
            $param['os_name'] = $product_config[2] ;
            $param['os_password'] =$os_password;
            $param['panel_password'] = $panel_password;
            $param['memory_dynamic'] = $node['memory_dynamic'];
            $param['ram_start'] = $node['memory_dynamic']==1?$node['ram_start']:0;
            $param['cpu_limit'] = $node['cpu_limit'];
            $param['state'] = 1;//创建中
            $param['is_agent'] =  0;
            //$param['os_disk_path'] = $node['os_disk_path'];
            $param['os_disk_maxiops'] = $node['os_iops_max'];
            $param['data_disk_path'] = $node['data_path'];
            $param['data_disk_maxiops'] = $node['data_iops_max'];
            $param['is_nat'] = $product['is_nat'];
            if ($product['is_nat'] == 1) { //挂机宝订单
                $param['port_num'] = $product['nat_port_num'];
                $param['domain_num'] = $product['nat_domain_num'];
            }
            $param['snapshot_num'] = $product['snapshot_num'];
            $param['backup_num'] = $product['backup_num'];
            $param['max_reinstall_num'] = $line['reinstall_num'];
            $param['remark'] = 'yvsy.com';

            Db::startTrans();
            $res = Ecs::createVps($param);
            Db::commit();

        }catch (Exception $e){
            $this->ysvymsg("0",$e->getMessage());
        }
        $this->openysvymsg("1","OK",$res['ip'],$res['host_name'],$res['panel_password']);
    }

    //http://127.0.0.1/idc/public/index.php/api/task/exec_task?taskid=28 日：day，试用：999，周：week，月：month，季：season，半年：half，1-5为年限
    public function renew(){
        $ordersid =$this->request->param("ordersid");
        $buy_time= $this->request->param('period');
        $hostModel = new HostVps();
        $date = ['month'=>1,'season'=>3,'half'=>6,'1'=>12,'2'=>'24','3'=>36,'4'=>48,'5'=>60];
        $hostinfo = $hostModel->where(['other_info'=>$ordersid])->find();
        if(!$hostinfo){
            $this->ysvymsg("0","err host not found");
        }
        $hostinfo->save(['end_time'=>QzcloudTool::getDateMonth($hostinfo['end_time'],$date[$buy_time])]);
        Ecs::unlockHost(['hostid'=>$hostinfo['id']]);
        $this->ysvymsg("1","OK");
    }
//http://127.0.0.1/idc/public/index.php/api/yvsy?action=panel&&ordersid=222222&password=3sadmSEJH
    public function panel(){
        $ordersid = $this->request->param('ordersid');
        $password = $this->request->param('password');
        $hostModel = new HostVps();
        $hostinfo = $hostModel->where(['other_info'=>$ordersid])->find();
        $site = config('web');
        $domian = isset($site['apiurl'])?$site['apiurl']:'';
        $forward_url = url('control/ecs/login');

        if($domian){
            $forward_url = ltrim($forward_url,'http://');
            $index = strpos($forward_url,'/');
            $forward_url = 'http://'.$domian.substr($forward_url,$index,strlen($forward_url));
        }
        header('Location: '.$forward_url.'?host_name='.$hostinfo['host_name'].'&panel_password='.$password);
        exit;
    }

    function ysvymsg($code,$message){
	    exit(iconv('utf-8','GBK','<?xml version="1.0" encoding="GB2312"?><root><status><code>'.$code.'</code><message>'.$message.'</message><created_at>2015112164928</created_at></status><root>'));
    }

    function openysvymsg($code,$message,$ip,$hostname,$password){
        exit(iconv('utf-8','GBK','
<?xml version="1.0" encoding="GB2312"?>
<root>
<status>
<code>'.$code.'</code>
<message>'.$message.'</message>
 </status>
 <info>
 <ip>'.$ip.'</ip>
 <hostname>'.$hostname.'</hostname>
 <password>'.$password.'</password>
 </info>
 <root>')
        );

    }
}
