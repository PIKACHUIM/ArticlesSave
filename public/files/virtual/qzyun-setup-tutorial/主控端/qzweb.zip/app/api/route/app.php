<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2018 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------
use think\facade\Route;

$site = config('web');
$domian = isset($site['apiurl'])?$site['apiurl']:'';
if(isset($site['apiurl'])&&$site['apiurl']){
    Route::domain($domian, function(){
        // 动态注册域名的路由规则
        Route::rule('/', 'control/index/index');
        Route::rule('index', 'control/index/index');
        Route::rule('cloudapi.asp', 'api/xingwai/main');
        Route::rule('vpsadm/login.asp', 'api/xingwai/panel');
        Route::rule('checkvpsname.asp', 'api/xingwai/checkvpsname');
        Route::rule('yvsy', 'api/Yiduiyi/main');
    });
}
Route::rule('cloudapi.asp', 'api/xingwai/main');
Route::rule('login.asp', 'api/xingwai/panel');
Route::rule('checkvpsname.asp', 'api/xingwai/checkvpsname');
Route::rule('yvsy', 'api/Yiduiyi/main');


Route::post('virtual','api/virtual/create_host');
Route::delete('virtual/:id','api/virtual/remove_host');
Route::put("virtual/:id",'api/virtual/update_host');
Route::get("virtual_reset_system/:id/:templateid",'api/virtual/reset_os');
Route::get("area",'api/virtual/area');
Route::get("virtual_monitoring/:id",'api/virtual/monitoring_host');
Route::get('virtual/:id','api/virtual/host_info');

Route::post('nat_acl','api/virtual/nat_acl_add');
Route::put('nat_acl/:virtual_id','api/virtual/nat_acl_edit');
Route::delete('nat_acl/:id','api/virtual/nat_acl_del');
Route::get('nat_acl/:virtual_id','api/virtual/nat_acl_list');

Route::post('backups','api/virtual/backups_add');
Route::delete('backups/:id','api/virtual/backups_del');
Route::get('backups/:id/edit','api/virtual/backups_restore');
Route::get('backups/:virtual_id','api/virtual/backups_list');
Route::put('backups/:virtual_id','api/virtual/backups_edit');

Route::post('snapshot','api/virtual/snapshot_add');
Route::delete('snapshot/:id','api/virtual/snapshot_del');
Route::get('snapshot/:id/edit','api/virtual/snapshot_restore');
Route::get('snapshot/:virtual_id','api/virtual/snapshot_list');
Route::put('snapshot/:virtual_id','api/virtual/snapshot_edit');

Route::get('virtual_power/:virtual_id/:type','api/virtual/virtual_power');

Route::get('virtual_pause/:virtual_id','api/virtual/virtual_pause');
Route::get('virtual_restore_pause/:virtual_id','api/virtual/virtual_restore_pause');


Route::get('mirror_image','api/virtual/mirror_image');

Route::get('virtual_run_status/:virtual_id','api/virtual/mirror_image');

Route::put('virtual_reset_password/:virtual_id','api/virtual/virtual_reset_password');

Route::get('virtual_link_vnc/:virtual_id','api/virtual/virtual_link_vnc');
Route::get('virtual_link_vnc_view/:virtual_id/:vnc_token','api/virtual/virtual_link_vnc_view');

Route::post('security_group','api/virtual/security_group_add');
Route::put('security_group/:id','api/virtual/security_group_edit');
Route::delete('security_group/:id','api/virtual/security_group_del');
Route::get('security_group/:userid','api/virtual/security_group_list');
Route::get('security_group_acl/:gid','api/virtual/security_group_acl_list');
Route::post('security_group_acl','api/virtual/security_group_acl_add');
Route::delete('security_group_acl/:id','api/virtual/security_group_acl_del');
Route::get('security_group/:virtual_id/edit','api/virtual/security_group_cur');
Route::post('security_group_apply/:gid','api/virtual/security_group_apply');

Route::get('cd_rom','api/virtual/cd_rom');








//Route::get('/api/virtual');api/
