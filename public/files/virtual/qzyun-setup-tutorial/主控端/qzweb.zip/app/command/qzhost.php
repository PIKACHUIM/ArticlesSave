<?php
declare (strict_types = 1);

namespace app\command;

use app\common\service\Ecs;
use app\common\service\HostSite;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

class qzhost extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('qzhost')
            ->setDescription('the qzhost command');
    }

    //检查到期 暂定
    //更新主机流量
    //到期删除
    protected function execute(Input $input, Output $output)
    {
        // 指令输出
        HostSite::updateTrafficList();
        HostSite::updateQuotaUsedList();

        HostSite::updateMysqlQuota();
        HostSite::updateMssqlQuota();

        HostSite::check_host_overdue();

        //到期处理
        $output->writeln('qzhost');
    }
}
