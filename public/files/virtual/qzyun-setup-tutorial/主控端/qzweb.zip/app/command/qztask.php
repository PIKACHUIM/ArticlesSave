<?php
declare (strict_types = 1);

namespace app\command;

use app\common\service\Ecs;
use think\console\Command;
use think\console\Input;
use think\console\input\Argument;
use think\console\input\Option;
use think\console\Output;

class qztask extends Command
{
    protected function configure()
    {
        // 指令配置
        $this->setName('qztask')
            ->setDescription('the qztask command');
    }

    //检查到期 暂定
    //更新主机流量
    //到期删除
    protected function execute(Input $input, Output $output)
    {
        // 指令输出
        Ecs::network_flow_host();
        Ecs::set_network_state_host();
        Ecs::check_overdue();
        Ecs::do_overdue();
        $output->writeln('qztask');
    }
}
