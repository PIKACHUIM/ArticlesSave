<?php
declare (strict_types = 1);

namespace app\common\model;

use qzcloud\Baremetal;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalBusiness extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按名称查找
        if ($name = input("name")) {
            $where[] = ["name", "like", "%" . $name . "%"];
        }

        if ($ip = input("ip")) {
            $BaremetalIp = new BaremetalIp();
            $ipList = $BaremetalIp->where([["ip", "like", "%" . $ip . "%"],["host_id", ">",0]])->select();

            if (!empty($ipList)){
                $idList = array_column($ipList->toArray(),'host_id');
                $where[] = ['h.id','in',$idList];
            }else{
                $where[] = ['h.id','<',0];
            }
        }

        $start_time = input('get.start_time');
        $end_time = input('get.end_time');

        if(!empty($start_time)){
            $where[] = ["a.end_time", ">=", $start_time." 00:00:00"];
        }

        if(!empty($end_time)){
            $where[] = ["a.end_time", "<=", $end_time." 23:59:59"];
        }

        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'baremetal_host h', 'a.host_id = h.id')
            ->leftJoin($prefix . 'baremetal_seat b', 'h.seat_id = b.id')
            ->leftJoin($prefix . 'baremetal_cabinet c', 'b.cabinet_id = c.id')
            ->leftJoin($prefix . 'servers_area d', 'c.area_id = d.id')
            ->field('a.*,h.state as host_state,h.uuid,h.name,h.id as host_id,h.host_name,h.type,h.cpu,h.memory,h.hard_disks,h.bandwidth,h.os_name,h.ipnum,h.area_id,h.cabinet_id,h.seat_id,h.ipmi_host,h.ipmi_user,h.ipmi_passwd,h.pxe_mac,h.node_id,CONCAT(b.number,"-",b.node) as seat_number,b.node as seat_node,c.number as seat_cabinet,d.area_name as area_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }



}

