<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class BaremetalCabinet extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按机会编号查找
        if ($number = input("number")) {
           $where[] = ["number", "like", "%" . $number . "%"];
        }

        //按查找
        if ($state = input("state")) {
           $where[] = ["state", "like", "%" . $state . "%"];
        }
        //$list = self::order('id','desc')->where($where)->paginate($limit);
        //按属所区域id查找
        if ($area_name = input("area_name")) {
            $where[] = ["c.area_name", "like", "%" . $area_name . "%"];
        }

        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_area c', 'a.area_id = c.id')
                ->field('a.*,c.area_name as area_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeDelete($data){
        $seatmodel = new BaremetalSeat();
        $info = $seatmodel->where(['cabinet_id'=>$data['id']])->find();
        if(!empty($info)){
            throw new \Exception('您不能删除该机柜，请先删除机柜下面的机位');
        }
    }
}
