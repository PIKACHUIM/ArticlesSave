<?php
declare (strict_types = 1);

namespace app\common\model;

use app\common\util\MacAddress;
use app\common\util\QzcloudTool;
use think\Exception;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalHost extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
        //按名称查找
        if ($name = input("name")) {
           $where[] = ["name", "like", "%" . $name . "%"];
        }

        if ($uuid = input("uuid")) {
            $where[] = ["uuid", "like", "%" . $uuid . "%"];
        }

        if ($area_id = input("area_id")) {
            $where[] = ["a.area_id", "=",$area_id ];
        }
        if ($allocation = input("allocation")) {
            $where[] = ["a.allocation", "=",$allocation ];
        }

        if ($ip = input("ip")) {
            $BaremetalIp = new BaremetalIp();
            $ipList = $BaremetalIp->where([["ip", "like", "%" . $ip . "%"],["host_id", ">",0]])->select();

            if (!empty($ipList)){
               $idList = array_column($ipList->toArray(),'host_id');
               $where[] = ['a.id','in',$idList];
            }else{
                $where[] = ['a.id','<',0];
            }
        }

        //$list = self::order('id','desc')->where($where)->paginate($limit);
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'baremetal_seat b', 'a.seat_id = b.id')
            ->leftJoin($prefix . 'baremetal_cabinet c', 'b.cabinet_id = c.id')
            ->leftJoin($prefix . 'servers_area d', 'c.area_id = d.id')
            ->field('a.*,CONCAT(b.number,"-",b.node) as seat_number,b.node as seat_node,c.number as seat_cabinet,d.area_name as area_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeInsert($data)
    {
        $info = self::where(['seat_id'=>$data['seat_id']])->find();
        if (!empty($info)){
            throw new  Exception('机位被占用');
        }
        $uuid =  QzcloudTool::getUuid();
        $data['uuid'] = $uuid;
        $data['pxe_mac'] =str_replace('-',':',$data['pxe_mac']) ;

        $info =self::where(['pxe_mac'=>$data['pxe_mac']])->find();
        if ($info){
            throw new  Exception('pxe_mac已存在'.$info['uuid']);
        }
        $info1 =self::where(['ipmi_host'=>$data['ipmi_host']])->find();
        if ($info1){
            throw new  Exception('ipmi_host已存在'.$info1['uuid']);
        }

        //反写机位
        $seatModel = new BaremetalSeat();
        $info = $seatModel->where(['isused'=>0,'id'=>$data['seat_id']])->find();
        if(empty($info)){
            throw new  Exception('未找到可用机位');
        }
        $gid = explode(',',$data['ip_group_id']);
        $baremetalModel = new BaremetalIp();
        $info = $baremetalModel->where(['ip'=>$data['ip'],'state'=>1,'disable'=>0])->whereIn('gid',$gid)->find();
        if (empty($info)){
            throw new  Exception('设置IP错误，确保IP在可选ip组里面，并且ip未被占用');
        }

        $info = self::where(['switch_id'=>$data['switch_id'],'switch_port'=>$data['switch_port']])->find();
        if (empty($info)){
            throw new  Exception('来晚了一步，交换机端口被占用');
        }

        $baremetalModel->whereIn('gid',$gid)->where(['state'=>1,'disable'=>0,'ip'=>$data['ip']])->save(['host_id'=>0,'state'=>2]);
        $seatModel->update(['isused'=>1],['id'=>$data['seat_id']]);
    }

    public static function onAfterInsert(Model $model)
    {
        $baremetalModel = new BaremetalIp();
        $baremetalModel->where(['ip'=>$model['ip']])->save(['host_id'=>$model['id'],'state'=>2]);

        $switch_port = new BaremetalSwitchPort();
        $switch_port->save(
            [
                'cabinet_id'=>$model['cabinet_id'],
                'switch_id'=>$model['switch_id'],
                'port'=>$model['switch_port'],
                'host_id'=>$model['id'],
                'vlan_id'=>$model['vlan_id'],
                'in_bw'=>$model['bandwidth_in'],
                'out_bw'=>$model['bandwidth'],
                'mac'=>$model['pxe_mac'],
            ]
        );
    }

    public static function onBeforeDelete($data)
    {
        //反写机位
        $seatModel = new BaremetalSeat();
        $seatModel->update(['isused'=>0],['id'=>$data['seat_id']]);

        //删除分配ip

        $baremetalModel = new BaremetalIp();
        $baremetalModel->where(['host_id'=>$data['id']])->save(['host_id'=>0,'state'=>1]);

        $switch_port = new BaremetalSwitchPort();
        $switch_port->where(['host_id'=>$data['id']])->delete();

        //业务分配里面 要检查，存在不能删除
        $businessModel = new BaremetalBusiness();
        $info = $businessModel->where(['host_id'=>$data['id']])->find();
        if (!empty($info)){
            throw new  Exception('请先删除关联业务');
        }
    }

    public static function onBeforeUpdate($data)
    {
        $info = self::where(['id'=>$data['id']])->find();
        $data['pxe_mac'] =str_replace('-',':',$data['pxe_mac']) ;

        $switch = self::where(['switch_id'=>$data['switch_id'],'switch_port'=>$data['switch_port']])->find();
        if ($switch['id']!=$data['id']){
            throw new  Exception('来晚了一步，交换机端口被占用');
        }

        $switch_port = new BaremetalSwitchPort();
        $switch_port->where(['host_id'=>$data['id']])->delete();

       if ($info['seat_id']!=$data['seat_id']){
           $seatModel = new BaremetalSeat();
           $info = $seatModel->where(['isused'=>1],['id'=>$data['seat_id']])->find();
           if(!empty($info)){
               throw new  Exception('机位被占用');
           }

           $seatModel->update(['isused'=>0],['id'=>$info['seat_id']]);
           $seatModel->update(['isused'=>1],['id'=>$data['seat_id']]);

           if($info['ip']!=$data['ip']){
               $gid = explode(',',$data['ip_group_id']);
               $baremetalModel = new BaremetalIp();
               $info = $baremetalModel->where(['ip'=>$data['ip'],'state'=>1,'disable'=>0])->whereIn('gid',$gid)->find();
               if (empty($info)){
                   throw new  Exception('设置IP错误，确保IP在可选ip组里面，并且ip未被占用');
               }
               $baremetalModel->whereIn('gid',$gid)->where(['state'=>1,'disable'=>0,'ip'=>$data['ip']])->save(['host_id'=>0,'state'=>2]);
               $baremetalModel->where(['ip'=>$info['ip']])->save(['host_id'=>0,'state'=>1]);
           }
       }
    }

    public static function onAfterUpdate(Model $model)
    {
        $switch_port = new BaremetalSwitchPort();
        $switch_port->save(
            [
                'cabinet_id'=>$model['cabinet_id'],
                'switch_id'=>$model['switch_id'],
                'port'=>$model['switch_port'],
                'host_id'=>$model['id'],
                'vlan_id'=>$model['vlan_id'],
                'in_bw'=>$model['bandwidth_in'],
                'out_bw'=>$model['bandwidth'],
                'mac'=>$model['pxe_mac'],
            ]
        );
    }

}
