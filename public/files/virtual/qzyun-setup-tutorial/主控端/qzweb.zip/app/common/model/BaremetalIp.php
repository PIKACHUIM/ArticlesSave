<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class BaremetalIp extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按ip查找
               if ($ip = input("ip")) {
                   $where[] = ["ip", "like", "%" . $ip . "%"];
               }

               if ($state = input("state")) {
                   $where[] = ["state", "=",$state];
               }

                //按查找
                if ($host_name = input("host_name")) {
                    $where[] = ["host_name", "like", "%" . $host_name . "%"];
                }

                //按查找
                if ($gid = input("gid")) {
                    $where[] = ["gid", "=", $gid];
                }

                if ($disable = input("disable")) {
                    $where[] = ["disable", "=",$disable];
                }
        $list = self::order('id','desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeDelete($data)
    {

    }
}
