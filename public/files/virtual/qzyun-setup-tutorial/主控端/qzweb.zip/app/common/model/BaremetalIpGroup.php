<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Exception;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalIpGroup extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按ip查找
               if ($name = input("name")) {
                   $where[] = ["name", "like", "%" . $name . "%"];
               }
        $list = self::order('id','desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeDelete($data)
    {
       $count =  (new BaremetalIp())->where(['gid'=>$data['id']])->count();
       if($count>0){
           throw  new Exception('请先删除该分组下的IP');
       }
    }
}
