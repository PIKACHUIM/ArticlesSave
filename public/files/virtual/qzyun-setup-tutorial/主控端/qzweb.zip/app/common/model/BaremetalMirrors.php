<?php
declare (strict_types = 1);

namespace app\common\model;

use qzcloud\Baremetal;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalMirrors extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
        $list = self::order('id','desc')->where($where)->paginate($limit);
        $nodeM = new BaremetalNode();
        $nodeList = $nodeM->select();
        $nodeListArr =[];
        $list1 = $list->items();
        if($nodeList!=null){
            $nodeListArr =  array_column($nodeList->toArray(),null,'id');
        }

        foreach ($list1 as  $k=>$v){
            $node = explode(',',$v['node']);
            foreach ($node as $k2=>$v2){
                if(empty($v2)){
                    continue;
                }
                if(isset($nodeListArr[$v2])){
                    $list1[$k]['node_name'] .= $nodeListArr[$v2]['name'].",";
                }
            }
            if(isset( $list1[$k]['node_name'])){
                $list1[$k]['node_name'] = trim($list1[$k]['node_name'],',');
            }else{
                $list1[$k]['node_name'] = '';
            }

        }

        return ['code'=>0,'data'=>$list1,'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getRemoteList(){
        $Baremetal = new Baremetal();

        $limit = input('get.limit',10);
        $page = input('get.page',1);

        $result = $Baremetal->remoteMirrors();
        $data = $result['data'];
        $count = count($result['data']);
        $start = ($page-1)*$limit;
        $pageC = array_slice($data,$start,$limit);
        return ['code'=>0,'data'=>$pageC,'extend'=>['count' =>$count, 'limit' => $limit]];
    }

    public static function getAllController($uid){
        $nodeModel = new BaremetalNode();
        $mirrorsDetaiModel = new BaremetalMirrorsDetail();
        $list = $nodeModel->where(['state'=>1])->select();
        foreach ($list as $k=>$v){
            $importImage = $mirrorsDetaiModel->where(['uuid'=>$uid,'node_id'=>$v['id']])->find();
            $v['import_state'] = 0;
            if($importImage){
                $v['import_state'] = $importImage['state'] ;
            }
            $list[$k] = $v;
        }
        return $list;
    }

    public static function getDetailList()
    {
        $limit = input('get.limit');
        $state = input('get.state');
        $nodeid = input('get.nodeid');
        $where =[];
        if (!empty($state)){
            $where['state'] = $state;
        }
        if (!empty($nodeid)){
            $where['node_id'] = $nodeid;
        }

        $model = new BaremetalMirrorsDetail();
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = $model->order('state','asc')->alias('as a')
            ->leftJoin($prefix . 'baremetal_mirrors b', 'a.mirrors_id = b.id')
            ->where($where)
            ->field('a.id,a.node_id,a.state,a.create_time,b.os_index,b.os_type,b.os_name')
            ->paginate($limit);

        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getListAll($param)
    {
        $state = empty($param['state'])?'':$param['state'];
        $nodeid = empty($param['node_id'])?'':$param['node_id'];
        $id = empty($param['id'])?'':$param['id'];
        $where =[];
        if (!empty($state)){
            $where['state'] = $state;
        }
        if (!empty($nodeid)){
            $where['node_id'] = $nodeid;
        }
        if (!empty($id)){
            $where['a.id'] = $id;
        }
        $model = new BaremetalMirrorsDetail();
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = $model->order('state','asc')->alias('as a')
            ->leftJoin($prefix . 'baremetal_mirrors b', 'a.mirrors_id = b.id')
            ->where($where)
            ->field('a.id,a.node_id,a.state,a.create_time,b.os_type,b.os_index,
            b.os_name,b.os_ver,b.install_key,b.os_lang,b.os_root,b.os_passwd,
            b.os_port,b.os_timezone,b.is_desktop,b.package,b.install_script,b.install_source,
            b.source_type,b.os_partition,b.os_drive_dir,b.diy_command,a.os_dir')
            ->select();

        return ['code'=>0,'data'=>empty($list)?[]:$list->toArray()];
    }
}
