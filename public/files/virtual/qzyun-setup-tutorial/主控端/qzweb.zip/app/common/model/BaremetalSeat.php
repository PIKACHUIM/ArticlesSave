<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Exception;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalSeat extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按机柜查找
               if ($cabinet_number = input("cabinet_number")) {
                   $where[] = ["c.number", "like", "%" . $cabinet_number . "%"];
               }
               //按编号1-48查找
               if ($number = input("number")) {
                   $where[] = ["a.number", "like", "%" . $number . "%"];
               }
               //按查找
               if ($area_name = input("area_name")) {
                   $where[] = ["area_name", "like", "%" . $area_name . "%"];
               }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'baremetal_cabinet c', 'a.cabinet_id = c.id')
            ->leftJoin($prefix . 'servers_area b', 'c.area_id = b.id')
            ->field('a.*,b.area_name ,c.number as cabinet_number')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getInfoById($id){
        $where['a.id'] = $id;
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'baremetal_cabinet c', 'a.cabinet_id = c.id')
            ->leftJoin($prefix . 'servers_area b', 'c.area_id = b.id')
            ->field('a.*,b.area_name ,c.number as cabinet_number')->where($where)->find();
        if(empty($info))return [];
        return $info;
    }


    public static function onBeforeInsert($data)
    {
        $info = self::where(['number'=>$data['number'],'node'=>$data['node'],'cabinet_id'=>$data['cabinet_id']])->find();
        if (!empty($info)){
            throw new  Exception('请不要重复添加');
        }
    }

    public static function onBeforeDelete($data)
    {
       $info =  (new BaremetalHost())->where(['seat_id'=>$data['id']])->find();
       if(!empty($info)){
           throw new  Exception('该机位被占用，请先删除资产');
       }
    }

    public static function onBeforeUpdate($data)
    {
        $info = self::find($data['id']);
        if($info['number']==$data['number']&&$info['node']==$data['node']&&$info['cabinet_id']==$data['cabinet_id']){
            return true;
        }
        $info1 = self::where(['number'=>$data['number'],'node'=>$data['node']])->find();
        if (!empty($info1)){
            throw new  Exception('请不要重复添加');
        }
    }
}
