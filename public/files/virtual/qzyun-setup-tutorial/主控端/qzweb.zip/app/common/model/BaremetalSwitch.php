<?php
declare (strict_types = 1);

namespace app\common\model;

use app\common\util\QzcloudTool;
use think\Exception;
use think\facade\Db;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalSwitch extends Model
{
    use SoftDelete;
     protected $deleteTime = false;

    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按名称查找
               if ($name = input("a.name")) {
                   $where[] = ["name", "like", "%" . $name . "%"];
               }
               //按所在机房查找
               if ($area_id = input("area_id")) {
                   $where[] = ["area_id", "like", "%" . $area_id . "%"];
               }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'servers_area b', 'a.area_id = b.id')
            ->leftJoin($prefix . 'baremetal_switch_model c', 'a.model_id = c.id')
            ->leftJoin($prefix . 'baremetal_cabinet d', 'a.cabinet_id = d.id')
            ->field('a.*,b.area_name,c.switch_name,d.number')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getInfoById($id){
        $where['a.id'] = $id;
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'servers_area b', 'a.area_id = b.id')
            ->field('a.*,b.area_name')->where($where)->find();
        if(empty($info))return [];
        return $info;
    }

    public static function onBeforeDelete($data)
    {
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info = Db::table($prefix.'baremetal_switch_port')->where(['switch_id'=>$data['id']])->find();
        if(!empty($info)){
            throw new  Exception('交换机被物理机使用无法删除'); //cloud_baremetal_switch_port
        }
    }

    public static function onBeforeInsert($data)
    {
        $data['passwd'] = QzcloudTool::encrypt($data['passwd'],'qzsystem123');
    }

    public static function onBeforeUpdate($data)
    {
        $data['passwd'] = QzcloudTool::encrypt($data['passwd'],'qzsystem123');
    }

    public static function onAfterUpdate(Model $model)
    {

    }
    public static function onAfterInsert(Model $model)
    {

    }

    public static function onAfterRead(Model $model)
    {
        $model['passwd'] = QzcloudTool::decrypt($model['passwd'],'qzsystem123');
    }
}
