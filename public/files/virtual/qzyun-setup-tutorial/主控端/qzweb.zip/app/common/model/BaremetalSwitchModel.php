<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Exception;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalSwitchModel extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
     public static $osType = [
         'windows'=>'windows',
         'centos'=>'centos',
         'debian'=>'debian',
         'ubuntu'=>'ubuntu',
         'other'=>'other',
     ];
    public static $osPartition = [
        '/boot'=>'/boot',
        '/'=>'/',
        'swap'=>'swap',
    ];
    public static $osLinixPartitionFormat = [
        'ext4'=>'ext4',
        'xfs'=>'xfs',
        'swap'=>'swap',
    ];
    public static $osWindowsPartitionFormat = [
        'NTFS'=>'NTFS',
    ];
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按名称查找
               if ($name = input("a.name")) {
                   $where[] = ["name", "like", "%" . $name . "%"];
               }
               //按所在机房查找
               if ($area_id = input("area_id")) {
                   $where[] = ["area_id", "like", "%" . $area_id . "%"];
               }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'servers_area b', 'a.area_id = b.id')
            ->field('a.*,b.area_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getInfoById($id){
        $where['a.id'] = $id;
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info = self::order('id', 'desc')->alias('as a')
            ->leftJoin($prefix . 'servers_area b', 'a.area_id = b.id')
            ->field('a.*,b.area_name')->where($where)->find();
        if(empty($info))return [];
        return $info;
    }

    public static function onBeforeDelete($data)
    {
        $info =  (new BaremetalHost())->where(['node_id'=>$data['id']])->find();
        if(!empty($info)){
            throw new  Exception('请先删除资产');
        }
    }

    public static function onBeforeInsert($data)
    {
        $iprange =  explode('-',$data['iprange']);

        if (count($iprange)!=2){
            throw new  Exception('分配IP段错误，x.x.x.开始IP-x.x.x.结束数字，里面不能包涵网关');
        }
        $start = $iprange[0];
        $start = explode('.',$start);

        $end = $iprange[1];
        $end = explode('.',$end);

        if (count($start)!=4){
            throw new  Exception('分配IP段错误，x.x.x.开始IP-x.x.x.结束数字，里面不能包涵网关');
        }
        if (count($end)!=4){
            throw new  Exception('分配IP段错误，x.x.x.开始IP-x.x.x.结束数字，里面不能包涵网关');
        }
    }

    public static function onBeforeUpdate($data)
    {
        $iprange =  explode('-',$data['iprange']);

        if (count($iprange)!=2){
            throw new  Exception('分配IP段错误，x.x.x.开始IP-x.x.x.结束数字，里面不能包涵网关');
        }
        $start = $iprange[0];
        $start = explode('.',$start);

        $end = $iprange[1];
        $end = explode('.',$end);

        if (count($start)!=4){
            throw new  Exception('分配IP段错误，x.x.x.开始IP-x.x.x.结束数字，里面不能包涵网关');
        }
        if (count($end)!=4){
            throw new  Exception('分配IP段错误，x.x.x.开始IP-x.x.x.结束数字，里面不能包涵网关');
        }
    }

    public static function onAfterUpdate(Model $model)
    {
        //调用节点初始化
        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $model['id'];
        if (empty($node_id)){
            throw new Exception('暂不支持该功能');
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            throw new Exception('暂不支持该功能');
        }
        $baremetalService = new \qzcloud\Baremetal();
        $result = $baremetalService->initNode(
            $model,$node);
        if ($result['code']!=200){
            throw new Exception('节点异常');
        }

    }
    public static function onAfterInsert(Model $model)
    {
        //调用节点初始化
        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $model['id'];
        if (empty($node_id)){
            throw new Exception('暂不支持该功能');
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            throw new Exception('暂不支持该功能');
        }
        $baremetalService = new \qzcloud\Baremetal();
        $result = $baremetalService->initNode(
            $model,$node);
        if ($result['code']!=200){
            throw new Exception('节点异常');
        }
    }
}
