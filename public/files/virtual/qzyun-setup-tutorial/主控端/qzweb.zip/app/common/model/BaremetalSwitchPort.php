<?php
declare (strict_types = 1);

namespace app\common\model;

use app\common\util\QzcloudTool;
use think\Exception;
use think\facade\Db;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalSwitchPort extends Model
{
    use SoftDelete;
     protected $deleteTime = false;


}
