<?php
declare (strict_types = 1);

namespace app\common\model;

use app\common\util\QzcloudTool;
use think\Exception;
use think\facade\Db;
use think\Model;
use think\model\concern\SoftDelete;
class BaremetalSwitchTemplate extends Model
{
    use SoftDelete;
     protected $deleteTime = false;

    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按名称查找
        if ($name = input("name")) {
            $where[] = ["name", "like", "%" . $name . "%"];
        }

        $list = self::order('id', 'desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getInfoById($id){
        $where['a.id'] = $id;
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info = self::order('id', 'desc')->alias('as a')
            ->field('a.*')->where($where)->find();
        if(empty($info))return [];
        return $info;
    }


    public static function onBeforeDelete($data)
    {
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info = Db::table($prefix.'baremetal_switch')->where(['template_id'=>$data['id']])->find();
        if(!empty($info)){
            throw new  Exception('模版被交换机使用无法删除');
        }
    }

    public static function onAfterUpdate(Model $model)
    {

    }
    public static function onAfterInsert(Model $model)
    {

    }

}
