<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class HostSite extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
     public static $netver =[
         2=>['module'=>'Classic','net_ver'=>'v2.0','remark'=>'ASP.Net2.0(经典)'],
         3=>['module'=>'Integrated','net_ver'=>'v2.0','remark'=>'ASP.Net2.0(集成)'],
         4=>['module'=>'Classic','net_ver'=>'v4.0','remark'=>'ASP.Net4.0(经典)'],
         5=>['module'=>'Integrated','net_ver'=>'v4.0','remark'=>'ASP.Net4.0(集成)'],
     ];

    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按点站名称查找
               if ($site_name = input("site_name")) {
                   $where[] = ["site_name", "like", "%" . $site_name . "%"];
               }
               //按站点域名查找
               if ($domain = input("domain")) {
                   $where[] = ["domain", "like", "%" . $domain . "%"];
               }
               //按到期时间查找
               $start = input("get.end_time-start");
               $end = input("get.end_time-end");
               if ($start && $end) {
                   $where[]=["end_time","between",[$start,date("Y-m-d",strtotime("$end +1 day"))]];
               }
        $list = self::order('id','desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onAfterRead($data)
    {
        if(!empty($data["buy_time"]))$data["buy_time"] = substr($data["buy_time"],0,10);
        if(!empty($data["end_time"]))$data["end_time"] = substr($data["end_time"],0,10);
        if(!empty($data["domain"]))$data["domain"] = trim($data["domain"],',');
        if(!empty($data["domain"]))$data["domain_show"] = str_replace(',',"\n",$data["domain"]);
        if(!empty($data["ip_security"]))$data["ip_security_show"] = str_replace(',',"\n",$data["ip_security"]);
        $data['traffic_used'] =  round(($data['down_month_traffic_used']+ $data['up_month_traffic_used'])/1000000,1);
        if(!empty($data["ip_security"]))$data["ip_security_show"] = str_replace(',',"\n",$data["ip_security"]);
    }
}
