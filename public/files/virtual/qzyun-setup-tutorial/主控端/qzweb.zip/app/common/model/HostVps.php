<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class HostVps extends Model
{
    use SoftDelete;
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'datetime';
    protected $dateFormat="Y-m-d H:i:s";
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $ip= input('get.ip');
        $start_time = input('get.start_time');
        $end_time = input('get.end_time');
        $host_name = input('get.host_name');
        $limit = input('get.limit');
        $nodeid = input('get.node_id');

        if(!empty($host_name)){
            $where[] = ["host_name", "=", $host_name];
        }

        if(!empty($start_time)){
            $where[] = ["end_time", ">=", $start_time];
        }

        if(!empty($end_time)){
            $where[] = ["end_time", "<=", $end_time];
        }
        if(!empty($ip)){
            $where[] = function ($query)use($ip){
                $query->where("ip='$ip' or add_ip like '%$ip%'");
            };
        }

        if(!empty($nodeid)){
            $where[] = ["node_id", "=", $nodeid];
        }

        $list = self::order('id','desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onAfterRead($data)
    {
        if(!empty($data["buy_time"]))$data["buy_time"] = substr($data["buy_time"],0,10);
        if(!empty($data["end_time"]))$data["end_time"] = substr($data["end_time"],0,10);
    }

}
