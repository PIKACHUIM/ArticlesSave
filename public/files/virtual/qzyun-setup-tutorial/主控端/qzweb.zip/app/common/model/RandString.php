<?php
/**
 * Created by PhpStorm.
 * Date: 2020/4/16
 * Time: 15:50
 */

namespace app\common\model;


use think\Model;

class RandString extends Model
{
    // 自动写入时间戳字段
    protected $autoWriteTimestamp = 'date';
    protected $dateFormat="Y-m-d H:i:s";
    // 定义时间戳字段名
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
}