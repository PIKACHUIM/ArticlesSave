<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class ServersArea extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
               //按区域名称查找
               if ($area_name = input("area_name")) {
                   $where[] = ["area_name", "like", "%" . $area_name . "%"];
               }
        $list = self::order('id','desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }


    public static function onBeforeDelete($data){
        $cabinetmodel = new BaremetalCabinet();
        $info = $cabinetmodel->where(['area_id'=>$data['id']])->find();
        if(!empty($info)){
            throw new \Exception('该机房存在机柜，请先删除机房下面的机柜');
        }
    }
}
