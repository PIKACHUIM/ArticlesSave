<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class ServersImageConfig extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
     public static $os_type = array(1=>'windows', 2=>'centos', 3=>'ubuntu', 4=>'debian',);
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
        $list = self::order('id','desc')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }
    public static function onAfterRead($data){
        $data["os_type_name"] = isset(self::$os_type[$data['os_type']])?self::$os_type[$data['os_type']]:'未知';
    }

    public static function onBeforeDelete($data){
        $id = $data['id'];
        $imageNodeModel = new ServersImageLine();
        $info = $imageNodeModel->where(['config_id'=>$id])->find();
        if($info){
            throw new \Exception('线路下已勾选该镜像');
        }

        $hostModel = new HostVps();
        $host = $hostModel->where(['os_name'=>$data['os_name']])->find();
        if($host){
            throw new \Exception('云主机在使用该镜像不能删除，您可以在线路里面设置该镜像不显示');
        }
    }
}
