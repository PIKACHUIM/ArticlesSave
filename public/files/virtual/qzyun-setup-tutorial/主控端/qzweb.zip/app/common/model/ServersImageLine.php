<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class ServersImageLine extends Model
{
    use SoftDelete;
     protected $deleteTime = false;

    // 获取列表
    public static function getAllList($param)
    {
        $where = [];
        if(isset($param['line_id'])){
            $where['a.line_id'] = $param['line_id'];
        }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_image_config c', 'a.config_id = c.id')
            ->field('c.*')->where($where)->select();
        return ['code' => 0, 'data' => $list->toArray()];
    }
}
