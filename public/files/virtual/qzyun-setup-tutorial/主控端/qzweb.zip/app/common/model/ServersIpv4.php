<?php
declare (strict_types = 1);

namespace app\common\model;

use app\common\util\MacAddress;
use think\Model;
use think\model\concern\SoftDelete;
class ServersIpv4 extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按ip地址查找
        if ($ip = input("ip")) {
           $where[] = ["a.ip", "like", "%" . $ip . "%"];
        }
        //按所属ip池查找
        if ($ip_pool_name = input("ip_pool_name")) {
           $where[] = ["c.pool_name", "like", "%" . $ip_pool_name . "%"];
        }

        if ($ip_pool_id= input("ip_pool_id")) {
            $where[] = ["c.id", "=", $ip_pool_id];
        }

        //按所属虚拟机标识查找
        if ($v_name = input("v_name")) {
           $where[] = ["a.v_name", "like", "%" . $v_name . "%"];
        }
        //按状态查询
        if ($state= input("state")) {
            $where[] = ["a.state", "=", $state];
        }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id','desc')->alias('as a')->leftJoin($prefix.'servers_ip_pool c', 'a.ip_pool_id = c.id')
            ->field('a.id,a.ip,a.netmask,a.gateway,a.mac,a.v_name,a.state,a.create_time,a.update_time,c.pool_name as ip_pool_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getPage()
    {
        $where = [];
        $limit = input('get.limit');

        //按ip地址查找
        if ($ip = input("ip")) {
            $where[] = ["a.ip", "like", "%" . $ip . "%"];
        }
        //按所属ip池查找
        if ($ip_pool_name = input("ip_pool_name")) {
            $where[] = ["c.pool_name", "like", "%" . $ip_pool_name . "%"];
        }
        //按所属虚拟机标识查找
        if ($v_name = input("v_name")) {
            $where[] = ["a.v_name", "like", "%" . $v_name . "%"];
        }
        //按状态查询
        if ($state= input("state")) {
            $where[] = ["a.state", "=", $state];
        }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('c.host_name,a.update_time','desc')->alias('as a')->leftJoin($prefix.'host_vps c', 'a.ip = c.ip and a.v_name=c.host_name')
            ->field('a.*,c.host_name,(case when c.host_name=a.v_name then 1 else 0 end) masterip')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeInsert($data)
    {
        $info = self::where(['ip'=>$data['ip']])->find();
        if($info){
            return false;
        }
        $mac = '';
        while (true){
            $mac =  MacAddress::generateMacAddress('public');
            if(self::where(['mac'=>$mac])->count()<1){
                break;
            }
        }
        $data['mac'] = $mac;
    }

}