<?php
declare (strict_types = 1);

namespace app\common\model;

use app\common\util\MacAddress;
use think\Model;
use think\model\concern\SoftDelete;
class ServersIpv4Private extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按查找
        if ($id = input("id")) {
           $where[] = ["id", "like", "%" . $id . "%"];
        }
        //按ip地址查找
        if ($ip = input("ip")) {
           $where[] = ["ip", "like", "%" . $ip . "%"];
        }
        //按掩码查找
        if ($netmask = input("netmask")) {
           $where[] = ["netmask", "like", "%" . $netmask . "%"];
        }
        //按网关查找
        if ($gateway = input("gateway")) {
           $where[] = ["gateway", "like", "%" . $gateway . "%"];
        }
        //按状态查询
        if ($state= input("state")) {
            $where[] = ["a.state", "=", $state];
        }

        //按所属虚拟机标识查找
        if ($v_name = input("v_name")) {
            $where[] = ["a.v_name", "like", "%" . $v_name . "%"];
        }

        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id','desc')->alias('as a')->leftJoin($prefix.'servers_ip_pool c', 'a.ip_pool_id = c.id')
            ->field('a.id,a.ip,a.netmask,a.gateway,a.mac,a.v_name,a.state,a.create_time,a.update_time,c.pool_name as ip_pool_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeInsert($data)
    {
        $info = self::where(['ip'=>$data['ip'],'ip_pool_id'=>$data['ip_pool_id']])->find();
        if($info){
            return false;
        }
        $mac = '';
        while (true){
            $mac =  MacAddress::generateMacAddress('private');
            if(self::where(['mac'=>$mac])->count()<1){
                break;
            }
        }
        $data['mac'] = $mac;
    }
}
