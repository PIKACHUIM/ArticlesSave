<?php
declare (strict_types=1);

namespace app\common\model;

use think\Collection;
use think\Model;
use think\model\concern\SoftDelete;

class ServersLine extends Model
{
    use SoftDelete;
    protected $deleteTime = false;

    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按线路名称查找
        if ($line_name = input("line_name")) {
            $where[] = ["a.line_name", "like", "%" . $line_name . "%"];
        }
        //按属所区域id查找
        if ($area_name = input("area_name")) {
            $where[] = ["a.area_id", "like", "%" . $area_name . "%"];
        }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_area c', 'a.area_id = c.id')
            ->field('a.*,c.area_name as area_name')->where($where)->paginate($limit);
        return ['code' => 0, 'data' => $list->items(), 'extend' => ['count' => $list->total(), 'limit' => $limit]];
    }

    // 获取列表
    public static function getAllList($param)
    {
        $where = [];
        if(isset($param['state'])){
            $where['a.state'] = $param['state'];
        }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_area c', 'a.area_id = c.id')
            ->field('a.*,c.area_name as area_name')->where($where)->select();
        return ['code' => 0, 'data' => $list->toArray()];
    }

    // 获取列表
    public static function getOne($id)
    {
        $where = [];
        $info = self::order('id', 'desc')->find($id);
        return ['code' => 0, 'data' => $info];
    }

    public static function onAfterInsert($data)
    {
        $line_image_use_arr = $data['line_image_use'];
        $line_image_use_arr = explode(',', $line_image_use_arr);

        // unset($ServersNode->data['node_image_use']);
        $imageConfModel = new ServersImageConfig();
        $imageListObj = $imageConfModel->whereIn('id', $line_image_use_arr)->select();

        $insert = $temp = [];
        foreach ($imageListObj as $key => $value) {
            $temp = [];
            $temp['os_name'] = $value['os_name'];
            $temp['line_id'] = $data['id'];
            $temp['config_id'] = $value['id'];
            $temp['os_type'] = $value['os_type'];
            $temp['sort'] = $value['sort'];
            $temp['remark'] = $value['remark'];
            $temp['limit_cpu'] = $value['limit_cpu'];
            $temp['file_name'] = $value['file_name'];
            $temp['limit_memory'] = $value['limit_memory'];
            $temp['create_time'] = date("Y-m-d H:i:s");
            $temp['update_time'] = date("Y-m-d H:i:s");
            $insert[] = $temp;
        }
        $imageLineModel = new ServersImageLine();
        $imageLineModel->insertAll($insert);
    }

    public static function onAfterUpdate($data){

        $line_image_use_arr=$data['line_image_use'];
        if(empty($line_image_use_arr)){
            return true;
        }
        $line_image_use_arr = explode(',', $line_image_use_arr);
        // unset($ServersNode->data['node_image_use']);
        $imageConfModel = new ServersImageConfig();
        //Collection

        $imageListObj = $imageConfModel->whereIn('id', $line_image_use_arr)->select();
        $imageList = $imageListObj->toArray();
        $postConfigObj = array_column($imageList,'id');

        $imageLineModel = new ServersImageLine();
        $oldImageNode = $imageLineModel->where(['line_id'=>$data['id']])->select();
        $oldNodeIdObj=[];
        if($oldImageNode){
            $oldImageNode = $oldImageNode->toArray();
            $oldNodeIdObj = array_column($oldImageNode,'config_id');
        }

        //新增
        $addArr = array_diff($postConfigObj,$oldNodeIdObj);

        $insert = $update = $del = $temp = [];
        foreach ($imageList as $key=>$value){
            $temp=[];
            if(!in_array($value['id'],$addArr)){
                continue;
            }
            $temp['os_name'] = $value['os_name'];
            $temp['line_id'] = $data['id'];
            $temp['config_id'] = $value['id'];
            $temp['os_type'] = $value['os_type'];
            $temp['sort'] = $value['sort'];
            $temp['remark'] = $value['remark'];
            $temp['limit_cpu'] = $value['limit_cpu'];
            $temp['file_name'] = $value['file_name'];
            $temp['limit_memory'] = $value['limit_memory'];
            $temp['create_time'] = date("Y-m-d H:i:s");
            $temp['update_time'] = date("Y-m-d H:i:s");
            $insert[]=$temp;
        }

        if($insert)$imageLineModel->insertAll($insert);

        //修改
        $updateArr = array_intersect($postConfigObj,$oldNodeIdObj);
        foreach ($imageList as $key=>$value){
            $temp=[];
            if(!in_array($value['id'],$updateArr)){
                continue;
            }
            $temp['os_name'] = $value['os_name'];
            $temp['line_id'] = $data['id'];
            $temp['config_id'] = $value['id'];
            $temp['os_type'] = $value['os_type'];
            $temp['sort'] = $value['sort'];
            $temp['remark'] = $value['remark'];
            $temp['limit_cpu'] = $value['limit_cpu'];
            $temp['file_name'] = $value['file_name'];
            $temp['limit_memory'] = $value['limit_memory'];
            $temp['update_time'] = date("Y-m-d H:i:s");
            $imageLineModel->update($temp,['line_id'=>$data['id'],'config_id'=>$value['id']]);
        }

        //删除
        $delArr = array_diff($oldNodeIdObj,$postConfigObj);
        foreach ($oldImageNode as $key=>$value){
            if(!in_array($value['config_id'],$delArr)){
                continue;
            }
            $del[]=$value['id'];
        }
        if($del)$imageLineModel->whereIn('id',$del)->delete();
    }

    public static function onAfterDelete($data){
        $imageNodeModel = new ServersImageLine();
        $imageNodeModel->where(['line_id'=>$data['id']])->delete();
    }

    public static function onBeforeDelete($data){
        $serversNodeModel = new ServersNode();
        $info = $serversNodeModel->where(['line_id'=>$data['id']])->find();
        if($info){
            throw new \Exception('有物理节点在该线路下不能删除，您可以暂停它');
        }

        $hostModel = new HostVps();
        $host = $hostModel->where(['line_id'=>$data['id']])->find();
        if($host){
            throw new \Exception('云主机在使用该线路不能删除，您可以暂停它');
        }

        $virNodeModel = new VirhostNode();
        $virNode = $virNodeModel->where(['line_id'=>$data['id']])->find();
        if($virNode){
            throw new \Exception('虚拟主机节点属于该线路您不能删除，您可以暂停它');
        }

    }
}
