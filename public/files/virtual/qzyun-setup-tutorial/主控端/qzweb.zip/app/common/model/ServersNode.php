<?php
declare (strict_types=1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;

class ServersNode extends Model
{
    use SoftDelete;
    protected $deleteTime = false;
    public static $node_type = array('hyper-v' => 'hyper-v', 'kvm' => 'kvm');

    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        //按线路id
        if ($line_id = input("line_id")) {
            $where[] = ["line_id", "=",$line_id ];
        }
        //按点节名称查找
        if ($node_name = input("node_name")) {
            $where[] = ["node_name", "like", "%" . $node_name . "%"];
        }
        //按点节名称查找
        if ($ip_pool_name= input("ip_pool_name")) {
            $where[] = ["ip_pool_name", "like", "%" . $ip_pool_name . "%"];
        }
        //按点节名称查找
        $state = input("state");
        if (is_numeric($state)) {
            $where[] = ["a.state", "=", $state];
        }

        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_line c', 'a.line_id = c.id')
            ->field('a.*,c.line_name')->where($where)->paginate($limit);
        return ['code' => 0, 'data' => $list->items(), 'extend' => ['count' => $list->total(), 'limit' => $limit]];
    }

    public static function getAllList($param)
    {
        $where = [];
        if(isset($param['state'])){
            $where['a.state'] = $param['state'];
        }
        if(isset($param['line_id'])){
            $where['a.line_id'] = $param['line_id'];
        }
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_line c', 'a.line_id = c.id')
            ->field('a.*,c.line_name')->where($where)->select();
        return ['code' => 0, 'data' => $list->toArray()];
    }

    public static function onBeforeInsert($data)
    {
        $ip_pool_name_str = $data['ip_pool_name'];
        $ip_pool_name_arr = explode('|', $ip_pool_name_str);

        //赋值
        // $ServersNode->data['area_name']=$area_name_arr[1];
        //$ServersNode->data['area_id']=$area_name_arr[0];
        $data['state'] = 1;
        $data['ip_pool_name'] = $ip_pool_name_arr[1];
        $data['ip_pool_id'] = $ip_pool_name_arr[0];
    }

    public static function onBeforeUpdate($data)
    {
        $ip_pool_name_str = $data['ip_pool_name'];
        $ip_pool_name_arr = explode('|', $ip_pool_name_str);
        if (count($ip_pool_name_arr) < 2) {
            return true;
        }
        //赋值
        // $ServersNode->data['area_name']=$area_name_arr[1];
        //$ServersNode->data['area_id']=$area_name_arr[0];
        $data['ip_pool_name'] = $ip_pool_name_arr[1];
        $data['ip_pool_id'] = $ip_pool_name_arr[0];
    }

    public static function onBeforeDelete($data){
        $hostModel = new HostVps();
        $host = $hostModel->where(['node_id'=>$data['id']])->find();
        if($host){
            throw new \Exception('云主机在使用该节点不能删除，您可以暂停它');
        }

    }
}
