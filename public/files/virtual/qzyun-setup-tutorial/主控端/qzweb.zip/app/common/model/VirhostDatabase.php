<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class VirhostDatabase extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');

        if ($dataname = input("dataname")) {
            $where[] = ["a.dataname", "=",$dataname];
        }

        if ($site_name = input("site_name")) {
            $where[] = ["c.site_name", "=",$site_name ];
        }

        $datatype = input("datatype");
        if (is_numeric($datatype)) {
            $where[] = ["a.datatype", "=", $datatype];
        }

        //按到期时间查找
        $start = input("get.end_time-start");
        $end = input("get.end_time-end");
        if ($start && $end) {
            $where[]=["a.end_time","between",[$start,date("Y-m-d",strtotime("$end +1 day"))]];
        }

        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'host_site c', 'a.site_id = c.id')
            ->field('a.*,c.site_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onAfterRead($data){
       $data['datatype_txt'] = $data['datatype']==1?'MYSQL':'MSSQL';
        if(!empty($data["buy_time"]))$data["buy_time"] = substr($data["buy_time"],0,10);
        if(!empty($data["end_time"]))$data["end_time"] = substr($data["end_time"],0,10);
    }
}
