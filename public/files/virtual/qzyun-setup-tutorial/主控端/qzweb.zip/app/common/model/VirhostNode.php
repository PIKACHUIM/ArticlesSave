<?php
declare (strict_types = 1);

namespace app\common\model;

use think\Model;
use think\model\concern\SoftDelete;
class VirhostNode extends Model
{
    use SoftDelete;
     protected $deleteTime = false;
    // 获取列表
    public static function getList()
    {
        $where = [];
        $limit = input('get.limit');
        
        //按点节名称查找
        if ($node_name = input("node_name")) {
           $where[] = ["node_name", "like", "%" . $node_name . "%"];
        }

        //按线路id
        if ($line_id = input("line_id")) {
            $where[] = ["line_id", "=",$line_id ];
        }
        //按点节名称查找
        $state = input("state");
        if (is_numeric($state)) {
            $where[] = ["a.state", "=", $state];
        }

        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $list = self::order('id', 'desc')->alias('as a')->leftJoin($prefix . 'servers_line c', 'a.line_id = c.id')
            ->field('a.*,c.line_name')->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function onBeforeInsert($data)
    {
        if(!empty($data['phpver']))$data['phpver'] = trim($data['phpver'],'.');
        if(!empty($data['phpver']))$data['phpver'] =  ','.$data['phpver'].',';
    }
    public static function onBeforeUpdate($data)
    {
        if(!empty($data['phpver']))$data['phpver'] = trim($data['phpver'],'.');
        if(!empty($data['phpver']))$data['phpver'] =  ','.$data['phpver'].',';
    }

    public static function onAfterRead($data){
        if(!empty($data['phpver']))$data['phpver'] = trim($data['phpver'],'.');
    }
}
