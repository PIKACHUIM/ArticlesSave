<?php

namespace app\common\model;

use think\Model;

class VncPort extends Model
{

    // 表名
    protected $name = 'vnc_port_vps';

}
