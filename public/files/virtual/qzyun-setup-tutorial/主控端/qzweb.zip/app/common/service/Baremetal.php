<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\BaremetalBusiness;
use app\common\model\BaremetalHost;
use app\common\model\BaremetalMirrors;
use app\common\model\ServersArea;
use app\common\model\Task;
use think\Exception;
use think\facade\Db;
use think\facade\Request;

class Baremetal
{

    public function startVnc($param){
        $hostModel = new \app\common\model\BaremetalHost();
        $info = $hostModel->where(['id'=>$param['hostid']])->find();
        try {
            if(empty($info)){
                throw new Exception('主机不存在');
            }
            $ipmi_host = $info['ipmi_host'];
            $ipmi_user = $info['ipmi_user'];
            $ipmi_passwd = $info['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $info['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $vnc = $baremetalService->startVnc(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);
            return $vnc;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage(),'data'=>[]];
        }
    }
    public function flushVnc($param){
        $hostModel = new \app\common\model\BaremetalHost();
        $info = $hostModel->where(['id'=>$param['hostid']])->find();
        try {
            if(empty($info)){
                throw new Exception('主机不存在');
            }
            $ipmi_host = $info['ipmi_host'];
            $ipmi_user = $info['ipmi_user'];
            $ipmi_passwd = $info['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $info['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $vnc = $baremetalService->flushVnc(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);
            return $vnc;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage(),'data'=>[]];
        }
    }
    public function installOS($param){
        try {
            $baremetaModel = new BaremetalHost();
            $hostid = $param['hostid'];
            $os_id = $param['os_id'];
            $password = $param['os_passwd'];
            $os_port = $param['os_port'];
            // $partition_default = $param['partition_default'];
            $disk_partition_type = isset($param['disk_partition_type'])?$param['disk_partition_type']:'';

            $host = $baremetaModel->find($hostid);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            if(in_array($host->state,[3,6,7])){
                return ['code'=>0,'msg'=>'当前状态不允许操作'];
            }

            if($host->admin_lock==1){
                return ['code'=>0,'msg'=>'管理员锁定状态不允许操作'];
            }

            $mount = $param['mount'];
            $size = $param['size'];
            $ext = $param['ext'];
            if(count($mount)!=count(array_unique($mount))){
                throw new Exception('挂载点重复');
            }

            if(count($mount)!=count($size)||count($mount)!=count($ext)){
                throw new Exception('配置异常，稍后重试~');
            }
            $empty = 0;
            $part = '';
            $extend = '';
            foreach ($mount as $k=>$v){
                $temp='';
                if(empty(trim($v,''))){
                    throw new Exception('挂载点/盘符不能有空项');
                }
                if($v!='swap'&&$ext[$k]=='swap'){
                    throw new Exception('非swap分区不能使用swap格式');
                }
                if(!empty($size[$k])&&!is_numeric($size[$k])){
                    throw new Exception('容量为空请为数字/或者填空');
                }
                if(empty(trim($size[$k],''))){
                    $empty++;
                }
                if($empty>1){
                    throw new Exception('只能存在一个剩余空间行');
                }

                if(empty($ext[$k])){
                    throw new Exception('格式不能为空');
                }
                $size_ = $size[$k];
                if(empty($size_)){
                    $size_ = 'extend';
                    $extend = "{$v}:{$ext[$k]}:$size_";
                }else{
                    $temp = "{$v}:{$ext[$k]}:$size_";
                }
                if(!empty($temp)){
                    $part=$part.','.$temp;
                }

            }
            $part = trim($part,',');
            $part = $part.','.$extend;
            $part = trim($part,',');

            //$nodelModel = new \app\common\model\BaremetalNode();
            //$node = $nodelModel->where(['id'=>$host['node_id']])->find();

            //镜像列表 可用的
            $mirrors = BaremetalMirrors::getListAll(['state'=>3,'node_id'=>$host['node_id'],'id'=>$os_id]);
            if (empty($mirrors)){
                throw new Exception('镜像不存在');
            }
            $mirrors = $mirrors['data'][0];
            if(!is_numeric($os_port)){
                throw new Exception('远程端口请填写数字');
            }
            Db::startTrans();

            //创建任务
            $taskid = self::addTask('installOS',$hostid);

            $host->state=3;
            $host->os_id=$mirrors['id'];
            $host->os_name=$mirrors['os_name'];
            $host->remote_port=$os_port;
            $host->reinstall_time = date("Y-m-d H:i:s");
            $host->os_password = $password;

            if ($mirrors['os_type']=='windows'){
                $host->disk_partition_type = $disk_partition_type;
                if($disk_partition_type==1){
                    $host->disk_partition_type = 1;
                }elseif ($disk_partition_type==2){
                    $host->disk_partition_type = 3;
                    $host->disk_partition=$part;
                }
            }else{
                $host->disk_partition_type = 5;
                $host->disk_partition=$part;
            }

            $host->save();

            //执行任务
            $cloudTask = new ExecuteTask();
            $res = $cloudTask->installOS($taskid);
            if($res['code']!=200){
                throw new  Exception($res['msg']);
            }
            Db::commit();
            return ['code'=>200,'msg'=>'success'];
        }catch (Exception $e){
            Db::rollback();
            return ['code'=>201,'msg'=>$e->getMessage()];
        }
    }

    public function rescue($param){
        try {
            $baremetaModel = new BaremetalHost();
            $hostid = $param['hostid'];
            $rescue_os_type = $param['rescue_os_type'];

            $host = $baremetaModel->find($hostid);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            if(in_array($host->state,[3,6,7])){
                return ['code'=>0,'msg'=>'当前状态不允许操作'];
            }

            if($host->admin_lock==1){
                return ['code'=>0,'msg'=>'管理员锁定状态不允许操作'];
            }

            $host->state = 6;
            $host->rescue_type=$rescue_os_type;
            $host->save();

            //执行任务
            $cloudTask = new ExecuteTask();
            //创建任务
            $taskid = self::addTask('rescue',$hostid);
            $res = $cloudTask->installOS($taskid);
            if($res['code']!=200){
                throw new  Exception($res['msg']);
            }
            Db::commit();
            return ['code'=>200,'msg'=>'success'];
        }catch (Exception $e){
            Db::rollback();
            return ['code'=>201,'msg'=>$e->getMessage()];
        }
    }

    public function systemPasswd($param){
        try {
            $baremetaModel = new BaremetalHost();
            $hostid = $param['hostid'];
            $password = $param['password'];

            $host = $baremetaModel->find($hostid);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            if(in_array($host->state,[3,6,7])){
                return ['code'=>0,'msg'=>'当前状态不允许操作'];
            }

            if($host->admin_lock==1){
                return ['code'=>0,'msg'=>'管理员锁定状态不允许操作'];
            }

            $host->os_password=$password;
            $host->state = 7;
            $host->save();

            //执行任务
            $cloudTask = new ExecuteTask();
            //创建任务
            $taskid = self::addTask('passwd',$hostid);
            $res = $cloudTask->installOS($taskid);
            if($res['code']!=200){
                throw new  Exception($res['msg']);
            }
            Db::commit();
            return ['code'=>200,'msg'=>'success'];
        }catch (Exception $e){
            Db::rollback();
            return ['code'=>201,'msg'=>$e->getMessage()];
        }
    }

    public function powerOn($id){
        try {
            $baremetaModel = new BaremetalHost();
            $host = $baremetaModel->find($id);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            $ipmi_host = $host['ipmi_host'];
            $ipmi_user = $host['ipmi_user'];
            $ipmi_passwd = $host['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $host['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $result = $baremetalService->powerOn(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);

            return $result;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }

    }

    public function powerOff($id){
        try {
            $baremetaModel = new BaremetalHost();
            $host = $baremetaModel->find($id);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            $ipmi_host = $host['ipmi_host'];
            $ipmi_user = $host['ipmi_user'];
            $ipmi_passwd = $host['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $host['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $result = $baremetalService->powerOff(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);

            return $result;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function restart($id){
        try {
            $baremetaModel = new BaremetalHost();
            $host = $baremetaModel->find($id);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            $ipmi_host = $host['ipmi_host'];
            $ipmi_user = $host['ipmi_user'];
            $ipmi_passwd = $host['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $host['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $result = $baremetalService->reset(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);

            return $result;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function runingStatus($id){
        try {
            $baremetaModel = new BaremetalHost();
            $host = $baremetaModel->find($id);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            if($host['state']==3){
                return ['code'=>200,'msg'=>'','data'=>['status'=>'重装系统中']];
            }elseif($host['state']==4){
                return ['code'=>200,'msg'=>'','data'=>['status'=>'重装系统失败']];
            }elseif($host['state']==5){
                return ['code'=>200,'msg'=>'','data'=>['status'=>'到期锁定']];
            }elseif($host['state']==6){
                return ['code'=>200,'msg'=>'','data'=>['status'=>'救援中']];
            }elseif($host['state']==7){
                return ['code'=>200,'msg'=>'','data'=>['status'=>'破解密码中']];
            }

            $ipmi_host = $host['ipmi_host'];
            $ipmi_user = $host['ipmi_user'];
            $ipmi_passwd = $host['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $host['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $result = $baremetalService->powerStatus(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);

            return $result;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function resetbmc($id){
        try {
            $baremetaModel = new BaremetalHost();
            $host = $baremetaModel->find($id);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            $ipmi_host = $host['ipmi_host'];
            $ipmi_user = $host['ipmi_user'];
            $ipmi_passwd = $host['ipmi_passwd'];
            if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
                throw new Exception('暂不支持该功能');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $host['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $result = $baremetalService->resetbmc(
                ['ipmi_host'=>$ipmi_host,
                    'ipmi_user'=>$ipmi_user,
                    'ipmi_passwd'=>$ipmi_passwd
                ],$node);

            return $result;
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public static function addTask($command,$where,$other=[]){
        try{
            $model = new Task();
            $data = ['command'=>$command,'param'=>$where,'create_time'=>date('Y-m-d H:i:s')];
            if($other){
                $data =array_merge($data,$other);
            }
            $res = $model->insert($data,true);
            return $res;
        }catch (Exception $E){
            throw new Exception($E->getMessage());
        }
    }
}
