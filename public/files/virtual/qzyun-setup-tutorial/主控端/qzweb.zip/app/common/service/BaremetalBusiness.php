<?php
declare (strict_types = 1);

namespace app\common\service;

use think\Exception;
use think\facade\Db;
use think\facade\Request;
use app\common\model\BaremetalBusiness as M;

class BaremetalBusiness
{

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'status' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Db::startTrans();
            //ip
            $BaremetalIp = new \app\common\model\BaremetalIp();
            $BaremetalIp->where(['host_id'=>$model['host_id']])->save(['host_id'=>'','state'=>1]);
            //资产
            $BaremetalHost = new \app\common\model\BaremetalHost();
            $BaremetalHost->where(['id'=>$model['host_id']])->save(['allocation'=>1,'allocation_msg'=>'']);
            $model->delete();
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }

    }

    // 批量删除
    public static function goBatchRemove($ids)
    {
        if (!is_array($ids)) return ['msg'=>'数据不存在','code'=>201];
        try{
            M::destroy($ids);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }


}
