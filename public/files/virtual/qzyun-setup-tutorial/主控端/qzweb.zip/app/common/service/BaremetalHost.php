<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\BaremetalBusiness;
use app\common\model\Task;
use app\common\util\QzcloudTool;
use think\Exception;
use think\facade\Db;
use think\facade\Request;
use app\common\model\BaremetalHost as M;
use app\common\validate\BaremetalHost as V;
use think\facade\Template;
use think\facade\View;
use think\tests\TestTemplate;

class BaremetalHost
{
    // 添加
    public static $fun=['installos'=>'安装系统','power'=>'电源管理','resetpasswd'=>'重设密码','vnc'=>'html5VNC','pe'=>'紧急救援'];
    public static function goAdd($data)
    {

        //验证
        $validate = new V;
        if(!$validate->scene('add')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {

            Db::startTrans();
            M::create($data);
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 编辑
    public static function goEdit($data,$id)
    {
        $data['id'] = $id;
        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {
            Db::startTrans();
            M::update($data);
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'status' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Db::startTrans();
            $model->delete();
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 批量删除
    public static function goBatchRemove($ids)
    {
        if (!is_array($ids)) return ['msg'=>'数据不存在','code'=>201];
        try{
            M::destroy($ids);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 获取列表
    public static function goRecycle()
    {
        if (Request::isPost()){
            $ids = Request::param('ids');
            if (!is_array($ids)) return ['msg'=>'参数错误','code'=>'201'];
            try{
                if(Request::param('type')){
                    $data = M::onlyTrashed()->whereIn('id', $ids)->select();
                    foreach($data as $k){
                        $k->restore();
                    }
                }else{
                    M::destroy($ids,true);
                }
            }catch (\Exception $e){
                return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
            }
            return ['msg'=>'操作成功'];
        }
        //按用户名
        $where = [];
        $limit = input('get.limit');

        //按名称查找
        if ($name = input("name")) {
            $where[] = ["name", "like", "%" . $name . "%"];
        }
        $list = M::onlyTrashed()->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    // 获取列表
    public static function goIPList($hostid)
    {
        //按用户名
        $where = [];
        $limit = input('get.limit');
        //按名称查找
        if ($ip = input("ip")) {
            $where[] = ["ip", "like", "%" . $ip . "%"];
        }
        if ($gid = input("gid")) {
            $where[] = ["gid", "=", $gid];
        }

        $host =  M::find($hostid);
        if ($host){
            $gid = explode(',',$host['ip_group_id']);
        }
        //$groupIpModel = new \app\common\model\BaremetalIpGroup();
        //$ipgroupList = $groupIpModel->whereIn('id',$gid)->select();

        if(empty($gid)&&$hostid>0){
            return ['code'=>0,'data'=>[],'extend'=>['count' => 0, 'limit' => 0]];
        }
        if (!empty($gid)){
            $list = \app\common\model\BaremetalIp::whereIn('gid',$gid)->where(['disable'=>0])->where(function ($query)use ($gid,$host){
                $query->whereOr(['state'=>1,'host_id'=>$host['id']]);
            })->where($where)->order('state desc')->paginate($limit);
        }else{
            $list = \app\common\model\BaremetalIp::where(['disable'=>0,'state'=>1])->where($where)->order('state desc')->paginate($limit);
        }

        $data =[];
        foreach ($list->items() as $k=>$v){
            $v['LAY_CHECKED'] = false;
            if($v['host_id']>0&&$v['host_id']==$hostid){
                $v['LAY_CHECKED'] = true;
                if($v['ip']==$host['ip']){
                    $v['ip'] = $v['ip']."(主IP)";
                }
            }
            $data[] = $v;
        }
        return ['code'=>0,'data'=>$data,'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }

    public static function settingIp($hostid){
        try {
            Db::startTrans();
            $host = M::find($hostid);
            $selectIp = Request::param('selected');
            $allIp = Request::param('all');
            $noId = [];
            if(!empty($selectIp)){
                foreach ($allIp as $k=>$v){
                    if (!in_array($v,$selectIp)){
                        $noId[] =  $v;
                    }
                }
            }else{
                $noId= $allIp;
            }

            $masterip = \app\common\model\BaremetalIp::where(['ip'=>$host['ip']])->find();
            if($masterip&&in_array((string)$masterip['id'],$noId)){
                throw new Exception("此处不能去掉主IP，请在编辑里面切换主IP");
            }

            if (!empty($noId)){
                \app\common\model\BaremetalIp::whereIn('id',$noId)->where(['host_id'=>$hostid])->save(['host_id'=>'','state'=>1]);
            }

            if (!empty($selectIp)){
                $ip_group_id =  explode(',',$host['ip_group_id']) ;
                if (!empty($ip_group_id)){
                    \app\common\model\BaremetalIp::whereIn('id',$selectIp)->whereIn('gid',$ip_group_id)->where(['state'=>1,'disable'=>0])->save(['host_id'=>$hostid,'state'=>2]);
                }
            }
            Db::commit();
            return ['msg'=>'操作成功'];
        }catch (Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    public static function goAllotBusiness($post){
        try {
            $host_id = $post['host_id'];
            if (empty($host_id)){
                throw new Exception('hostid 为空');
            }
            $businessModel = new BaremetalBusiness();
            $business = $businessModel->where(['host_id'=>$host_id])->find();
            $host = M::find($host_id);
            if (!empty($business)||$host['allocation']==2){
                throw new Exception('请不要重复分配业务，可在物理机业务管理里面删除业务再来分配');
            }

            $business = $businessModel->where(['user'=>$post['user']])->find();
            if ($business){
                throw new Exception('系统分配用户重复');
            }
        }catch (Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }

        try {
            Db::startTrans();
            $data['allot_name'] = $post['allot_name'];
            $data['host_id'] = $post['host_id'];
            $data['state'] = 1;
            $data['open_time'] =  $post['open_time'];
            $data['end_time'] = $post['end_time'];
            $data['user'] = $post['user'];
            $data['passwd'] = $post['passwd'];
            $businessModel->save($data);
            M::where(['id'=>$host_id])->save(['allocation'=>2]);
            Db::commit();
        }catch (Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    public static function getMacList($post){
        $ipmi_host = $post['ipmi_host'];
        $ipmi_user = $post['ipmi_user'];
        $ipmi_passwd = $post['ipmi_passwd'];
        if (empty($ipmi_host)||empty($ipmi_user)||empty($ipmi_passwd)){
            throw new Exception('暂不支持该功能');
        }
        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $post['node_id'];
        if (empty($node_id)){
            throw new Exception('暂不支持该功能');
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            throw new Exception('暂不支持该功能');
        }
        $baremetalService = new \qzcloud\Baremetal();
        $result = $baremetalService->getMacList(
            ['ipmi_host'=>$ipmi_host,
                'ipmi_user'=>$ipmi_user,
                'ipmi_passwd'=>$ipmi_passwd
            ],$node);

        return $result;
    }

    public static function cancelAuto($post){
        try {
            $host_id = $post['host_id'];
            $host = M::find($host_id);
            if (empty($host)){
                throw new Exception('主机不存在');
            }

            if (!in_array($host['state'],[3,6,7])){
                throw new Exception('暂无任务');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node_id = $host['node_id'];
            if (empty($node_id)){
                throw new Exception('暂不支持该功能');
            }
            $node = $nodeModel->find($node_id);
            if (empty($node)){
                throw new Exception('暂不支持该功能');
            }
            $baremetalService = new \qzcloud\Baremetal();
            $task = (new Task())->where(['param'=>$host_id,'state'=>1])->find();
            if ($task){
                    $baremetalService->cancelTask(
                    ['callback_param'=>$task['id']],$node);
            }
            $host->state=1;
            $host->save();
            return ['code'=>200,'msg'=>'success'];
        }catch (Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public static function upShelves($host_id){
        $host = M::find($host_id);
        if (empty($host)){
            throw new Exception('主机不存在');
        }

        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $host['node_id'];
        if (empty($node_id)){
            return;
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            return;
        }

        $host->shelves_state=1;
        $host->save();

        $baremetalService = new \qzcloud\Baremetal();
        $switchTemplateModel = new \app\common\model\BaremetalSwitchTemplate();
        $switchModel = new \app\common\model\BaremetalSwitch();
        $switch = $switchModel->where(['id'=>$host['switch_id']])->find();
        if ($switch){
            $switchTemplate = $switchTemplateModel->where(['id'=>$switch['template_id']])->find();
            if ($switchTemplate){
                $param = [
                    'host'=>$switch['host'],
                    'user'=>$switch['user'],
                    'passwd'=>$switch['passwd'],
                    'port'=>$switch['port'],
                ];
                if (!empty($switchTemplate['onshelf_pre_arp'])){
                   $command = QzcloudTool::getSwitchCommand($switchTemplate['onshelf_pre_arp'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
                if (!empty($switchTemplate['onshelf_pre_acl'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['onshelf_pre_acl'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
                if (!empty($switchTemplate['onshelf_arp'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['onshelf_arp'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
                if (!empty($switchTemplate['onshelf_acl'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['onshelf_acl'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }

            }
        }

        return ['code'=>200,'msg'=>'发送命令成功'];
    }

    public static function downShelves($host_id){
        $host = M::find($host_id);
        if (empty($host)){
            throw new Exception('主机不存在');
        }

        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $host['node_id'];
        if (empty($node_id)){
            return;
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            return;
        }

        $host->shelves_state=2;
        $host->save();

        $baremetalService = new \qzcloud\Baremetal();
        $switchTemplateModel = new \app\common\model\BaremetalSwitchTemplate();
        $switchModel = new \app\common\model\BaremetalSwitch();
        $switch = $switchModel->where(['id'=>$host['switch_id']])->find();
        if ($switch){
            $switchTemplate = $switchTemplateModel->where(['id'=>$switch['template_id']])->find();
            if ($switchTemplate){
                $param = [
                    'host'=>$switch['host'],
                    'user'=>$switch['user'],
                    'passwd'=>$switch['passwd'],
                    'port'=>$switch['port'],
                ];
                if (!empty($switchTemplate['offshelf_pre_arp'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['offshelf_pre_arp'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
                if (!empty($switchTemplate['offshelf_pre_acl'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['offshelf_pre_acl'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
                if (!empty($switchTemplate['offshelf_arp'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['offshelf_arp'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
                if (!empty($switchTemplate['offshelf_acl'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['offshelf_acl'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }

            }
        }

        return ['code'=>200,'msg'=>'发送命令成功'];
    }

    public static function closeNetwork($host_id){
        $host = M::find($host_id);
        if (empty($host)){
            throw new Exception('主机不存在');
        }

        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $host['node_id'];
        if (empty($node_id)){
            return;
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            return;
        }

        $host->network_state=2;
        $host->save();

        $baremetalService = new \qzcloud\Baremetal();
        $switchTemplateModel = new \app\common\model\BaremetalSwitchTemplate();
        $switchModel = new \app\common\model\BaremetalSwitch();
        $switch = $switchModel->where(['id'=>$host['switch_id']])->find();
        if ($switch){
            $switchTemplate = $switchTemplateModel->where(['id'=>$switch['template_id']])->find();
            if ($switchTemplate){
                $param = [
                    'host'=>$switch['host'],
                    'user'=>$switch['user'],
                    'passwd'=>$switch['passwd'],
                    'port'=>$switch['port'],
                ];
                if (!empty($switchTemplate['network_shutdown'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['network_shutdown'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }
            }
        }

        return ['code'=>200,'msg'=>'发送命令成功'];
    }

    public static function openNetwork($host_id){
        $host = M::find($host_id);
        if (empty($host)){
            throw new Exception('主机不存在');
        }

        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $host['node_id'];
        if (empty($node_id)){
            return;
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            return;
        }

        $host->network_state=1;
        $host->save();

        $baremetalService = new \qzcloud\Baremetal();
        $switchTemplateModel = new \app\common\model\BaremetalSwitchTemplate();
        $switchModel = new \app\common\model\BaremetalSwitch();
        $switch = $switchModel->where(['id'=>$host['switch_id']])->find();
        if ($switch){
            $switchTemplate = $switchTemplateModel->where(['id'=>$switch['template_id']])->find();
            if ($switchTemplate){
                $param = [
                    'host'=>$switch['host'],
                    'user'=>$switch['user'],
                    'passwd'=>$switch['passwd'],
                    'port'=>$switch['port'],
                ];
                if (!empty($switchTemplate['network_unshutdown'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['network_unshutdown'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }

            }
        }

        return ['code'=>200,'msg'=>'发送命令成功'];
    }

    public static function upBandwidth($param){
        $host_id = $param['id'];
        $host = M::find($host_id);
        if (empty($host)){
            throw new Exception('主机不存在');
        }

        $nodeModel = new \app\common\model\BaremetalNode();
        $node_id = $host['node_id'];
        if (empty($node_id)){
            return;
        }
        $node = $nodeModel->find($node_id);
        if (empty($node)){
            return;
        }

        $host->bandwidth=$param['bandwidth'];
        $host->bandwidth_in=$param['bandwidth_in'];
        $host->save();

        $baremetalService = new \qzcloud\Baremetal();
        $switchTemplateModel = new \app\common\model\BaremetalSwitchTemplate();
        $switchModel = new \app\common\model\BaremetalSwitch();
        $switch = $switchModel->where(['id'=>$host['switch_id']])->find();
        if ($switch){
            $switchTemplate = $switchTemplateModel->where(['id'=>$switch['template_id']])->find();
            if ($switchTemplate){
                $param = [
                    'host'=>$switch['host'],
                    'user'=>$switch['user'],
                    'passwd'=>$switch['passwd'],
                    'port'=>$switch['port'],
                ];
                if (!empty($switchTemplate['upgrade_bandwidth'])){
                    $command = QzcloudTool::getSwitchCommand($switchTemplate['upgrade_bandwidth'],$host_id);
                    $param['command'] = $command;
                    $baremetalService->switchCommand($command,$node_id);
                }

            }
        }

        return ['code'=>200,'msg'=>'发送命令成功'];
    }
}
