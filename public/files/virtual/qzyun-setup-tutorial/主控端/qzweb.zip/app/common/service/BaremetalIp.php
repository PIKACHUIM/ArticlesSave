<?php
declare (strict_types = 1);

namespace app\common\service;

use think\facade\Db;
use think\facade\Request;
use app\common\model\BaremetalIp as M;
use app\common\validate\BaremetalIp as V;

class BaremetalIp
{
    // 添加
    // 添加
    public static function goAdd($data)
    {
        //验证
        $validate = new V;
        if(!$validate->scene('add')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {
            Db::transaction(function ()use ($data) {
                $ipGidModel = new \app\common\model\BaremetalIpGroup() ;
                $ipG = $ipGidModel->where(['id'=>$data['gid']])->find();
                $data['gname'] = $ipG->toArray()['name'];
                $data['gid'] = $ipG->toArray()['id'];
                if(strstr($data['ip'],'-')!==false){
                    $iparr = explode('-',$data['ip']);
                    $ip_=explode('.',$iparr[0]);
                    if($ip_[3]>$iparr[1]){
                        throw new Exception('ip段填写错误');
                    }
                    $pre = $ip_[0].'.'.$ip_[1].'.'.$ip_[2];
                    for ($i=$ip_[3];$i<=$iparr[1];$i++){
                        $data['ip']=$pre.'.'.$i;
                        if(M::where(['ip'=>$data['ip']])->find()){
                            continue;
                        }
                        M::create($data);
                    }
                }else{
                    if(M::where(['ip'=>$data['ip']])->find()){
                        return ;
                    }
                    M::create($data);
                }
            });

        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }
    
    // 编辑
    public static function goEdit($data,$id)
    {
        $data['id'] = $id;
        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
        return ['msg'=>$validate->getError(),'code'=>201];
        try {
            $ipGidModel = new \app\common\model\BaremetalIpGroup() ;
            $ipG = $ipGidModel->where(['id'=>$data['gid']])->find();
            $data['gname'] = $ipG->toArray()['name'];
            $data['gid'] = $ipG->toArray()['id'];
             M::update($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'status' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
           $model->delete();
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 批量删除
    public static function goBatchRemove($ids)
    {
        if (!is_array($ids)) return ['msg'=>'数据不存在','code'=>201];
        try{
            M::destroy($ids);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 获取列表
    public static function getIpPageList()
    {
        $where = [];
        $limit = input('get.limit',10000);
        $host_id = input('get.hostid');
        if (empty($host_id)){
            return ['msg'=>'参数错误','code'=>201];
        }
       //按ip查找
        if ($ip = input("ip")) {
           $where[] = ["ip", "like", "%" . $ip . "%"];
        }
        $where[] = ["host_id", "=", $host_id];
        $list = M::onlyTrashed()->where($where)->paginate($limit);
        return ['code'=>0,'data'=>$list->items(),'extend'=>['count' => $list->total(), 'limit' => $limit]];
    }
}
