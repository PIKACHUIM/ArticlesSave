<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\BaremetalMirrorsDetail;
use app\common\model\Task;
use qzcloud\Baremetal;
use think\Exception;
use think\facade\Db;
use think\facade\Request;
use app\common\model\BaremetalMirrors as M;
use app\common\validate\BaremetalMirrors as V;

class BaremetalMirrors
{
    // 添加
    public static function goAdd($data)
    {
        //验证
        $validate = new V;
        if(!$validate->scene('add')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {
            M::create($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 编辑
    public static function goEdit($data,$id)
    {
        $mount = $data['mount'];
        $size = $data['size'];
        $ext = $data['ext'];
        if(count($mount)!=count(array_unique($mount))){
            throw new Exception('挂载点重复');
        }

        if(count($mount)!=count($size)||count($mount)!=count($ext)){
            throw new Exception('数据异常');
        }
        $empty = 0;
        $part = '';
        $extend = '';
        foreach ($mount as $k=>$v){
            $temp='';
            if(empty(trim($v,''))){
                throw new Exception('挂载点/盘符不能有空项');
            }
            if($v!='swap'&&$ext[$k]=='swap'){
                throw new Exception('非swap分区不能使用swap格式');
            }
            if(!empty($size[$k])&&!is_numeric($size[$k])){
                throw new Exception('容量为空请为数字/或者填空');
            }
            if(empty(trim($size[$k],''))){
                $empty++;
            }
            if($empty>1){
                throw new Exception('只能存在一个剩余空间行');
            }

            if(empty($ext[$k])){
                throw new Exception('格式不能为空');
            }
            $size_ = $size[$k];
            if(empty($size_)){
                $size_ = 'extend';
                $extend = "{$v}:{$ext[$k]}:$size_";
            }else{
                $temp = "{$v}:{$ext[$k]}:$size_";
            }

            $part=$part.','.$temp;
        }
        $part = trim($part,',');
        $part = $part.','.$extend;
        $part = trim($part,',');
        $data['id'] = $id;
        $data['os_partition'] = $part;
        unset($data['mount'],$data['size'],$data['ext']);

        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {
            M::update($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'status' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->delete();
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 批量删除
    public static function goBatchRemove($ids)
    {
        if (!is_array($ids)) return ['msg'=>'数据不存在','code'=>201];
        try{
            M::destroy($ids);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    public static function goRemoteMirror($post)
    {
        $baremetal = new Baremetal();
        if (!isset($post['uuid'])||empty($post['uuid'])){
            return ['code'=>201,'msg'=>'没有要导入的信息'];
        }
        $uuid = $post['uuid'];
        $node_name = $post['node_name'];
        $result = $baremetal->remoteMirrors();
        $data = $result['data'];
        $info= [];
        foreach ($data as $k=>$v){
            if($v['uuid']==$uuid){
                $info = $v;
            }
        }
        if (empty($node_name)){
            return ['code'=>201,'msg'=>'请选择控制器'];
        }
        if(empty($info)){
            return ['code'=>201,'msg'=>'镜像信息不存在'];
        }
        $data = [];
        $data['os_name'] = $info['os_name'];
        $data['os_index'] = $info['os_index'];

        $data['uuid'] = $info['uuid'];
        $data['os_size'] = $info['os_size'];
        $data['hidden'] = 1;
        $data['os_type'] = $info['os_type'];
        $data['os_ver'] = $info['os_ver'];
        $data['os_type'] = $info['os_type'];
        $data['os_url'] = $info['os_url'];
        if(strstr(strtolower($data['os_type']),'windows')!==false){
            $data['os_partition'] = '分区1:NTFS:102400';
            $data['os_root'] = 'administrator';
        }else{
            $data['os_partition'] = '/boot:ext4:2048,/:ext4:51200,swap:swap:8192,/home:ext4:extend';
            $data['os_root'] = 'root';
        }
        $baremetalMirrors = new \app\common\model\BaremetalMirrors();

        $mirrors = $baremetalMirrors->where(['uuid'=>$info['uuid']])->find();
        $data['os_source'] = 2;
        $id = 0;
        if($mirrors){
            $id = $mirrors['id'];
            $baremetalMirrors->where(['uuid'=>$info['uuid']])->save($data);
        }else{
            $id =  $baremetalMirrors->insert($data,true);
        }

        $MirrorsDetail = new \app\common\model\BaremetalMirrorsDetail();
        foreach ($node_name as $k=>$v){
            try {
                //$re = $baremetalService->import(['node_id'=>$v,'url'=>$info['os_url']]);
                $count = $MirrorsDetail->where([
                    'mirrors_id'=>$id,
                    'node_id'=>$v,
                    'state'=>1,
                ])->count();
                if($count){
                    continue;
                }
                Db::startTrans();
                $detailid  = $MirrorsDetail->insert([
                    'mirrors_id'=>$id,
                    'node_id'=>$v,
                    'uuid'=>$info['uuid'],
                    'state'=>1,
                ],true);
                $taskid = self::addTask("down_isofile",$detailid);

                $cloudTask = new ExecuteTask();
                $res = $cloudTask->downISOFile($taskid);
                if ($res['code'] == 0){
                    throw new Exception($res['msg']);
                }
                $mirrorsinfo = $baremetalMirrors->find($id);
                $node ='';
                if (empty($mirrorsinfo['node'])){
                    $node = $v;
                }else{
                    $node = $mirrorsinfo['node'].','.$v;
                }
                $baremetalMirrors->where(['uuid'=>$info['uuid']])->save(['node'=>$node]);
                Db::commit();
            }catch (Exception $e){
                Db::rollback();
                return ['code'=>201,'msg'=>$e->getMessage()];
                //throw new Exception($e->getMessage());
            }
        }
    }

    public static function golocalMirror($post){
        $data = [];
        $uuid = date("YmdHis").rand_string(4,1);
        $os_index = $post['os_index'];
        $os_index_arr = explode('|',$os_index);
        $size = count($os_index_arr)>1?$os_index_arr[1]:0;
        if ($size>1000){
            $size = round( $size/1024,2);
            $size = $size.'GB';
        }else{
            $size = $size.'MB';
        }
        $data['os_name'] = $post['os_name'];
        $data['uuid'] = $uuid;
        $data['os_size'] = $size;
        $data['os_type'] = $post['os_type'];
        $data['os_source'] = 1;
        $data['os_index'] = $os_index_arr[0];
        $data['os_url'] = $post['os_url'];
        $data['os_ver'] = $post['os_ver'];
        $data['node'] = $post['node_id'];
        $data['hidden'] = 1;
        if(strstr(strtolower($data['os_type']),'windows')){
            $data['os_partition'] = '分区1:NTFS:102400';
            $data['os_root'] = 'administrator';
        }else{
            $data['os_partition'] = '/boot:ext4:2048,/:ext4:51200,swap:swap:8192,/home:ext4:extend';
            $data['os_root'] = 'root';
        }

        $baremetalMirrors = new \app\common\model\BaremetalMirrors();
        $id =  $baremetalMirrors->insert($data,true);

        $MirrorsDetail = new \app\common\model\BaremetalMirrorsDetail();
        $MirrorsDetail->startTrans();
        try {
            //$re = $baremetalService->import(['node_id'=>$v,'url'=>$info['os_url']]);
            $detailid  = $MirrorsDetail->insert([
                'mirrors_id'=>$id,
                'node_id'=>$post['node_id'],
                'uuid'=>$uuid,
                'state'=>1,
            ],true);
            $taskid = self::addTask("import_iso",$detailid);
            $cloudTask = new ExecuteTask();
            $res = $cloudTask->importISO($taskid);
            $MirrorsDetail->commit();
        }catch (Exception $e){
            $MirrorsDetail->rollback();
            // throw new Exception($e->getMessage());
            return ['code'=>201,'msg'=>$e->getMessage()];
        }
    }

    public static function getISOList($node_id){
        if (empty($node_id)){
            return [];
        }
        $baremetal = new Baremetal();
        $nodel = new \app\common\model\BaremetalNode();
        $info = $nodel->where(['id'=>$node_id])->find();
        return $baremetal->getISOList([],$info);
    }

    public static function getISOInfo($param){
        if (empty($param)){
            return [];
        }
        $baremetal = new Baremetal();
        $nodel = new \app\common\model\BaremetalNode();
        $info = $nodel->where(['id'=>$param['node_id']])->find();
        return $baremetal->GetSystemVer(['file_name'=>$param['iso_name']],$info);
    }

    public static function addTask($command,$where,$other=[]){
        try{
            $model = new Task();
            $data = ['command'=>$command,'param'=>$where,'create_time'=>date('Y-m-d H:i:s')];
            if($other){
                $data =array_merge($data,$other);
            }
            $res = $model->insert($data,true);
            return $res;
        }catch (Exception $E){
            throw new Exception($E->getMessage());
        }
    }

    public static function flushStatus($post){
        if (!isset($post['ids'])){
            return [];
        }

        $ids = $post['ids'];

        $mirrorsDetailModel = new BaremetalMirrorsDetail();
        $mirrorsDetailList =  $mirrorsDetailModel->where(['state'=>1])->whereIn('id',$ids)->select();
        if (empty($mirrorsDetailList)){
            return [];
        }
        $callback_param_id = array_column($mirrorsDetailList->toArray(),'id');
        $taskModel = new Task();
        $tasklist = $taskModel->where(['command'=>'downISOFile'])->whereIn('param',$callback_param_id)->select();
        $detailId = [];
        if(empty($tasklist)){
            return  [];
        }
        foreach ($tasklist as $k=>$v){
            $detailId[$v['id']] = $v['param'];
        }
        $taskidList = array_column($tasklist->toArray(),'id');
        $baremetal = new Baremetal();
        $nodeModel = new \app\common\model\BaremetalNode();
        if (!isset($mirrorsDetailList[0])){
            return  [];
        }
        $node = $nodeModel->where(['id'=>$mirrorsDetailList[0]['node_id']])->find();
        //
        $taskList = $baremetal->getTaskList(['callback_param'=>implode(',',$taskidList)],$node);
        if ($taskList['code']!=200){
            return [];
        }
        $data = [];
        if(empty($taskList['data'])){
            return [];
        }
        foreach ($taskList['data'] as $k=>$v){
            if (!isset($detailId[$v['callback_param']])){
                continue;
            }
            if (!isset($v['Process'])){
                continue;
            }
            $monitor = json_decode($v['Process'],true);
            $str = '';
          /*  if(isset($monitor['DownloadSpeed'])){
                $str .= '下载速度:'.$monitor['DownloadSpeed'].'kb/s,';
            }*/
            if(isset($monitor['Process'])){
                $str .= '总进度:'.$monitor['Process'].'%';
            }
            if(!empty($monitor['Remark'])){
                $str .= ',备注:'.$monitor['Remark'];
            }
            $data[$detailId[$v['callback_param']]]=$str;
        }
        return ['msg'=>'','data'=>$data,'code'=>200];
    }

    public static function stopTask($id){
        try {
            $MirrorsDetail = new \app\common\model\BaremetalMirrorsDetail();
            $info = $MirrorsDetail ->where(['id'=>$id])->find();
            if (empty($info)){
                throw new Exception('信息不存在');
            }
            $taskModel = new Task();
            $task = $taskModel->where(['command'=>'import_iso','param'=>$id])->find();
            if (empty($task)){
                throw new Exception('任务不存在');
            }
            $nodeModel = new \app\common\model\BaremetalNode();
            $node = $nodeModel->where(['id'=>$info['node_id']])->find();
            $baremetalS = new Baremetal();
            $re = $baremetalS->cancelTask(['callback_param'=>$task['id']],$node);
            if ($re['code']!=200){
                throw new Exception('取消失败');
            }

            $MirrorsDetail ->where(['id'=>$id])->save(['state'=>2]);
        }catch (Exception $e){
            return ['code'=>201,'msg'=>$e->getMessage()];
        }
    }

    public static function reImport($id){
        try {
            $MirrorsDetail = new \app\common\model\BaremetalMirrorsDetail();
            $info = $MirrorsDetail ->where(['id'=>$id])->find();
            if (empty($info)){
                throw new Exception('信息不存在');
            }

            $taskModel = new Task();
            $task = $taskModel->where(['command'=>'import_iso','param'=>$id])->find();
            if (empty($task)){
                throw new Exception('任务不存在');
            }
            $taskModel->where(['id'=>$task['id'],'is_delete'=>1])->update(['state'=>0,'end_time'=>date("Y-m-d H:i:s")]);
            //$taskid = self::addTask("import_iso",$id);

            $cloudTask = new ExecuteTask();
            $res = $cloudTask->importISO($task['id']);
            if ($res['code'] == 0){
                throw new Exception($res['msg']);
            }

            $MirrorsDetail ->where(['id'=>$id])->save(['state'=>1]);

        }catch (Exception $e){
            return ['code'=>201,'msg'=>$e->getMessage()];
        }
    }

}
