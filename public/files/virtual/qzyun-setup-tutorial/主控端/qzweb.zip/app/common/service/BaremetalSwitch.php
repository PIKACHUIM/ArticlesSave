<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\BaremetalBusiness;
use app\common\model\BaremetalSwitchPort;
use app\common\model\Task;
use think\Exception;
use think\facade\Db;
use think\facade\Request;
use app\common\model\BaremetalSwitch as M;
use app\common\validate\BaremetalSwitch as V;

class BaremetalSwitch
{
    // 添加
    public static function goAdd($data)
    {

        //验证
        $validate = new V;
        if(!$validate->scene('add')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {

            Db::startTrans();
            M::create($data);
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 编辑
    public static function goEdit($data,$id)
    {
        $data['id'] = $id;
        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {
            M::update($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'status' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    public static function switchList($cabinet_id){
        $info =  M::where(['cabinet_id'=>$cabinet_id])->select();
        if (!empty($info)){
            $info =   $info->toArray();
        }
        return ['msg'=>'','code'=>200,'data'=>$info];
    }

    public static function switchPort($switchid,$switch_port=''){
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $info =  M::find($switchid);
        $switchModel = Db::table($prefix.'baremetal_switch_model')->find($info['model_id']);
        $usedPortList = Db::table($prefix.'baremetal_switch_port')->where(['switch_id'=>$switchid])->select();
        $port =[];
        if (!empty($usedPortList)){
            $usedPortList= $usedPortList->toArray();
            $usedPortList = array_filter(array_column($usedPortList,'port'));
        }
        if (!empty($switchModel['prefix'])){
            $prefix = json_decode($switchModel['prefix'],true);
            foreach ($prefix as $k=>$v){
                if (empty($k)){
                    continue;
                }
                $range = explode('-',$k);
                if (count($range)!=2){
                    continue;
                }

                for ($i=$range[0];$i<=$range[1];$i++){
                    $item = $v.$i;
                    if (!empty($usedPortList)){
                        if (in_array($item,$usedPortList)&&$item!=$switch_port){
                            continue;
                        }
                    }

                    $port[] = $item;
                }
            }

        }
        return ['code'=>200,'msg'=>'','data'=>$port] ;
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Db::startTrans();
            $model->delete();
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

}
