<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\BaremetalBusiness;
use app\common\model\Task;
use think\Exception;
use think\facade\Db;
use think\facade\Request;
use app\common\model\BaremetalSwitchTemplate as M;
use app\common\validate\BaremetalSwitchTemplate as V;

class BaremetalSwitchTemplate
{
    // 添加
    public static function goAdd($data)
    {

        //验证
        $validate = new V;
        if(!$validate->scene('add')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {

            Db::startTrans();
            M::create($data);
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 编辑
    public static function goEdit($data,$id)
    {
        $data['id'] = $id;
        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
            return ['msg'=>$validate->getError(),'code'=>201];
        try {
            M::update($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'status' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Db::startTrans();
            $model->delete();
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

}
