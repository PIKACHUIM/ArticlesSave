<?php

namespace app\common\service;

use app\common\model\BackupVps;
use app\common\model\BaremetalHost;
use app\common\model\BaremetalMirrors;
use app\common\model\BaremetalMirrorsDetail;
use app\common\model\HostVps;
use app\common\model\ServersImageConfig;
use app\common\model\ServersIpv4;
use app\common\model\ServersIpv4Nat;
use app\common\model\ServersIpv4Private;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\model\SnapshotVps;
use app\common\model\Task;
use app\common\util\BaseConst;
use GuzzleHttp\Client;
use qzcloud\Baremetal;
use qzcloud\HyperV;
use qzcloud\Kvm;
use think\Exception;
use think\Log;

/**
 *  轻舟 hyper-v或者kvm
 */
set_time_limit(0);
class ExecuteTask
{
    public function exec_task($taskid){
        $taskModel = new  Task();
        $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
        if(!$taskInfo){
            return ;
        }
        switch($taskInfo['command']){
            case 'create_vps': //创建
                $this->createVps($taskid);
                break;
            case 'recreate_vps': //重新创建
                $this->recreateVps($taskid);
                break;
            case 'remove_vps':
                $this->removeVps($taskid); //删除vps
                break;
            case 'reinstall':
                $this->reinstallVps($taskid); //重新安装操作系统
                break;
            case 'create_snapshot':
                $this->createSnapshotVps($taskid); //创建快照
                break;
            case 'create_backup':
                $this->createBackupVps($taskid); //创建备份
                break;
            case 'restore_snapshot':
                $this->restoreSnapshotVps($taskid); //还原快照
                break;
            case 'restore_backup':
                $this->restoreBackupVps($taskid); //还原备份
                break;
            case 'remove_snapshot':
                $this->removeSnapshotVps($taskid); //删除快照
                break;
            case 'remove_backup':
                $this->removeBackupVps($taskid); //删除备份
                break;
            case 'update_vps':
                $this->updateVps($taskid); //升级vps
                break;
            case 'down_isofile':
                $this->downISOFile($taskid); //导入iso
                break;
            default:;
        }
    }

    //创建vps
    public function createVps($taskid)
    {
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new  Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                throw new Exception('taskid not exit taskid='.$taskid);
            }
            $hostModel = new HostVps();
            $hostInfo = $hostModel->where($taskInfo['param'])->find();
            if($hostInfo['state']!=1){
                throw new Exception('taskid is success taskid ='.$taskid.' ,host_id='.$hostInfo['id']);
            }
            //第一步
            $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->data(['state'=>1,'start_time'=>date("Y-m-d H:i:s")])->save();
            $node = new ServersNode();
            $line = new ServersLine();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            $lineinfo = $line->where(['id'=>$hostInfo['line_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            $image = new ServersImageConfig();
            $imageinfo = $image->where(['os_name'=>$hostInfo['os_name']])->find();
            if(!$imageinfo){
                throw new Exception('镜像文件不存在 os_name=####'.$hostInfo['os_name']);
            }
            $serverIpv4PrivateModel = new ServersIpv4Private();//私有ip
            $privateip = $serverIpv4PrivateModel->where(['ip'=>$hostInfo['local_ip']])->find();
            if($hostInfo['is_nat']==1){ //挂机宝
                $serverIpv4NatModel = new ServersIpv4Nat();//natip
                $ip = $serverIpv4NatModel->where(['ip'=>$hostInfo['ip']])->find();
            }else{
                $serverIpv4Model =  new ServersIpv4();//独立ip
                $ip = $serverIpv4Model->where(['ip'=>$hostInfo['ip']])->find();
            }
            $hostInfo_ = $hostInfo->toArray();
            $hostInfo_['file_name'] = $imageinfo->file_name;
            $hostInfo_['os_type'] = ServersImageConfig::$os_type[$imageinfo->os_type];
            $network =[];
            $network['eth1'] =$ip;
            $network['eth2'] =$privateip;
            $network['otherip'] =$hostInfo['add_ip'];
            return $vm->openHost($lineinfo,$nodeinfo,$hostInfo_,$network,$taskid);
        }catch (Exception $e){
            $state = 11; //创建失败
            $taskModel->where(['id'=>$taskid,'is_delete'=>1])->data(['state'=>3,'start_time'=>date("Y-m-d H:i:s"),'end_time'=>date("Y-m-d H:i:s"),'remark'=>$e->getMessage()])->save();
            $hostModel->where(['id'=>$hostInfo['id']])->save(['state'=>$state]);
            throw new Exception($e->getMessage());
        }
    }

    //升级
    public function updateVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new  Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                throw new Exception('taskid not exit taskid='.$taskid);
            }
            $hostModel = new HostVps();
            $hostInfo = $hostModel->where($taskInfo['param'])->find();

            //第一步
            ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }
            $image = new ServersImageConfig();
            $imageinfo = $image->where(['os_name'=>$hostInfo['os_name']])->find();
            $serverIpv4PrivateModel = new ServersIpv4Private();//私有ip
            $privateip = $serverIpv4PrivateModel->where(['ip'=>$hostInfo['local_ip']])->find();
            if($hostInfo['is_nat']==1){ //挂机宝
                $serverIpv4NatModel = new ServersIpv4Nat();//natip
                $ip = $serverIpv4NatModel->where(['ip'=>$hostInfo['ip']])->find();
            }else{
                $serverIpv4Model = new ServersIpv4();//独立ip
                $ip = $serverIpv4Model->where(['ip'=>$hostInfo['ip']])->find();
            }
            $hostInfo_ = $hostInfo->toArray();
            $hostInfo_['file_name'] = $imageinfo->file_name;
            $hostInfo_['os_type'] = ServersImageConfig::$os_type[$imageinfo->os_type];
            /* $network =[];
             $network['eth1'] =$ip;
             $network['eth2'] =$privateip;
             $network['otherip'] =$hostInfo['add_ip'];*/
            //$hostInfo_ = $hostInfo->toArray();
            $hostInfo_['mac'] = $ip['mac'];
            $hostInfo_['mac1'] = $privateip['mac'];
            return $info = $vm->updateHost($nodeinfo->toArray(),$hostInfo_,$taskid);
        }catch (Exception $e){
            $state = 11; //创建失败
            ecs::setField(['id'=>$taskid,'is_delete'=>1],['state'=>3,'end_time'=>date("Y-m-d H:i:s"),'remark'=>$e->getMessage()]);
            $hostModel->where(['id'=>$hostInfo['id']])->save(['state'=>$state]);
            throw new Exception($e->getMessage());
        }
    }

    //重新创建vps
    public function recreateVps($taskid)
    {
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new  Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                throw new Exception('taskid not exit taskid='.$taskid);
            }
            $hostModel = new HostVps();
            $hostInfo = $hostModel->where($taskInfo['param'])->find();

            //第一步
            $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->data(['state'=>1,'start_time'=>date("Y-m-d H:i:s")])->save();
            $node = new ServersNode();
            $line = new ServersLine();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            $lineinfo = $line->where(['id'=>$hostInfo['line_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            $image = new ServersImageConfig();
            $imageinfo = $image->where(['os_name'=>$hostInfo['os_name']])->find();
            if(!$imageinfo){
                throw new Exception('镜像文件没有不存在 os_name=####'.$hostInfo['os_name']);
            }
            $serverIpv4PrivateModel = new ServersIpv4Private();//私有ip
            $privateip = $serverIpv4PrivateModel->where(['ip'=>$hostInfo['local_ip']])->find();
            if($hostInfo['is_nat']==1){ //挂机宝
                $serverIpv4NatModel = new ServersIpv4Nat();//natip
                $ip = $serverIpv4NatModel->where(['ip'=>$hostInfo['ip']])->find();
            }else{
                $serverIpv4Model =  new ServersIpv4();//独立ip
                $ip = $serverIpv4Model->where(['ip'=>$hostInfo['ip']])->find();
            }
            $hostInfo_ = $hostInfo->toArray();
            $hostInfo_['file_name'] = $imageinfo->file_name;
            $hostInfo_['os_type'] = ServersImageConfig::$os_type[$imageinfo->os_type];
            $hostInfo_['re_create']=1;
            $network =[];
            $network['eth1'] =$ip;
            $network['eth2'] =$privateip;
            $network['otherip'] =$hostInfo['add_ip'];
            return $vm->openHost($lineinfo,$nodeinfo,$hostInfo_,$network,$taskid);
        }catch (Exception $e){
            $state = 11; //创建失败
            $taskModel->where(['id'=>$taskid,'is_delete'=>1])->data(['state'=>3,'start_time'=>date("Y-m-d H:i:s"),'end_time'=>date("Y-m-d H:i:s"),'remark'=>$e->getMessage()])->save();
            $hostModel->where(['id'=>$hostInfo['id']])->save(['state'=>$state]);
            throw new Exception($e->getMessage());
        }

    }

    //手动删除vps
    public function removeVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new  Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                throw new Exception('taskid not exit taskid='.$taskid);
            }
            $hostModel = new HostVps();
            $hostInfo = $hostModel->where($taskInfo['param'])->find();

            //第一步
            $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->data(['state'=>1,'start_time'=>date("Y-m-d H:i:s")])->save();
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            return $vm->deleteHost($nodeinfo->toArray(),$hostInfo->toArray(),$taskid);
        }catch (Exception $e){
            $taskModel->where(['id'=>$taskid,'is_delete'=>1])->data(['state'=>3,'start_time'=>date("Y-m-d H:i:s"),'end_time'=>date("Y-m-d H:i:s"),'remark'=>$e->getMessage()])->save();
            //$hostModel->where(['id'=>$hostInfo['id']])->save(['state'=>$state]);
            throw new Exception($e->getMessage());
        }
    }

    //重新安装操作系统
    public function reinstallVps($taskid)
    {
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $hostModel = new HostVps();
            $hostInfo = $hostModel->where($taskInfo['param'])->find();
            //第一步
            ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            $image = new ServersImageConfig();
            $imageinfo = $image->where(['os_name'=>$hostInfo['os_name']])->find();
            $hostinfo_ = $hostInfo->toArray();
            $hostinfo_['file_name'] = $imageinfo['file_name'];
            $hostinfo_['os_type'] = BaseConst::OS_TYPE[$imageinfo->os_type];

            $serverIpv4PrivateModel = new ServersIpv4Private();//私有ip
            $privateip = $serverIpv4PrivateModel->where(['ip'=>$hostInfo['local_ip']])->find();
            $other =[];
            if($hostInfo['is_nat']==1){ //挂机宝
                $serverIpv4NatModel = new ServersIpv4Nat();//natip
                $ip = $serverIpv4NatModel->where(['ip'=>$hostInfo['ip']])->find();
            }else{
                $serverIpv4Model = new ServersIpv4();//独立ip
                $ip = $serverIpv4Model->where(['ip'=>$hostInfo['ip']])->find();
                if($hostInfo['add_ip']){
                    $otherip = explode(',',$hostInfo['add_ip']);
                    $otherip = array_filter($otherip);
                    $other = $serverIpv4Model->where('ip','<>',$hostInfo['ip'])->whereIn('ip',$otherip)->find();
                }

            }

            $network =[];
            $network['eth1'] =$ip;
            $network['eth2'] =$privateip;
            $network['other'] =$other;
            return $vm->reinstallHost($nodeinfo->toArray(),$hostinfo_,$network,$taskid);

        }catch (Exception $e){
            $taskModel->where(['id'=>$taskid,'is_delete'=>1])->data(['state'=>3,'start_time'=>date("Y-m-d H:i:s"),'end_time'=>date("Y-m-d H:i:s"),'remark'=>$e->getMessage()])->save();
            $hostModel->where(['id'=>$hostInfo['id']])->save(['state'=>5]);
            throw new Exception($e->getMessage());
        }

    }

    //创建快照
    public function createSnapshotVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $snapshot_vps_model = new SnapshotVps();
            $hostModel = new HostVps();
            $snapshotInfo = $snapshot_vps_model->where($taskInfo['param'])->find();
            $hostInfo = $hostModel->where(['id'=>$snapshotInfo->host_id])->find();
            if(empty($hostInfo)){
                exit('createSnapshotVps host info not exit ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            return $vm->createSnapshotHost($nodeinfo->toArray(),$snapshotInfo->toArray(),$taskid);
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    //还原快照
    public function restoreSnapshotVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                // Log::error('taskid not exist, taskid='.$taskid);
                // exit('taskid not exit taskid='.$taskid);
            }
            $snapshot_vps_model = new SnapshotVps();
            $hostModel = new HostVps();
            $snapshotInfo = $snapshot_vps_model->where($taskInfo['param'])->find();
            $hostInfo = $hostModel->where(['id'=>$snapshotInfo->host_id])->find();
            if(empty($hostInfo)){
                // Log::error('restoreSnapshotVps host info not exit ');
                // exit('restoreSnapshotVps host info not exit ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }
            return $vm->restoreSnapshotHost($nodeinfo->toArray(),$snapshotInfo->toArray(),$taskid);
        }catch (Exception $e){
            $snapshotInfo->state=3;
            $snapshotInfo->save();
            throw new Exception($e->getMessage());
        }
    }

    //删除快照
    public function removeSnapshotVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $snapshot_vps_model = new SnapshotVps();
            $hostModel = new HostVps();
            $snapshotInfo = $snapshot_vps_model->where($taskInfo['param'])->find();
            $hostInfo = $hostModel->where(['id'=>$snapshotInfo->host_id])->find();
            if(empty($hostInfo)){
                exit('removeSnapshotVps host info not exit ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            return $info = $vm->removeSnapshotHost($nodeinfo->toArray(),$snapshotInfo->toArray(),$taskid);
        }catch (Exception $e){
            $snapshotInfo->state=2;
            $snapshotInfo->save();
            throw new Exception($e->getMessage());
        }
    }

    //创建备份
    public function createBackupVps($taskid){
        if(!$taskid) {
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $backup_vps_model =  new BackupVps();
            $hostModel = new HostVps();
            $backupInfo = $backup_vps_model->where($taskInfo['param'])->find();
            $hostInfo = $hostModel->where(['id'=>$backupInfo->host_id])->find();
            if(empty($hostInfo)){
                exit('createBackupVps host info not exit ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            return $vm->createBackupHost($nodeinfo->toArray(),$backupInfo->toArray(),$taskid);
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    //还原备份
    public function restoreBackupVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $backup_vps_model = new BackupVps();
            $hostModel = new HostVps();
            $backupInfo = $backup_vps_model->where($taskInfo['param'])->find();
            $hostInfo = $hostModel->where(['id'=>$backupInfo->host_id])->find();
            if(empty($hostInfo)){
                exit('restoreBackupVps host info not exit ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }
            return $vm->restoreBackupHost($nodeinfo->toArray(),$backupInfo->toArray(),$taskid);
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    //删除备份
    public function removeBackupVps($taskid){
        if(!$taskid){
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();
            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $backup_vps_model = new BackupVps();
            $hostModel = new HostVps();
            $backupInfo = $backup_vps_model->where($taskInfo['param'])->find();
            $hostInfo = $hostModel->where(['id'=>$backupInfo->host_id])->find();
            if(empty($hostInfo)){
                exit('removeBackupVps host info not exit ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            $node = new ServersNode();
            $nodeinfo = $node->where(['id'=>$hostInfo['node_id']])->find();
            if($hostInfo['from_type']=='1'){
                if($hostInfo['virtual_type']=='hyper-v'){
                    $vm = new HyperV();
                }else{ //kvm
                    $vm = new Kvm();
                }

            }else{//对接api
                $vm = new $hostInfo['plug_name']();
            }

            return $vm->removeBackupHost($nodeinfo->toArray(),$backupInfo->toArray(),$taskid);
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    //统计流量
    public function networkFlowVps(){
        $logic = new EcsLogic();
        $logic->network_flow_host();
    }

    //检查到期
    public function checkOverdue(){
        $logic = new EcsLogic();
        $logic->check_overdue();
    }

    //根据流量设置网卡状态
    public function setNetworkStateVps(){
        $logic = new EcsLogic();
        $logic->set_network_state_host();
    }

    //删除
    public function do_overdue(){
        $logic = new EcsLogic();
        $logic->do_overdue(); //删除自产
        $logic->delete_agent_host(); //删除代理商记录
    }

    //裸金属任务
    public function downISOFile($taskid){
        if(!$taskid) {
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();

            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $mirrorsDetailModel =  new BaremetalMirrorsDetail();
            $mirrorsDetailInfo = $mirrorsDetailModel->where(['id'=>$taskInfo['param']])->find();

            if(empty($mirrorsDetailInfo)){
                exit('downISOFile  mirrorsDetail not found ');
            }

            $mirrorsModel =  new \app\common\model\BaremetalMirrors();
            $mirrorsInfo = $mirrorsModel->where(['id'=>$mirrorsDetailInfo['mirrors_id']])->find();
            if(empty($mirrorsInfo)){
                exit('downISOFile  mirrors not found ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);

            $baremetalServeice = new Baremetal();
            $param['url'] = $mirrorsInfo['os_url'];
            $param['name'] = $mirrorsInfo['os_name'];
            $param['taskid'] = $taskid;
            $param['source'] = $mirrorsInfo['os_source'];
            $baremetalNodeModel = new \app\common\model\BaremetalNode();
            $node = $baremetalNodeModel->where(['id'=>$mirrorsDetailInfo['node_id']])->find();
            if(empty($node)){
                exit('downISOFile  node not found ');
            }

            return $baremetalServeice->downISOFile($param,$node->toArray());
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
    }

    public function installOS($taskid){
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();

            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $baremetalService = new \qzcloud\Baremetal();
            //$taskInfo['param']
            $baremetaModel = new BaremetalHost();
            $hostid = $taskInfo['param'];
            $host = $baremetaModel->find($hostid);
            $baremetalIpModel = new \app\common\model\BaremetalIp();
            $info = $baremetalIpModel->where(['ip'=>$host['ip']])->find();


            $nodelModel = new \app\common\model\BaremetalNode();
            $node = $nodelModel->where(['id'=>$host['node_id']])->find();

            $post_data['host_name'] = rand_string(15);
            $post_data['command'] = $taskInfo['command'];
            if($taskInfo['command'] == 'rescue'){
                $post_data['os_type'] = $host['rescue_type'];
            }elseif($taskInfo['command'] == 'password'){
                $post_data['os_type'] = "linux";
            }else{
                //镜像列表 可用的
                $mirrors = BaremetalMirrors::getListAll(['state'=>3,'node_id'=>$host['node_id'],'id'=>$host['os_id']]);
                if (empty($mirrors)){
                    throw new Exception('镜像不存在');
                }
                $mirrors = $mirrors['data'][0];
                $post_data['os_type'] = $mirrors['os_type'];
                $post_data['os_name'] = $mirrors['os_name'];
                $post_data['os_index'] = $mirrors['os_index'];
                $post_data['os_key'] = $mirrors['install_key'];
                //$post_data['remote_port'] = $mirrors['os_port'];
                $post_data['os_ver'] = $mirrors['os_ver'];
                $post_data['mirrors_dir'] = $mirrors['os_dir'];
                $post_data['disk_partition'] = $host['disk_partition'];
                $post_data['disk_partition_type'] = $host['disk_partition_type'];
            }

            $post_data['pxe_mac'] = $host['pxe_mac'];
            $post_data['ip'] = $host['ip'];
            $post_data['gateway'] = $info['gateway'];
            $post_data['netmask'] = $info['netmask'];
            $post_data['dns1'] = $host['dns1'];
            $post_data['dns2'] = $host['dns2'];
            $post_data['host_passwd'] = $host['os_password'];
            $post_data['ipmi_host'] = $host['ipmi_host'];
            $post_data['ipmi_user'] = $host['ipmi_user'];
            $post_data['ipmi_pass'] = $host['ipmi_passwd'];
            $post_data['remote_port'] = $host['remote_port'];
            $post_data['taskid'] = $taskid;
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);
            if($taskInfo['command'] == 'rescue'){
                $result = $baremetalService->rescue(
                    $post_data,$node);
            }elseif($taskInfo['command'] == 'passwd'){
                $result = $baremetalService->password(
                    $post_data,$node);
            }else{
                $result = $baremetalService->installOS(
                    $post_data,$node);
            }
            if ($result['code']!=200){
                throw new Exception($result['msg']);
            }
            return $result;
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }

    }
    //裸金属任务
    public function importISO($taskid){
        if(!$taskid) {
            return false;
        }
        try{
            $taskModel = new Task();
            $taskInfo = $taskModel->where(['id'=>$taskid,'is_delete'=>1,'state'=>0])->find();

            if(!$taskInfo){
                exit('taskid not exit taskid='.$taskid);
            }
            $mirrorsDetailModel =  new BaremetalMirrorsDetail();
            $mirrorsDetailInfo = $mirrorsDetailModel->where(['id'=>$taskInfo['param']])->find();

            if(empty($mirrorsDetailInfo)){
                exit('importISO  mirrorsDetail not found ');
            }

            $mirrorsModel =  new \app\common\model\BaremetalMirrors();
            $mirrorsInfo = $mirrorsModel->where(['id'=>$mirrorsDetailInfo['mirrors_id']])->find();
            if(empty($mirrorsInfo)){
                exit('importISO  mirrors not found ');
            }
            //第一步
            Ecs::setField(['id'=>$taskid,'is_delete'=>1,'state'=>0],['state'=>1,'start_time'=>date("Y-m-d H:i:s")]);

            $baremetalServeice = new Baremetal();
            $param['dir'] = '';
            $param['name'] = $mirrorsInfo['os_url'];
            $param['taskid'] = $taskid;
            $param['source'] = '';
            $baremetalNodeModel = new \app\common\model\BaremetalNode();
            $node = $baremetalNodeModel->where(['id'=>$mirrorsDetailInfo['node_id']])->find();
            if(empty($node)){
                exit('downISOFile  node not found ');
            }

            return $baremetalServeice->importISO($param,$node->toArray());
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
    }

}
?>
