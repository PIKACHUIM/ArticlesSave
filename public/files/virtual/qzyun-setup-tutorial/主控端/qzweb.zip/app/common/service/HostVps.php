<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\CheckOverdueVps;
use app\common\model\FirewallVps;
use app\common\model\ForwardDomainVps;
use app\common\model\ForwardPortVps;
use app\common\model\NetworkMonitorVps;
use app\common\model\ServersImageLine;
use app\common\model\VncPort;
use qzcloud\HyperV;
use qzcloud\Kvm;
use think\facade\Db;
use app\common\model\HostVps as M;
use app\common\validate\HostVps as V;
use think\facade\Session;

class HostVps
{
    // 添加
    public static function goAdd($params)
    {
        $os_password = $params["os_password"];
        $panel_password = $params["panel_password"];
        if(!isset($params["node_id"])){
            return ['msg'=>'请选择物理节点','code'=>201];
        }
        $line_id = $params["line_id"];
        $node_id = $params["node_id"];
        $os_id = $params["os_name"];
        //$username = $params["username"];


        $os_model = new \app\common\model\ServersImageConfig();
        $os_info = $os_model->where(['id'=>$os_id])->find();
        if(!$os_info){
            return ['msg'=>'系统不存在','code'=>201];
        }

        //拼装主机列表参数
        $lineModel = new \app\common\model\ServersLine(); //线路
        $nodeModel = new \app\common\model\ServersNode();//物理节点信息
        $areaModel = new \app\common\model\ServersArea();//地区信息
        $line = $lineModel->where(['id' =>$line_id])->find();

        $node = $nodeModel->where("id =" .$node_id)->find();
        $area = $areaModel->where(['id' => $line['area_id']])->find();
        if (!$node) {
            return ['msg'=>'节点不存在','code'=>201];
        }
        $param = [];

        //$param['product_id'] = ;
        $param['product_name'] = '';
        $param['host_name'] = $params['host_name'];
        $param['user_id'] = 0;
        $param['orderid'] = 0;
        $param['area_name'] = $area['area_name'];
        $param['area_id'] = $area['id'];
        $param['line_name'] = $line['line_name'];
        $param['line_id'] = $line['id'];
        $param['node_name'] = $node['node_name'];
        $param['node_id'] = $node['id'];
        $param['vlanid1'] = $node['vlan_id1'];
        $param['vlanid2'] = $node['vlan_id2'];
        $param['virtual_type'] = $node['virtual_type'];
        $param['from_type'] = 1; //自生产
        $param['buy_time'] = date("Y-m-d H:i:s");
        $param['end_time'] = $params['end_time'];
        $param['other_info'] = '';
        if(!empty(trim($params['ip']))){
            $param['ip'] = $params['ip']??'';
        }

        //显卡
        $param['gpu_capacity'] = $params['gpu_capacity'];
        $param['resolution'] = $params['resolution'];

        $param['open_gpu'] = isset($params['open_gpu'])?$params['open_gpu']:'';
        //裸金
        $param['metal'] = $params['metal']==1?2:1;

        $param['ipnum'] = 1;
        // $param['virtual_type'] = isset($product_config[3])&&$product_config[3]=='k'?'kvm':'hyper-v';

        $param['cpu'] = $params['cpu'];
        $param['memory'] = $params['memory'];
        $param['hard_disks'] = $params['hard_disks'];
        $param['bandwidth'] = $params['bandwidth'];
        if (isset($params['bandwidth_in'])){
            $param['bandwidth_in'] = $params['bandwidth_in'];
        }
        $param['os_name'] =$os_info->os_name ;
        $param['os_password'] =$os_password;
        $param['panel_password'] = $panel_password;
        $param['memory_dynamic'] = $params['ram_start']>0?1:0;
        $param['ram_start'] = $params['ram_start'];
        $param['cpu_limit'] = $params['cpu_limit'];
        $param['state'] = 1;//创建中
        $param['is_agent'] =  0;
        $param['os_disk_path'] = $node['os_path'];
        $param['os_disk_maxiops'] = $params['os_disk_maxiops'];
        $param['data_disk_path'] = $node['data_path'];
        $param['data_disk_maxiops'] = $params['data_disk_maxiops'];

        $param['os_read'] = $params['os_read'];
        $param['os_write'] = $params['os_write'];
        $param['data_read'] = $params['data_read'];
        $param['data_write'] = $params['data_write'];
        $param['is_vnc'] = $params['is_vnc'];

        $param['is_nat'] = $params['is_nat'];
        if ($param['is_nat'] == 1) { //挂机宝订单
            $param['port_num'] = isset($params['port_num'])?$params['port_num']:$line['port_num'];
            $param['domain_num'] =  isset($params['domain_num'])?$params['domain_num']:$line['domain_num'];
        }
        $param['snapshot_num'] = $params['snapshot_num'];
        $param['backup_num'] = $params['backup_num'];
        $param['max_reinstall_num'] = $params['max_reinstall_num'];
        $param['remark'] = '后台创建';

        try {
            Db::startTrans();
            Ecs::createVps($param);
            Db::commit();
        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 编辑
    public static function goEdit($data,$id)
    {
        $data['id'] = $id;
        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
        return ['msg'=>$validate->getError(),'code'=>201];
        try {
            $infoOld = M::find($id);
            Db::startTrans();
            Ecs::updateVps($data,$infoOld);
            Db::commit();

        }catch (\Exception $e){
            Db::rollback();
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //云主机重建
    public static function goRecreate($id){
        try {
            $model = M::find($id);
            Db::transaction(function ()use ($model) {
                Ecs::recreateVps(['hostid'=>$model->id]);
            });
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Db::transaction(function ()use ($model) {
                Ecs::delete_host(['hostid'=>$model->id]);
            });
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }
   // 强制删除
    public static function goDelete($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Db::transaction(function ()use ($model) {
                //节点虚拟机减去1
                //删除云主机记录
                //恢复ip 私网ip 公网ip  natip
                //删除流量表
                //删除端口映射表
                //删除域名白名单表
                //kvm 删除vnc端口
                $hostid = $model->id;
                try{
                    $host_vps_model =  new \app\common\model\HostVps();
                    $host = $host_vps_model ->where(['id'=>$hostid])->find();
                    if(empty($host)){
                        return ['code'=>200,'msg'=>''];
                    }
                    \think\facade\Log::info("admin remove host hostinfo=###".json_encode($host->toArray()).'##userinfo='.Session::get('admin.id'));

                    //删除私有ip
                    $serverIpv4PrivateModel = new \app\common\model\ServersIpv4Private();//私有ip
                    $serverIpv4PrivateModel->where(['v_name'=>$host->host_name])->update(['state'=>1,'v_name'=>'']);
                    //删除public ip
                    $serverIpv4Model = new \app\common\model\ServersIpv4();//独立ip
                    $serverIpv4Model->where(['v_name'=>$host->host_name])->update(['state'=>1,'v_name'=>'']);
                    //删除nat ip
                    $serverIpv4NatModel = new \app\common\model\ServersIpv4Nat();//natip
                    $serverIpv4NatModel->where(['v_name'=>$host->host_name])->update(['state'=>1,'v_name'=>'']);

                    //删除流量
                    $network_monitor_model =  new NetworkMonitorVps();
                    $network_monitor_model->where(['host_name'=>$host->host_name])->delete();

                    //删除端口映射表
                    $port_vps_model = new  ForwardPortVps();
                    $port_vps_model->where(['host_name'=>$host->host_name])->delete();

                    //删除域名
                    $domain_vps_model = new ForwardDomainVps();
                    $domain_vps_model->where(['host_name'=>$host->host_name])->delete();

                    //删除策略
                    $firewall_vps_model = new FirewallVps();
                    $firewall_vps_model->where(['host_name'=>$host->host_name])->delete();

                    //删除vnc端口
                    $vncPort = new VncPort();
                    $vncPort->where(['host_name'=>$host->host_name])->delete();


                    //删除检查表
                    $checkOverdueVps =  new CheckOverdueVps();
                    $checkOverdueVps->where(['host_id'=>$host->id])->delete();
                    $host_vps_model ->where(['id'=>$host->id])->delete();
                    return ['code'=>200,'msg'=>''];
                }catch (Exception $e){
                    throw new  Exception('line:'.$e->getLine()."msg:".$e->getMessage());
                }
            });
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 开机
    public static function goStart($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::startHost(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //关机
    public static function goClose($id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::closeHost(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //重启
    public static function goRestart($id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::restartHost(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //电源
    public static function goPower($id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::powerHost(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //锁定
    public static function goLock($id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::lockHost(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //解锁
    public static function goUnlock($id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::unlockHost(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //删除IP
    public static function goRemoveIp($ips,$id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        $ip = $model->ip;

        foreach ($ips['ip'] as $k=>$v){
            if($ip==$v){
                return ['msg'=>'主ip不能删除','code'=>201];
            }
        }
        try{
            Db::transaction(function ()use ($model,$ips) {
                $ipmodel = new \app\common\model\ServersIpv4();
                $ipmodel->whereIn('ip',$ips['ip'])->update(['state'=>1,'v_name'=>'']);
                Ecs::goBatSetip(['hostid'=>$model->id]);
            });
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    //删除IP
    public static function goAddIp($ids,$id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        $ids = $ids['ids'];
        try{
            Db::transaction(function ()use ($model,$ids) {
                $ipmodel = new \app\common\model\ServersIpv4();
                $ipmodel->whereIn('id',$ids)->where('state','=',1)->update(['state'=>2,'v_name'=>$model->host_name]);
                Ecs::goBatSetip(['hostid'=>$model->id]);
            });
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    public static function node_image($line_id){
        //获取节点 和镜像
        $imageList = ServersImageLine::getAllList(['line_id'=>$line_id]);

        $nodeList = \app\common\model\ServersNode::getAllList(['line_id'=>$line_id]);

        $lineInfo = \app\common\model\ServersLine::getOne($line_id);
        $data = ['image'=>[],'node'=>[]];
        foreach ($imageList['data'] as $k=>$v){
            $data['image'][] = ['id'=>$v['id'],'os_name'=>$v['os_name']];
        }

        foreach ($nodeList['data'] as $k=>$v){
            $data['node'][] = ['id'=>$v['id'],'node_name'=>$v['node_name'],'virtual_type'=>$v['virtual_type']];
        }

        $data['line'] = $lineInfo['data'];
        return ['code'=>200,'data'=>$data];
    }

    //删除IP
    public static function goResetNetwork($id){
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
            Ecs::resetNetwork(['hostid'=>$model->id]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }
}
