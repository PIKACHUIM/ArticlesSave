<?php
declare (strict_types = 1);

namespace app\common\service;

use app\common\model\ForwardPortVps;
use app\common\model\VncPort;
use qzcloud\HyperV;
use qzcloud\Kvm;
use think\facade\Request;
use app\common\model\ServersNode as M;
use app\common\validate\ServersNode as V;

class ServersNode
{
    // 添加
    public static function goAdd($data)
    {
        //验证
        $validate = new V;
        if(!$validate->scene('add')->check($data))
        return ['msg'=>$validate->getError(),'code'=>201];
        try {
            M::create($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }
    
    // 编辑
    public static function goEdit($data,$id)
    {
        $data['id'] = $id;
        //验证
        $validate = new V;
        if(!$validate->scene('edit')->check($data))
        return ['msg'=>$validate->getError(),'code'=>201];
        try {
             M::update($data);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 状态
    public static function goStatus($data,$id)
    {
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        try{
            $model->save([
                'state' => $data,
            ]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 删除
    public static function goRemove($id)
    {
        $model = M::find($id);
        if ($model->isEmpty()) return ['msg'=>'数据不存在','code'=>201];
        try{
           $model->delete();
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 批量删除
    public static function goBatchRemove($ids)
    {
        if (!is_array($ids)) return ['msg'=>'数据不存在','code'=>201];
        try{
            M::destroy($ids);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    // 获取列表
    public static function getInfo($id)
    {
        $model =  M::find($id);
        return ['code'=>200,'data'=>$model->toArray()];
    }

    public static function forwardip($forward_url,$id){
        $model =  M::find($id);
        if ($model->isEmpty())  return ['msg'=>'数据不存在','code'=>201];
        $oldurl = $model['forward_url'];
        try{
            $model->save([
                'forward_url' => $forward_url,
            ]);
            //cloud_forward_port_vps  api_url
            $portModel = new ForwardPortVps();
            $portModel->where(['api_url'=>$oldurl])->save(['api_url'=>$forward_url]);
        }catch (\Exception $e){
            return ['msg'=>'操作失败'.$e->getMessage(),'code'=>201];
        }
    }

    public static function resetForwardPort($id){
        $hostModel = new \app\common\model\HostVps();
        $hostList = $hostModel->where(['is_nat'=>1,'node_id'=>$id])->select();
        $forwardPortVps = new ForwardPortVps();
        $model =  M::find($id);
        if($model['virtual_type']=='hyper-v'){
            $vm = new HyperV();
        }else{ //kvm
            $vm = new Kvm();
        }

        foreach ($hostList as $k=>$v){
            $list = $forwardPortVps->where(['host_name'=>$v['host_name']])->select();
            foreach ($list  as $k1=>$v1){
                $vm->removeForwardPort($model->toArray(),['dip'=>$v1['dip'],'sport'=>$v1['sport'],'dport'=>$v1['dport'],'host_name'=>$v1['host_name']]);
                $vm->addForwardPort($model->toArray(),['dip'=>$v1['dip'],'sport'=>$v1['sport'],'dport'=>$v1['dport'],'host_name'=>$v1['host_name']]);
            }
        }
    }

    public static function vmlist($param){
        $id = $param['id'];
        $model =  M::find($id);
        if($model['virtual_type']=='hyper-v'){
            $vm = new HyperV();
        }else{ //kvm
            $vm = new Kvm();
            return ['code'=>0,'data'=>[],'extend'=>[]];
        }
        $result = $vm->GetNetworkMonitoring($model->toArray());

        $limit = input('get.limit',10);
        $page = input('get.page',1);
        if ($result['code']!=200){
            return ['code'=>0,'data'=>[],'extend'=>[]];
        }
        $data = [];
        foreach ($result['data'] as $k=>$v){
            $data[] = ['host_name'=>$k,'out'=>$v[0].'KB/s','in'=>$v[1].'KB/s'];
        }
        $count = count($data);
        $start = ($page-1)*$limit;
        $pageC = array_slice($data,$start,$limit);
        return ['code'=>0,'data'=>$pageC,'extend'=>['count' =>$count, 'limit' => $limit]];

    }
}
