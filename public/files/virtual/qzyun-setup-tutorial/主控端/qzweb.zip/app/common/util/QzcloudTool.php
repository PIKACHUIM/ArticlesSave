<?php

namespace app\common\util;

use app\common\model\RandString;
use think\Db;
use think\Exception;
use think\facade\Template;
use think\facade\View;

class QzcloudTool{

    //唯一的随机字符串
    static  function getUniqueStr($type='host_name',$length =8,$prefix='',$string='FDSAZXCVBNMqwertyuioQWERTYUIOPLKJHGplkjhgfdsazxcvbnm'){
        try{
            if(!empty($prefix)){
                $prefix = $prefix.'-';
            }
            $randStringModel = new RandString();
            $m=0;
            $strlen=strlen($string)-1;
            while(true){
                $m++;
                $temp ='';
                for ($i=0;$i<$length;$i++){
                    $temp.=$string[rand(0,$strlen)];
                }
                $count = $randStringModel ->where(['type'=>$type,'value'=>$prefix.$temp])->count();
                if(!$count){
                    $res = $randStringModel->save(['type'=>$type,'value'=>$prefix.$temp]);
                    if(!$res){
                        throw new Exception('生成随机字符串异常');
                    }
                    break;
                }
                if($m==1000){
                    throw new Exception('生成随机字符串异常');
                    break;
                }
            }
        }catch (Exception $e){
            throw new Exception($e->getMessage());
        }
        return $prefix.$temp;
    }

    //随机字符串 不保证唯一
    static  function generatePassword( $length = 8 ,$chars='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789') {
        // 密码字符集，可任意添加你需要的字符

        $password = '';
        $strlen = strlen($chars) - 1;


        $password = '';
        $password1 =array();
        $strlen = strlen($chars) - 1;
        if($chars=='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'&&$length>7){
            $str ='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            while (true){
                $rand = $str[ mt_rand(0,25 ) ];
                if(in_array($rand,$password1)){
                    continue;
                }
                $password .= $rand;
                $password1[]=$rand;
                if(count($password1)==2){
                    $password1 =[];
                    break;
                }
            }
            $str ='abcdefghijklmnopqrstuvwxyz';
            while (true){
                $rand = $str[ mt_rand(0,25 ) ];
                if(in_array($rand,$password1)){
                    continue;
                }
                $password .= $rand;
                $password1[]=$rand;
                if(count($password1)==2){
                    $password1 =[];
                    break;
                }
            }
            $str1 ='0123456789';
            while (true){
                // 这里提供两种字符获取方式
                // 第一种是使用 substr 截取$chars中的任意一位字符；
                // 第二种是取字符数组 $chars 的任意元素
                // $password .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
                $rand = $str1[ mt_rand(0,9) ];
                if(in_array($rand,$password1)){
                    continue;
                }
                $password .= $rand;
                $password1[]=$rand;
                if(count($password1)==2){
                    $password1 =[];
                    break;
                }
            }

            for ( $i = 0; $i < $length-6; $i++ ) {
                // 这里提供两种字符获取方式
                // 第一种是使用 substr 截取$chars中的任意一位字符；
                // 第二种是取字符数组 $chars 的任意元素
                // $password .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
                $password .= $chars[ mt_rand(0,$strlen) ];
            }
            $password=str_split($password,1);
            shuffle($password);
            return implode('',$password);
        }

        for ( $i = 0; $i < $length; $i++ ) {
            // 这里提供两种字符获取方式
            // 第一种是使用 substr 截取$chars中的任意一位字符；
            // 第二种是取字符数组 $chars 的任意元素
            // $password .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
            $password .= $chars[ mt_rand(0,$strlen ) ];
        }

        return $password;
    }

    //计算自然月 到期时间
    static  function getDateMonth($nowDate,$month){
        $dateYm =date("Y-m",strtotime($nowDate));
        $newDateYm = date("Y-m",strtotime("+{$month}month",strtotime($dateYm)));
        $newDateD= $dateYm =date("d",strtotime($nowDate));
        $firstday = date('Y-m-01', strtotime($newDateYm));
        $lastDay = date('d', strtotime("$firstday +1 month -1 day"));
        $newDate = $newDateYm.'-'.(($lastDay>$newDateD)?$newDateD:$lastDay);
        return $newDate;
    }

    //随机取挂机宝端口范围 也可用作验证端口是否可用 

    /**
     * 不能并发
     * @param int $maxPort 最大端口范围
     * @param int $minPort 最小端口范围
     * @param array $neqPort 要排除的端口 不筛选
     * @param $limit 要返回几个可用端口
     * @param $api //用来转发的节点api是
     * @param $like //查找类似端口
     * @author xem
     * @throws \think\db\exception\BindParamException
     * @throws \think\exception\PDOException
     *
     */
    static  function getPort($maxPort=50000,$minPort=10000,$api='',$keywords='',$limit=20,$neqPort=[],$like=true){
        $where ='';
        if($neqPort){
            $where =' and  a.public_port not in('.implode(',',$neqPort).')';
        }
        if($keywords){
            if($like){
                $where ="and  a.public_port like '%$keywords%'" ;
            }else{
                $where ="and  a.public_port = '$keywords'" ;
            }
        }
        $sql = "SELECT * from cloud_port_template a LEFT JOIN (select * from cloud_forward_port_vps where api_url='$api') b
                on a.public_port=b.sport where (b.sport='' or  b.sport is null) and a.public_port>=$minPort and a.public_port<=$maxPort $where limit 0,$limit";
        $result = \think\facade\Db::query($sql);
        if(!$result){
            return [];
        }
        return array_column($result,'public_port');
    }

   //vnc端口
    static  function getVncPort($maxPort=60000,$minPort=50001,$vnc_url='',$keywords='',$limit=1,$neqPort=[],$like=true){
        $where ='';
        if($neqPort){
            $where =' and  a.public_port not in('.implode(',',$neqPort).')';
        }
        if($keywords){
            if($like){
                $where ="and  a.public_port like '%$keywords%'" ;
            }else{
                $where ="and  a.public_port = '$keywords'" ;
            }
        }
        $sql = "SELECT * from cloud_port_template a LEFT JOIN (select * from cloud_vnc_port_vps where vnc_url='$vnc_url') b
                on a.public_port=b.port where (b.port='' or  b.port is null) and a.public_port>=$minPort and a.public_port<=$maxPort $where limit 0,$limit";
        $result = \think\facade\Db::query($sql);
        if(!$result){
            return '';
        }
        return $result[0]['public_port'];
    }

    static function createForm($param){
        $type= isset($param['type'])?$param['type']:'text';
        $name= isset($param['name'])?$param['name']:'';
        $placeholder= isset($param['placeholder'])?$param['placeholder']:'';
        $description= isset($param['description'])?$param['description']:'';
        $default= isset($param['default'])?$param['default']:'';
        $key= isset($param['key'])?$param['key']:'';
        $options = isset($param['options'])?$param['options']:'';
        $rows = isset($param['rows'])?$param['rows']:'';
        $cols = isset($param['cols'])?$param['cols']:'';
        $yesno = isset($param['yesno'])?$param['yesno']:'';
        $input ='';

        if($type=='text'||$type=='password'){
            $input = '<input type="'.$type.'" placeholder="'.$placeholder.'" value="'.$default.'" name="'.$key.'" class="layui-input">';
        }

        if($type=='yesno'){
            $checked='';
            if(!empty($yesno)){
                $checked = 'checked="checked"';
            }
            $input = '<input '.$checked.' type="checkbox" lay-skin="primary"  name="'.$key.'"   value="'.$default.'">';
        }

        if($type=='radio'){
            $options = explode(',',$options);
            foreach ($options as $k=>$v){
                $checked='';
                if(empty($options))continue;
                if($v==$default){
                    $checked = 'checked="checked"';
                }
                $input .= '<input '.$checked.' type="radio" name="'.$key.'" value="'.$v.'" title="'.$v.'">';
            }

        }

        if($type=='dropdown'){
            if(is_array($options)){
                $input .= '<select name="'.$key.'"> <option value=""></option>';
                foreach ($options as $k=>$v){
                    $selected='';
                    if($k==$default){
                        $selected = 'selected="selected"';
                    }
                    $input+='<option '.$selected.' value="'.$k.'">'.$v.'</option>';
                }
            }
            $input .= ' </select>';
        }

        if($type=='textarea'){
            $input = '<textarea rows="'.$rows.'" cols=""'.$cols.' placeholder="'.$placeholder.'" name="'.$key.'" class="layui-input">'.$default.'</textarea>';
        }

        return '<div class="layui-col-md6">
                    <div class="layui-form-item">
                        <label class="layui-form-label">'.$name.'</label>
                        <div class="layui-input-inline">
                            '.$input.'
                        </div>
                        <span class="radioremark">'.$description.'</span>
                    </div>
                </div>';
        
    }

  static  function  getUuid()
    {
        $chars = md5(uniqid(mt_rand(), true));
        $uuid = substr ( $chars, 0, 8 ) . '-'
            . substr ( $chars, 8, 4 ) . '-'
            . substr ( $chars, 12, 4 ) . '-'
            . substr ( $chars, 16, 4 ) . '-'
            . substr ( $chars, 20, 12 );
        return $uuid ;
    }

    static function encrypt($data, $key) {
        $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
        $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, 0, $iv);
        return base64_encode($encrypted . '::' . $iv);
    }

// 解密
    static  function decrypt($data, $key) {
        list($encryptedData, $iv) = explode('::', base64_decode($data), 2);
        return openssl_decrypt($encryptedData, 'aes-256-cbc', $key, 0, $iv);
    }

    static function getSwitchCommand($content,$hostid){
        $prefix = \think\facade\Config::get('database.connections.mysql.prefix');
        $host = $hostModel = \think\facade\Db::table($prefix.'baremetal_host')->where(['id'=>$hostid])->find();
        if (empty($host)){
            return "";
        }
        $iplist = $hostModel = \think\facade\Db::table($prefix.'baremetal_ip')->where(['host_id'=>$hostid])->select();
        $param['Mac'] =$host['pxe_mac'];
        $param['PortName'] =$host['switch_port'];
        $param['Vlan'] =$host['vlanid'];
        $param['IPList'] = $iplist;
        $param['Description'] =$host['uuid'];
        $param['OutBound'] =$host['bandwidth'];
        $param['InBound'] =$host['bandwidth_in'];
        $view = View::instance();
        $content = preg_replace('/[\r\n]+/', '$$$', $content);
        $content = $view->display($content,$param);
        $content = str_replace("$$$","\n",$content);
        return  preg_replace('/^\s*[\r\n]+/m', '', $content);
    }

}
?>