<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class BaremetalNode extends Validate
{
    protected $rule = [
        'name|控制器名称' => 'require',
        'area_id|机房' => 'require',
        'api_url|api' => 'require',
        'vnc_url|vnc地址' => 'require',
        'ftp_user|ftp用户' => 'require',
        'ftp_passwd|ftp密码' => 'require',
        'apikey|apikey' => 'require',
    ];

    protected $message = [
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only(['name','area_id','api_url','vnc_url','ftp_user','ftp_passwd','apikey']);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only(['name','api_url','vnc_url','ftp_user','ftp_passwd','apikey']);
    }
}
