<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class BaremetalSeat extends Validate
{
    protected $rule = [
        'number|机位' => 'require|unique:baremetal_seat,number',
        'cabinet_id|机柜' => 'require',
        'state|状态' => 'require',

    ];

    protected $message = [
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only(['number,cabinet_id','state']);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only(['state']);
    }
}
