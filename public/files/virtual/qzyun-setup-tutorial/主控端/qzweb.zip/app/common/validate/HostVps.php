<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class HostVps extends Validate
{
    protected $rule = [
    ];

    protected $message = [];

    /**
     * 添加
     */
    public function sceneAdd()
    {

    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {

    }
}
