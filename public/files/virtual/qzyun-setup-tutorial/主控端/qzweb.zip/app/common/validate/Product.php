<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class Product extends Validate
{

    /**
     * 验证规则
     */
    protected $rule = [
        'product_name'=>['require'],
        'gpu_capacity'=>['gpuResolution'],
        'is_nat'=>['require','checkDomain'],
    ];
    /**
     * 提示消息
     */

    protected $message = [

    ];

    public function gpuResolution($value,$rule='',$data){
        if($value==0){
            return true;
        }
        if(!$data['gpu_resolution']){
            return '您选择了显卡内存就必须选择分辨率';
        }
        return true;
    }

    public function checkDomain($value,$rule='',$data){
        if($value==0){
            if($data['ipnum']<1){
                return '独立ip的云主机ip数量必须大于0';
            }
            return true;
        }
        return true;
    }

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only([]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only([]);
    }
}
