<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class ServersImageConfig extends Validate
{
    protected $rule = [
        'os_name' => 'require|unique:servers_image_config',
        'file_name' => 'require',
        'os_type' => 'require|number',
        'sort' => 'require|number',
    ];

    protected $message = [
        'os_name.require' => '统系文件名为必填项',
        'os_name.unique' => '统系文件名已存在',
        'os_type.require' => '统系类型为必填项',
        'os_type.number' => '统系类型需为数字',
        'sort.require' => '排序为必填项',
        'sort.number' => '排序需为数字',
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only(['os_name','file_name','os_type','sort','remark',]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only(['os_name','file_name','os_type','sort','remark',]);
    }
}
