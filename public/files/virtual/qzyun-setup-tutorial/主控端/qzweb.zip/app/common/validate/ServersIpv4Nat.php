<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class ServersIpv4Nat extends Validate
{
    protected $rule = [
        'ip'  => ['require'],
        'netmask'  => ['require','regex'=>'/^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])(\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])){3}$/'],
        'gateway'  => 'require|ip',
    ];

    protected $message = [
        'ip.require' =>'IP必填',
        'ip.regex' =>'IP为单个或者ip段格式',
        'netmask.require' =>'掩码必填',
        'netmask.regex' =>'掩码格式不正确',
        'gateway.require' =>'网关必填',
        'gateway.ip' =>'网关格式不正确',
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only([]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only([]);
    }
}
