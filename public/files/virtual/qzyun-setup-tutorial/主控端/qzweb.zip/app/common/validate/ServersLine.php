<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class ServersLine extends Validate
{
    protected $rule = [
        'line_name'=>'require|unique:servers_line',
        'area_id'=>'require',
    ];
    protected $message = [
        'line_name.require' =>'线路名称必填',
        'line_name.unique' => '线路名称已存在',
        'area_id.require' =>'区域必选',
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only([]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only([]);
    }
}
