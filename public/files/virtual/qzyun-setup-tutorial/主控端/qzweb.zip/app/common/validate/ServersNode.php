<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class ServersNode extends Validate
{
    protected $rule = [
        'line_id'=>['require'],
        'ip_pool_name'=>['require'],
        'node_name'=>['require'],
        'node_ip'=>['require'],
        'max_vm_number'=>['require','number'],
        'os_iops_min'=>['require','number'],
        'os_iops_max'=>['require','number'],
        'data_iops_min'=>['require','number'],
        'data_iops_max'=>['require','number'],
        'template_path'=>['require'],
        'data_path'=>['require'],
        'iso_path'=>['require'],
        'vlan_id1'=>['number'],
        'vlan_id2'=>['number'],
        'host_delete_day'=>['number'],
        'weight'=>['require','number'],
        'apikey'=>['require'],
        'dns1'=>['require','ip'],
        'dns2'=>['require','ip'],

    ];
    /**
     * 提示消息
     */

    protected $message = [
        'line_id.require' =>'线路必选',
        'ip_pool_name.require' =>'IP池必选',
        'node_name.require' =>'节点名必填',
        'node_ip.require' =>'通信ip必填',
        'max_vm_number.require' =>'最大主机数量必填',
        'max_vm_number.number' =>'最大主机数量为数字',
        'os_iops_min.require' =>'系统最小iops必填',
        'os_iops_min.number' =>'系统最小iops为数字',
        'data_iops_max.require' =>'系统最大iops必填',
        'data_iops_max.number' =>'系统最大iops数字',
        'template_path.require' =>'系统模板目录必填',
        'data_path.require' =>'数据存放目录必填',
        'iso_path.require' =>'iso文件存放目录必填',
        'vlan_id1.number' =>'网卡1vlanid为数字',
        'vlan_id2.number' =>'网卡2vlanid为数字',
        'host_delete_day.number' =>'到期删除天数为数字',
        'weight.require' =>'节点权重必填',
        'weight.number' =>'节点权重为数字',
        'apikey.require' =>'受控通讯节点apikey必填',
        'dns1.require' =>'dns1必填',
        'dns2.require' =>'dns2必填',
        'dns1.ip' =>'默认dns1格式不正常',
        'dns2.ip' =>'默认dns2格式不正常',
    ];
    /**
     * 添加
     */
    public function sceneAdd()
    {

    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {

    }
}
