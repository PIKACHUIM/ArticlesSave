<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class UserLog extends Validate
{
    protected $rule = ['user_id' => 'require|number','username' => 'require','url' => 'require','title' => 'require','content' => 'require','ip' => 'require','useragent' => 'require','createtime' => 'require|number',
    ];

    protected $message = ['user_id.require' => '用户ID为必填项','user_id.number' => '用户ID需为数字','username.require' => '管理员名字为必填项','url.require' => '操作页面为必填项','title.require' => '日志标题为必填项','content.require' => '内容为必填项','ip.require' => 'IP为必填项','useragent.require' => 'User-Agent为必填项','createtime.require' => '操作时间为必填项','createtime.number' => '操作时间需为数字',
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only(['user_id','username','url','title','content','ip','useragent','createtime',]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only(['user_id','username','url','title','content','ip','useragent','createtime',]);
    }
}
