<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class VirhostNode extends Validate
{
    protected $rule = [
        'node_name'  => ['require'],
        'node_ip'  => ['require'],
        'line_id'  => ['require'],
        'wwwroot'  => ['require'],
        'apikey'  => ['require'],
    ];

    protected $message = [
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only([]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only([]);
    }
}
