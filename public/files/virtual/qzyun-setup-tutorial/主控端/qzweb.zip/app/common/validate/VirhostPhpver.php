<?php
declare (strict_types = 1);

namespace app\common\validate;

use think\Validate;
class VirhostPhpver extends Validate
{
    protected $rule = [
        'php_name'  => ['require'],
        'php_ver'  => ['require'],
        'php_path'  => ['require'],
    ];

    protected $message = [
    ];

    /**
     * 添加
     */
    public function sceneAdd()
    {
        return $this->only([]);
    }

    /**
     * 编辑
     */
    public function sceneEdit()
    {
        return $this->only([]);
    }
}
