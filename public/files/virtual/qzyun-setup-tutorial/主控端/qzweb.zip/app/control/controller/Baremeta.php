<?php

namespace app\control\controller;

use app\common\model\BaremetalBusiness;
use app\common\model\BaremetalHost;
use app\common\model\BaremetalMirrors;
use app\common\model\BaremetalNode;
use app\common\model\ServersArea;
use app\common\service\BaremetalIp;
use app\common\util\HttpRequest;
use think\App;
use think\facade\Session;
use think\Log;
use think\Request;

/**
 * 云主机管理
 *
 * @icon fa fa-dashboard
 * @remark  云主机管理
 */
class Baremeta extends \app\BaseController
{
    protected $noNeedLogin = ['login'];

    protected function initialize()
    {
        $baseUrl = $this->request->baseUrl();
        $baseUrlArr = explode('baremeta',$baseUrl);
        $rootUrl = $this->request->domain().$baseUrlArr[0]."baremeta/";
        $this->assign('rootUrl',$rootUrl);
        $arr = $this->noNeedLogin;
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        //判断权限
        $hostid = $this->request->param('hostid');
        $host_id = $this->request->param('host_id');
        $host_id =  $hostid?$hostid:$host_id;
        $this->assign('hostid',$host_id);

        if ($arr) {
            $arr = array_map('strtolower', $arr);
            // 是否存在
            if (in_array(strtolower($this->request->action()), $arr) || in_array('*', $arr)) {
                return true;
            }
        }
        $act = ['powerOn','powerOff','restart','resetbmc','startVnc','reinstallOs','rescue','systemPasswd'];
        $hostModel = new BaremetalHost();
        $host = $hostModel->where(['id'=>$host_id])->find();
        //installos,power,resetpasswd,vnc,pe
        if(in_array($this->request->action(),$act)){
            if ($host['auto']!=1){
                $this->error('暂不开放该功能');
            }

            if (in_array($this->request->action(),['powerOn','powerOff','restart','resetbmc'])){
                if (strstr($host['funs'],"power")===false){
                    $this->error('暂不开放该功能');
                }
            }

            if (in_array($this->request->action(),['startVnc'])){
                if (strstr($host['funs'],"vnc")===false){
                    $this->error('暂不开放该功能');
                }
            }

            if (in_array($this->request->action(),['reinstallOs'])){
                if (strstr($host['funs'],"installos")===false){
                    $this->error('暂不开放该功能');
                }
            }

            if (in_array($this->request->action(),['rescue'])){
                if (strstr($host['funs'],"pe")===false){
                    $this->error('暂不开放该功能');
                }
            }

            if (in_array($this->request->action(),['systemPasswd'])){
                if (strstr($host['funs'],"resetpasswd")===false){
                    $this->error('暂不开放该功能');
                }
            }

        }

        $admin = Session::get('admin');
        if ($admin) {
            return true;
        }

        $baremetal_host = session('baremetal_host');

        if(empty($host_id)){
            $this->error('参数不正确');
        }

        if(empty($baremetal_host)){
            $this->error('未登陆或已退出登陆');
        }
        if($host->id!=$baremetal_host->host_id){
            $this->error('权限不足');
        }

    }

    //登录控制台
    public function login(){
        $host_name = $this->request->param('host_name','','trim');
        $panel_password = $this->request->param('panel_password','','trim');
        $model =  new BaremetalBusiness();
        $info = $model->where(['user'=>$host_name,'passwd'=>$panel_password])->find();
        $site = config('web');
        $domian = '';
        if(isset($site['apiurl'])){
            $domian = $site['apiurl'];
        }
        if($info){
            session('baremetal_host',$info);
        }else{
            $this->error('登陆失败',$domian.url('control/index/index'));
        }
        $forward_url =url('control/baremeta/index',['hostid'=>$info->host_id],false);
        if($this->request->isAjax()){
            $this->success('登陆成功',$forward_url);
        }else{
            //header('Location: '.$forward_url);
            return  redirect($forward_url) ;
        }
    }

    public function index($hostid=0){
        $baremetaModel = new BaremetalHost();
        $businessModel = new BaremetalBusiness();
        $host = $baremetaModel->find($hostid);
        if (empty($host)){
            $this->error("不存在的云主机");
        }
        $areaModel = new ServersArea();
        $area = $areaModel->find($host['area_id']);
        $business = $businessModel->where(['host_id'=>$hostid])->find();

        //镜像列表 可用的
        $mirrors = [];
        if (!empty($host['node_id'])){
            $mirrors = BaremetalMirrors::getListAll(['state'=>3,'node_id'=>$host['node_id']]);
        }
        $mirrors_data = [];
        foreach ($mirrors['data'] as $k=>$v){
            unset($v['os_passwd']);
            $mirrors_data[$v['os_type']][] = $v;
        }
        return $this->fetch('',['host'=>$host,'business'=>$business,'area'=>$area,'mirrors_data'=>$mirrors_data]);
    }

    public function allotIp($hostid){
        if (\think\facade\Request::isAjax()) {
            return $this->getJson(BaremetalIp::getIpPageList());
        }
        return $this->fetch();
    }

    public function startVnc($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->startVnc(['hostid'=>$hostid]);
        if($data['code']==200){
            $this->success('启动vnc命令执行成功','',"/vnc/index.htm?path=".$data['data']['url']);
        }else{
            $this->error($data['msg']);
        }
    }


    public function flushVnc($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->flushVnc(['hostid'=>$hostid]);
        if($data['code']==200){
            $this->success('刷新vnc命令执行成功','',"/vnc/index.htm?path=".$data['data']['url']);
        }else{
            $this->error($data['msg']);
        }
    }

    public function powerOn($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->powerOn($hostid);
        if($data['code']==200){
            $this->success('开机命令执行成功','');
        }else{
            $this->error($data['msg']);
        }
    }

    public function powerOff($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->powerOff($hostid);
        if($data['code']==200){
            $this->success('关机命令执行成功','');
        }else{
            $this->error($data['msg']);
        }
    }

    public function restart($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->restart($hostid);
        if($data['code']==200){
            $this->success('重启命令执行成功','');
        }else{
            $this->error($data['msg']);
        }
    }

    public function resetbmc($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->resetbmc($hostid);
        if($data['code']==200){
            $this->success('重置bmc命令执行成功','');
        }else{
            $this->error($data['msg']);
        }
    }

    public function runingStatus($hostid){
        $logic = new \app\common\service\Baremetal();
        $data = $logic->runingStatus($hostid);
        if($data['code']==200){
            $this->success('success','',$data['data']);
        }else{
            $this->error($data['msg'],'',['status'=>'']);
        }
    }

    public function reinstallOs($hostid){
        $osid = $this->request->param('os_id');
        $baremetalHostlogic = new BaremetalHost();
        $host = $baremetalHostlogic->find($hostid);
        if (empty($host)){
            $this->error('未找到主机');
        }
        $mirrors = BaremetalMirrors::getListAll(['id'=>$osid]);
        if (empty($mirrors['data'])){
            $this->error('未找到镜像');
        }
        $is_show = false;
        $oldname = '没有安装过操作系统';
        $osType = 'linux';
        if (empty($host['os_id'])){
            $is_show = true;
        }else{
            $oldmirrors = BaremetalMirrors::getListAll(['id'=>$host['os_id']]);
            if (isset($oldmirrors['data'])&&isset($oldmirrors['data'][0])){
                $oldname =  $oldmirrors['data'][0]['os_name'];
                $osType = $oldmirrors['data'][0]['os_type'];
            }
        }

        $mirrors = BaremetalMirrors::getListAll(['id'=>$osid]);
        if (empty($mirrors['data'])){
            $this->error('未找到镜像');
        }
        if ($osType !=$mirrors['data'][0]['os_type']){
            $is_show = true;
        }

        $part = explode(',',$mirrors['data'][0]['os_partition']);
        $partArr = [];
        foreach ($part as $k=>$v){
            $v_=explode(':',$v);
            $temp['mount'] = isset($v_[0])?$v_[0]:'';
            $temp['format'] = isset($v_[1])?$v_[1]:'';
            $temp['size'] =isset($v_[2])?($v_[2]=='extend'?'':$v_[2]):'';
            $partArr[]=$temp;
        }

        if($mirrors['data'][0]['os_type']!="windows"){
            $ext = BaremetalNode::$osLinixPartitionFormat;
        }else{
            $ext = BaremetalNode::$osWindowsPartitionFormat;
        }

        if (\think\facade\Request::isAjax()) {
            $logic = new \app\common\service\Baremetal();
            $param = $this->request->param();
            return $this->getJson($logic->installOS($param));
        }

        return $this->fetch('',[
            'osInfo'=>isset($mirrors['data'][0])?$mirrors['data'][0]:[],
            'is_show'=>$is_show,
            'old_osname'=>$oldname,
            'new_osname'=>$mirrors['data'][0]['os_name'],
            'part'=>$partArr,
            'ext'=>$ext,
        ]);
    }

    public function rescue($hostid){
        $rescue_os_type = $this->request->param('rescue_os_type');
        $baremetalHostlogic = new BaremetalHost();
        $host = $baremetalHostlogic->find($hostid);
        if (empty($host)){
            $this->error('未找到云主机');
        }

        if (!in_array($rescue_os_type,['linux','windows'])){
            $this->error('类型错误');
        }

        if (\think\facade\Request::isAjax()) {
            $logic = new \app\common\service\Baremetal();
            $param = $this->request->param();
            return $this->getJson($logic->rescue($param));
        }
    }

    public function panelPassword(){
        $param = $this->request->param();
        $panel_password = $param['passwd'];
        if(empty($panel_password)){
            $this->error('新的版面密码不能为空');
        }
        $host_mode = new BaremetalBusiness();
        $host_mode->where(['host_id'=>$param['hostid']])->save(['passwd'=>$panel_password]);
        $this->success('修改密码成功');
    }

    public function systemPasswd($hostid){
        $baremetalHostlogic = new BaremetalHost();
        $host = $baremetalHostlogic->find($hostid);
        if (empty($host)){
            $this->error('未找到云主机');
        }

        if (\think\facade\Request::isAjax()) {
            $logic = new \app\common\service\Baremetal();
            $param = $this->request->param();
            return $this->getJson($logic->systemPasswd($param));
        }
    }
}
?>