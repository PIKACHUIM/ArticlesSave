<?php

namespace app\control\controller;


/**
 * 云主机管理
 *
 * @icon fa fa-dashboard
 * @remark  云主机管理
 */
class Index  extends \app\BaseController
{
    public function index()
    {
        return $this->fetch();
    }
}
