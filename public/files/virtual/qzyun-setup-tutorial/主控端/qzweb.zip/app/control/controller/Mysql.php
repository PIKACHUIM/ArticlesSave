<?php

namespace app\control\controller;

use app\common\model\VirhostDatabase;
use app\common\model\VirhostNode;
use app\common\util\HttpRequest;
use think\App;
use think\Exception;
use think\facade\Session;

/**
 * 虚拟主机管理
 *
 * @icon fa fa-dashboard
 * @remark  虚拟主机管理
 */
class Mysql extends \app\BaseController
{
    protected $noNeedLogin = ['get_panel_password', 'login', 'index'];

    protected function initialize()
    {
        $id= $this->request->param('id');
        $this->assign("id",$id);

        $database_model = new VirhostDatabase();
        $database = $database_model->find($id);
        $this->assign("database",$database);
        if($database){
            $node_model = new VirhostNode();
            $node = $node_model->where(['id'=>$database['node_id']])->find();
            $this->assign("node",$node);
        }

        $baseUrl = $this->request->baseUrl();
        $baseUrlArr = explode('mysql',$baseUrl);
        $rootUrl = $this->request->domain().$baseUrlArr[0]."mysql/";
        $this->assign('rootUrl',$rootUrl);
        $arr = $this->noNeedLogin;
        $arr = is_array($arr) ? $arr : explode(',', $arr);
        if ($arr) {
            $arr = array_map('strtolower', $arr);
            // 是否存在
            if (in_array(strtolower($this->request->action()), $arr) || in_array('*', $arr)) {
                return true;
            }
        }

        $admin = Session::get('admin');
        if ($admin) {
            return true;
        }

        //判断权限
        if(empty($id)){
            $this->error('参数不正确');
        }

        if(empty($database)){
            $this->error('mysql不存在');
        }

        $mysqlinfo = session('mysqlinfo');
        if(empty($mysqlinfo)){
            $this->error('未登陆或已退出登陆');
        }
        if($database->id!=$mysqlinfo->id){
            $this->error('权限不足');
        }

    }

    //登录控制台
    public function login(){
        $dataname = $this->request->param('dataname','','trim');
        $datapasswd = $this->request->param('datapasswd','','trim');
        $database_model=  new VirhostDatabase();
        $info = $database_model->where(['dataname'=>$dataname,'datapasswd'=>$datapasswd,'datatype'=>1])->find();
        $site = config('web');
        $domian = '';
        if(isset($site['apiurl'])){
            $domian = $site['apiurl'];
        }
        if($info){
            session('mysqlinfo',$info);
        }else{
            $this->error('登陆失败',$domian.url('control/index/index'));
        }
        $forward_url =url('control/mysql/index',['id'=>$info->id],false);
        if($this->request->isAjax()){
            $this->success('登陆成功',$forward_url);
        }else{
            //header('Location: '.$forward_url);
            return  redirect($forward_url) ;
        }
    }

    public function index($id)
    {

        return $this->fetch('',['id'=>$id]);
    }

    public function mysqlinfo($id){
        $mysql_model = new VirhostDatabase();
        $mysql_info = $mysql_model->where(['id'=>$id,'datatype'=>1])->find();
        if(empty($mysql_info)){
            $this->error('没有找到数据库');
        }

        $node_model = new VirhostNode();
        $node = $node_model->where(['id'=>$mysql_info['node_id']])->find();
        return $this->fetch('',['id'=>$id,'mysqlinfo'=>$mysql_info,'nodeinfo'=>$node]);
    }

    public function change_passwd($id){
        if($this->request->isAjax()){
            $password = $this->request->param('password');
            if(empty($password)){
                $this->error('密码为空');
            }
            try{
                \app\common\service\HostSite::changeMysqlPasswd(['id'=>$id,'password'=>$password]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");
        }
    }

    public function mysqltool($id){
        $mysql_model = new VirhostDatabase();
        $mysql_info = $mysql_model->where(['id'=>$id,'datatype'=>1])->find();
        if(empty($mysql_info)){
            $this->error('没有找到数据库');
        }

        $node_model = new VirhostNode();
        $node = $node_model->where(['id'=>$mysql_info['node_id']])->find();
        return $this->fetch('',['id'=>$id,'mysqlinfo'=>$mysql_info,'nodeinfo'=>$node]);
    }

    public function open_ftp($id){
        $mysql_model = new VirhostDatabase();
        $mysql_info = $mysql_model->where(['id'=>$id,'datatype'=>1])->find();
        if(empty($mysql_info)){
            $this->error('没有找到数据库');
        }
        if(!empty($mysql_info['ftp_user'])){
            $this->error('ftp已经创建');
        }

        try{
            \app\common\service\HostSite::createFTP(['id'=>$id]);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
        $this->success("操作成功");

    }

    public function backup($id){
        $mysql_model = new VirhostDatabase();
        $mysql_info = $mysql_model->where(['id'=>$id,'datatype'=>1])->find();
        if(empty($mysql_info)){
            $this->error('没有找到数据库');
        }

        try{
            \app\common\service\HostSite::BackupMysql(['id'=>$id]);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
        $this->success("操作成功");
    }

    public function restore($id){
        $mysql_model = new VirhostDatabase();
        $mysql_info = $mysql_model->where(['id'=>$id,'datatype'=>1])->find();
        if(empty($mysql_info)){
            $this->error('没有找到数据库');
        }
        $filename = $this->request->param('filename');
        if(empty($filename)){
            $this->error('文件名不能为空');
        }
        try{
            \app\common\service\HostSite::RestoreMysql(['id'=>$id,'filename'=>$filename]);
        }catch (Exception $e){
            $this->error($e->getMessage());
        }
        $this->success("操作成功");
    }

    public function phpmyadmin($id){
        $mysql_model = new VirhostDatabase();
        $mysql_info = $mysql_model->where(['id'=>$id,'datatype'=>1])->find();
        if(empty($mysql_info)){
            $this->error('没有找到数据库');
        }

        $node_model = new VirhostNode();
        $node = $node_model->where(['id'=>$mysql_info['node_id']])->find();
        $this->assign("node",$node);
        $forward_url = "http://".$node['node_ip'].":8004/phpMyAdmin4.8.5/?pma_username=".$mysql_info['dataaccount']."&pma_password=".$mysql_info['datapasswd'];
        return  redirect($forward_url) ;
    }
}
?>