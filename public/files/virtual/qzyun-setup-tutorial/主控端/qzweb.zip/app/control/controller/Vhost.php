<?php

namespace app\control\controller;

use app\common\model\BackupVps;
use app\common\model\FirewallVps;
use app\common\model\ForwardDomainVps;
use app\common\model\ForwardPortVps;
use app\common\model\HostSite;
use app\common\model\HostVps;
use app\common\model\NetworkMonitorVps;
use app\common\model\ServersArea;
use app\common\model\ServersImageConfig;
use app\common\model\ServersImageLine;
use app\common\model\ServersIpv4;
use app\common\model\ServersIpv4Nat;
use app\common\model\ServersIpv4Private;
use app\common\model\ServersLine;
use app\common\model\ServersNode;
use app\common\model\SnapshotVps;
use app\common\model\VirhostDatabase;
use app\common\model\VirhostNode;
use app\common\model\VirhostPhpver;
use app\common\model\VirhostSsl;
use app\common\util\BaseConst;
use app\common\util\HttpRequest;
use think\App;
use think\Exception;
use think\facade\Session;
use think\Log;
use think\Request;

/**
 * 虚拟主机管理
 *
 * @icon fa fa-dashboard
 * @remark  虚拟主机管理
 */
class Vhost extends \app\BaseController
{
    protected $noNeedLogin = ['get_panel_password','login','index'];

    protected function initialize()
{
    $hostid = $this->request->param('hostid');
    $this->assign("hostid",$hostid);

    $baseUrl = $this->request->baseUrl();
    $baseUrlArr = explode('vhost',$baseUrl);
    $rootUrl = $this->request->domain().$baseUrlArr[0]."vhost/";
    $this->assign('rootUrl',$rootUrl);
    $arr = $this->noNeedLogin;
    $arr = is_array($arr) ? $arr : explode(',', $arr);
    if ($arr) {
        $arr = array_map('strtolower', $arr);
        // 是否存在
        if (in_array(strtolower($this->request->action()), $arr) || in_array('*', $arr)) {
            return true;
        }
    }

    $admin = Session::get('admin');
    if ($admin) {
        return true;
    }

    //判断权限
    $hostid = $this->request->param('hostid');
    $host_id = $this->request->param('host_id');
    $host_id =  $hostid?$hostid:$host_id;
    if(empty($host_id)){
        $this->error('参数不正确');
    }

    $host_model = new HostSite();
    $host = $host_model->find($host_id);
    if(empty($host)){
        $this->error('虚拟主机不存在');
    }

    $hostinfo = session('vhostinfo');
    if(empty($hostinfo)){
        $this->error('未登陆或已退出登陆');
    }
    if($host->id!=$hostinfo->id){
        $this->error('权限不足');
    }

}

    public function logout(){
        session('vhostinfo','');
        $forward_url =url('/',[],false);
        return  redirect($forward_url) ;
    }
    //登录控制台
    public function login(){
        $site_name = $this->request->param('site_name','','trim');
        $ftp_passwd = $this->request->param('ftp_passwd','','trim');
        $host_model =  new HostSite();
        $info = $host_model->where(['site_name'=>$site_name,'ftp_passwd'=>$ftp_passwd])->find();
        $site = config('web');
        $domian = '';
        if(isset($site['apiurl'])){
            $domian = $site['apiurl'];
        }
        if($info){
            session('vhostinfo',$info);
        }else{
            $this->error('登陆失败',$domian.url('control/index/index'));
        }
        $forward_url =url('control/vhost/index',['hostid'=>$info->id],false);
        if($this->request->isAjax()){
            $this->success('登陆成功',$forward_url);
        }else{
            //header('Location: '.$forward_url);
            return  redirect($forward_url) ;
        }
    }

    public function index(){
        $hostid= $this->request->param('hostid');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function running_dir(){
        $hostid= $this->request->param('hostid');
        $dir= $this->request->param('dir');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            if(empty($dir)){
                //$this->error('参数错误');
            }
            try{
                \app\common\service\HostSite::runningDir(['hostid'=>$hostid,'dir'=>$dir]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function bind_domain(){
        $hostid= $this->request->param('hostid');
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        $domain= $this->request->param('domain');
        if($this->request->isAjax()){
            if(empty($domain)){
                $this->error('参数错误');
            }
            try{
                \app\common\service\HostSite::bindDomain(['hostid'=>$hostid,'domain'=>$domain]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function ssl_manage(){
        $hostid= $this->request->param('hostid');
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        $domain= $this->request->param('domain');
        if($this->request->isAjax()){
            if(empty($domain)){
                $this->error('参数错误');
            }
            try{
                \app\common\service\HostSite::bindDomain(['hostid'=>$hostid,'domain'=>$domain]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        //证书信息
        $ssllist = (new VirhostSsl())->where(['site_id'=>$hostid])->select();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo,'ssllist'=>$ssllist]);
    }

    public function ssl_add(){
        $hostid= $this->request->param('hostid');
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
           try{
               $file = $this->request->file('ssl');
               if($file->extension()!="pfx"){
                   $this->error('必须是.pfx');
               }

               if($file->getSize()>25430){
                   $this->error('文件不能大于20KB');
               }
               $ssl = file_get_contents($file->getRealPath());
               $name= $this->request->param('name');
               $ssl_passwd= $this->request->param('ssl_passwd');
               \app\common\service\HostSite::importCertificate(['hostid'=>$hostid,'ssl'=>$ssl,'ssl_passwd'=>$ssl_passwd,'name'=>$name]);
               $this->success("操作成功");
           }catch (Exception $e){
               $this->error($e->getMessage());
           }
        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function bind_ssl(){
        $hostid= $this->request->param('hostid');
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        $id = $this->request->param('id');
        if($this->request->isAjax()){
            try{
                $domain = $this->request->param('domain');
                $domain_ = explode(',',$domain);
                $domain_ = array_filter($domain_);

                if(count($domain_)<1){
                    $this->error('请选择要部署的域名');
                }
                $ssl_model = new VirhostSsl();
                $list = $ssl_model->where('id','<>',$id)->where('site_id','=',$hostid)->select();
                $domain_old = '';
                foreach ($list as $k=>$v){
                    $domain_old.=$v['domain_ssl'];
                }
                $domain_old = array_filter(explode(',',$domain_old));
                foreach ($domain_ as $k=>$v){
                    if(in_array($v,$domain_old)){
                        $this->error('域名'.$v.'已经在其他证书部署');
                    }
                }
                \app\common\service\HostSite::bindSSL(['hostid'=>$hostid,'domain'=>$domain,'id'=>$id]);
                $this->success("操作成功");
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
        }
        //节点信息
        $domain = $hostinfo['domain'];
        $domain =  explode(',',$domain);
        $domain = array_filter($domain);

        $sslmodel = new VirhostSsl();
        
        $ssl = $sslmodel->find($id);
        $domainssl = $ssl['domain_ssl'];
        $domainssl = array_filter(explode(',',$domainssl));
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo,'domain'=>$domain,'domainssl'=>$domainssl]);
    }

    public function change_ftp_passwd(){
        $hostid= $this->request->param('hostid');
        $ftppasswd= $this->request->param('ftppasswd');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            if(strlen($ftppasswd)<8){
                $this->error('密码长度大于8');
            }
            try{

                \app\common\service\HostSite::changeFtpPasswd(['hostid'=>$hostid,'ftppasswd'=>$ftppasswd]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function default_doc(){
        $hostid= $this->request->param('hostid');
        $defaultdoc= $this->request->param('defaultdoc');
        $defaultdoc = str_replace('，',',',$defaultdoc);
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            if(strlen($defaultdoc)<4){
                $this->error('默认文档不能为空');
            }
            try{

                \app\common\service\HostSite::defaultDoc(['hostid'=>$hostid,'defaultdoc'=>$defaultdoc]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function site_state(){
        $hostid= $this->request->param('hostid');
        $state= $this->request->param('state');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            $state = $state==1?1:2;
            try{

                \app\common\service\HostSite::setState(['hostid'=>$hostid,'state'=>$state]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function phpver(){
        $hostid= $this->request->param('hostid');
        $phpver= $this->request->param('php_ver');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        $phpmodel = new VirhostPhpver();
        $phpAll = $phpmodel->select();
        if(!empty($phpAll)){
            $phpAll = $phpAll->toArray();
            $phpAll = array_column($phpAll,null,'id');
        }

        if($this->request->isAjax()){
            try{
                $php_path = '';
                if(is_numeric($phpver)){
                    $php_path=$phpAll[$phpver]['php_path'];
                }
                \app\common\service\HostSite::setPHPVer(['hostid'=>$hostid,'php_ver'=>$phpver,'php_path'=>$php_path]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        $phpnode = $nodeinfo->phpver;
        $phpnode = array_filter(explode(',',$phpnode));
        $phpnode_show =[];
        foreach ($phpnode as $k=>$v){
            if(isset($phpAll[$v]))$phpnode_show[] = $phpAll[$v];

        }

        $nowphp = '';
        if($hostinfo['php_ver']!='no'&&!empty($hostinfo['php_ver'])){
            $nowphp = $phpAll[$hostinfo['php_ver']]['php_name'];
        }
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo,'phpnode_show'=>$phpnode_show,'nowphp'=>$nowphp]);
    }

    public function http_errors(){
        $hostid= $this->request->param('hostid');
        $http_errors= $this->request->param('http_error');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            try{

                \app\common\service\HostSite::httpErrors(['hostid'=>$hostid,'http_errors'=>$http_errors]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function redirect(){
        $hostid= $this->request->param('hostid');
        $redirect_url =  $this->request->param('redirect_url');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            try{

                \app\common\service\HostSite::Redirect(['hostid'=>$hostid,'redirect_url'=>$redirect_url]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function mime_map(){
        $hostid= $this->request->param('hostid');
        $file_extension =  $this->request->param('file_extension');
        $mime_type =  $this->request->param('mime_type');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        if($this->request->isAjax()){
            try{

                \app\common\service\HostSite::AddMimeMap(['hostid'=>$hostid,'file_extension'=>$file_extension,'mime_type'=>$mime_type]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");
        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        $mime = $hostinfo['mime'];
        if(!empty($mime)){
            $mime = json_decode($mime,true);
            $mime = array_reverse($mime);
        }else{
            $mime =[];
        }

        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo,'mime'=>$mime]);
    }

    public function remove_mime_map(){
        $hostid= $this->request->param('hostid');
        $file_extension =  $this->request->param('file_extension');
        $mime_type =  $this->request->param('mime_type');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::RemoveMimeMap(['hostid'=>$hostid,'file_extension'=>$file_extension,'mime_type'=>$mime_type]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }
    }

    public function rewrite(){
        $hostid= $this->request->param('hostid');
        $rewrite=  $this->request->param('rewrite');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::Rewrite(['hostid'=>$hostid,'rewrite'=>$rewrite]);
            }catch (Exception $e){

                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function recycle(){
        $hostid= $this->request->param('hostid');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::Recycle(['hostid'=>$hostid]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function appmode(){
        $hostid= $this->request->param('hostid');
        $pool32= $this->request->param('pool32');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::Appmode(['hostid'=>$hostid,'pool32'=>$pool32]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function netver(){
        $hostid= $this->request->param('hostid');
        $net_ver = $this->request->param('net_ver');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::NetVer(['hostid'=>$hostid,'net_ver'=>$net_ver]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        $net_ver_list =  \app\common\Model\HostSite::$netver;
        $nownet = "未启用";
        if(isset($net_ver_list[$hostinfo->net_ver])){
            $nownet = $net_ver_list[$hostinfo->net_ver]['remark'];
        }

        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo,'net_ver_list'=>$net_ver_list,'nownet'=>$nownet]);
    }

    public function ip_security(){
        $hostid= $this->request->param('hostid');
        $ip_security = $this->request->param('ip_security');
        $ip_allowed = $this->request->param('ip_allowed');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::ipSecurity(['hostid'=>$hostid,'ip_security'=>$ip_security,'ip_allowed'=>$ip_allowed]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function zip(){
        $hostid= $this->request->param('hostid');
        $filepath = $this->request->param('filepath');
        $filename = $this->request->param('filename');
        $ziptype = $this->request->param('ziptype');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }
        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);
        if($this->request->isAjax()){
            try{
                \app\common\service\HostSite::zip(['hostid'=>$hostid,'filepath'=>$filepath,'filename'=>$filename,'ziptype'=>$ziptype]);
            }catch (Exception $e){
                $this->error($e->getMessage());
            }
            $this->success("操作成功");

        }

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo]);
    }

    public function database(){
        $hostid= $this->request->param('hostid');
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $vhost_model = new HostSite();
        $hostinfo = $vhost_model->find($hostid);

        //节点信息
        $nodeinfo = (new VirhostNode())->where(['id'=>$hostinfo->node_id])->find();
        $database = (new VirhostDatabase())->where(['site_id'=>$hostid])->select();
        $mysql = false;
        $mssql = false;
        if(!empty($database)){
            $database = $database->toArray();
            $database = array_column($database,null,'datatype');
            $mysql = isset($database[1])?true:false;
            $mssql = isset($database[2])?true:false;
        }

        return $this->fetch('',['hostinfo'=>$hostinfo,'nodeinfo'=>$nodeinfo,'mysql'=>$mysql,'mssql'=>$mssql]);
    }

    public function databaselogin(){
        $hostid= $this->request->param('hostid');
        $datatype= $this->request->param('datatype',1);
        if(empty($hostid)||!is_numeric($hostid)){
            $this->error('参数错误');
        }

        $database = (new VirhostDatabase())->where(['site_id'=>$hostid,'datatype'=>$datatype])->find();
        if(empty($database)){
            $this->error('数据库不存在');
        }

        $baseUrl = $this->request->baseUrl();
        $baseUrlArr = explode('vhost',$baseUrl);
        $rootUrl = $this->request->domain().$baseUrlArr[0];

        $forward_url = $rootUrl.($datatype==1?'mysql':'mssql')."/login?dataname=".$database['dataaccount']."&datapasswd=".$database['datapasswd'];
        return  redirect($forward_url) ;
    }
}
?>