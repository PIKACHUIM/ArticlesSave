<?php

namespace app\validate;

use think\Validate;

class Caremetal extends Validate
{
    protected $rule = [
        'area_id|机房' => 'require',
        'number|编号' => 'require',

    ];

}