<?php
/**
 * 系统配置文件
 */
return [
	'title' => '至简Stack',
	'key' => '',
	'desc' => '',
	'tel' => '',
	'qq' => '',
	'mail' => '',
	'addr' => '',
	'logo' => '',
	'bg' => '',
	'login_captcha' => '0',
	'smtp-user' => '',
	'smtp-pass' => '',
	'smtp-port' => '',
	'smtp-host' => '',
	'apiurl' => '',
	'apikey' => '',
	'file-type' => '1',
	'file-endpoint' => '',
	'file-OssName' => '',
	'file-accessKeyId' => '',
	'file-accessKeySecret' => '',
];