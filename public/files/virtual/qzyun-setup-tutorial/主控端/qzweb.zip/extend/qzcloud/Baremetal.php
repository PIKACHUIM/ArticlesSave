<?php
namespace qzcloud;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ConnectException;
use think\Log;
set_time_limit(0);
class Baremetal{
    public $apikey ="";
    public $api_url="";
    public $port ='8000';

    //创建一个云主机

    /**
     * @param array $lineInfo 产品信息 线路信息
     * @param array $nodeInfo 节点信息 自生产有值
     * @param array $param
     * @return array
     */
    public function initNode($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            //$post_data['ftp_root'] = $param['ftp_root'];
            $post_data['ftp_user'] = $param['ftp_user'];
            $post_data['ftp_passwd'] = $param['ftp_passwd'];
            $post_data['dns1'] = $param['dns1'];
            $post_data['dns2'] = $param['dns2'];
            $post_data['netmask'] = $param['netmask'];
            $post_data['gateway_ip'] = $param['gateway_ip'];
            $post_data['iprange'] = $param['iprange'];
            $post_data['ntp'] = $param['ntp'];
            $post_data['ifname'] = $param['ifname'];
            $post_data['leasetime'] = (int)$param['leasetime'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/InitConfig",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>$result['msg']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function remoteMirrors(){
        $url = 'https://www.qzsystem.com/home/mirrors/index';
        try {
            $Client = new Client();
            $res = $Client->get($url,[
                'headers' => ['Content-Type' => 'application/json'],
                'http_errors' => false,
                'json'    => [],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function powerStatus($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/PowerStatus",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function powerOff($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;


            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/PowerOff",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function powerOn($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;


            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/PowerOn",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function reset($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;


            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/Reset",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function resetbmc($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/ResetBMC",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function startVnc($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/StartVNC",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>['url'=>base64_encode($result['data']."&host=".$node_url)]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function flushVnc($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host'] = $param['ipmi_host'];
            $post_data['user'] = $param['ipmi_user'];
            $post_data['passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/FlushVNC",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>['url'=>base64_encode($result['data']."&host=".$node_url)]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //同步官网镜像
    public function downISOFile($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;


            if (empty($param['url'])){
                return ['code'=>0,'msg'=>'镜像地址异常'];
            }

            $post_data['source'] = $param['source'];
            $post_data['name'] = $param['name']??'';
            $post_data['url'] = $param['url'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/CreateTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>json_encode($post_data),'action'=>'downISOFile','callback_param'=>(string)$param['taskid'],'state'=>1],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>['url'=>'http://'.$node_url.$result['msg']]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function importISO($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;


            $post_data['source'] = '';
            $post_data['name'] = $param['name']??'';
            $post_data['dir'] = '';

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/CreateTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>json_encode($post_data),'action'=>'importISO','callback_param'=>(string)$param['taskid'],'state'=>1],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //本地上传的iso文件
    public function getISOList($param=[],$node){
        //api/qzsystem/isoList
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/ISOList",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    =>['name'=>''] ,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function GetSystemVer($param=[],$node){
        //api/qzsystem/isoList
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/GetSystemVer",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    =>['file_name'=>$param['file_name']] ,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function getTaskList($param=[],$node){
        //api/qzsystem/isoList
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $Client = new Client();

            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/TaskList",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    =>['callback_param'=>$param['callback_param']] ,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function updateTaskStatus($param=[],$node){
        //api/qzsystem/isoList
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }
            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$node['api_url'];
            $Client = new Client();

            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzsystem/CancelTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    =>['callback_param'=>(string)$param['callback_param'],"state"=>"-10"] ,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>''];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function installOS($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }


            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host_name'] = $param['host_name'];
            $post_data['os_name'] = $param['os_name'];
            $post_data['os_index'] = $param['os_index'];
            $post_data['os_type'] = $param['os_type'];
            $post_data['os_ver'] = $param['os_ver'];
            $post_data['mirrors_dir'] = $param['mirrors_dir'];
            $post_data['disk_partition'] = $param['disk_partition'];
            $post_data['disk_partition_type'] = (string)$param['disk_partition_type'];
            $post_data['pxe_mac'] = $param['pxe_mac'];
            $post_data['ip'] = $param['ip'];
            $post_data['gateway'] = $param['gateway'];
            $post_data['netmask'] = $param['netmask'];
            $post_data['dns1'] = $param['dns1'];
            $post_data['dns2'] = $param['dns2'];
            $post_data['host_passwd'] = $param['host_passwd'];
            $post_data['ipmi_host'] = $param['ipmi_host'];
            $post_data['ipmi_user'] = $param['ipmi_user'];
            $post_data['ipmi_pass'] = $param['ipmi_pass'];
            $post_data['os_key'] = $param['os_key'];
            $post_data['remote_port'] = $param['remote_port'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/CreateTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>json_encode($post_data),'action'=>'installOS','callback_param'=>(string)$param['taskid'],'state'=>1],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>['url'=>'http://'.$node_url.$result['msg']]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function rescue($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }

            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host_name'] = $param['host_name'];
            $post_data['os_type'] = $param['os_type'];
            $post_data['pxe_mac'] = $param['pxe_mac'];
            $post_data['ip'] = $param['ip'];
            $post_data['gateway'] = $param['gateway'];
            $post_data['netmask'] = $param['netmask'];
            $post_data['dns1'] = $param['dns1'];
            $post_data['dns2'] = $param['dns2'];
            $post_data['host_passwd'] = $param['host_passwd'];
            $post_data['ipmi_host'] = $param['ipmi_host'];
            $post_data['ipmi_user'] = $param['ipmi_user'];
            $post_data['ipmi_pass'] = $param['ipmi_pass'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/CreateTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>json_encode($post_data),'action'=>'rescue','callback_param'=>(string)$param['taskid'],'state'=>1],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>['url'=>'http://'.$node_url.$result['msg']]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function password($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }


            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host_name'] = $param['host_name'];
            $post_data['os_type'] = $param['os_type'];
            $post_data['pxe_mac'] = $param['pxe_mac'];
            $post_data['ip'] = $param['ip'];
            $post_data['gateway'] = $param['gateway'];
            $post_data['netmask'] = $param['netmask'];
            $post_data['dns1'] = $param['dns1'];
            $post_data['dns2'] = $param['dns2'];
            $post_data['host_passwd'] = $param['host_passwd'];
            $post_data['ipmi_host'] = $param['ipmi_host'];
            $post_data['ipmi_user'] = $param['ipmi_user'];
            $post_data['ipmi_pass'] = $param['ipmi_pass'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/CreateTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>json_encode($post_data),'action'=>'changePasswd','callback_param'=>(string)$param['taskid'],'state'=>1],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>''];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>['url'=>'http://'.$node_url.$result['msg']]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function getMacList($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }
            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$node['api_url'];
            $post_data['ipmi_host'] = $param['ipmi_host'];
            $post_data['ipmi_user'] = $param['ipmi_user'];
            $post_data['ipmi_passwd'] = $param['ipmi_passwd'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzsystem/GetMacList",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>'','data'=>[]];
                }else{
                    $data = $result['data'];
                    if (is_array($data)){
                        foreach ($data as $k=>&$v){
                            $v = trim($v,"\n");
                        }
                        unset($v);
                    }
                    return ['code'=>200,'msg'=>'','data'=>$data];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function cancelTask($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }


            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['callback_param'] = (string)$param['callback_param'];
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/CancelTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function switchCommand($param=[],$node){
        try {
            if($this->apikey==""&&$node['apikey']==""){
                return ['code'=>0,'msg'=>'通讯密钥错误'];
            }
            if($this->api_url==""&&$node['api_url']==""){
                return ['code'=>0,'msg'=>'节点通讯地址为空'];
            }


            $api_url = $node['api_url'];
            $api_url_arr = explode(":",$api_url);
            if (count($api_url_arr)>1){
                $this->port = $api_url_arr[1];
                $api_url = $api_url_arr[0];
            }

            $apikey = $this->apikey?$this->apikey:$node['apikey'];
            $node_url = $this->api_url?$this->api_url:$api_url;

            $post_data['host'] = (string)$param['host'];
            $post_data['port'] = (string)$param['port'];
            $post_data['user'] = (string)$param['user'];
            $post_data['passwd'] = (string)$param['passwd'];
            $post_data['command'] = (string)$param['command'];

            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/v1/SwitchCommand",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'','data'=>[]];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

}
?>
