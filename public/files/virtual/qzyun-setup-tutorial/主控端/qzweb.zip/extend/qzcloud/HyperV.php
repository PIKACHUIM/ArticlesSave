<?php
namespace qzcloud;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ConnectException;
use think\Log;
set_time_limit(0);
class HyperV{
    public $apikey ="";
    public $node_url="";
    public $port ='8000';

    public $forward_url='';
    public $forward_port='8000';
    //创建一个云主机

    /**
     * @param array $lineInfo 产品信息 线路信息
     * @param array $nodeInfo 节点信息 自生产有值
     * @param array $param
     * @return array
     */
    public function openHost($lineInfo=[],$nodeInfo=[],$param=[],$network=[],$taskid=null){
        //        ip gateway netmask dns1 dns2 band_width mac switch_name switch_name
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;


        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['host_name'];
        $post_data['password'] = $param['os_password'];
        $post_data['template_path'] = $nodeInfo['template_path'];
        $post_data['vhd_path'] = $nodeInfo['data_path'];
        $post_data['vcpus'] = $param['cpu'];
        $post_data['cpu_limit'] = empty($param['cpu_limit'])?'100':$param['cpu_limit'];
        $post_data['os_type'] = $param['os_type'];
        if(isset($nodeInfo['os_path'])&&!empty($nodeInfo['os_path'])){
            $post_data['os_vhd_path'] = $nodeInfo['os_path'];
        }
        if(isset($nodeInfo['diff_disk'])&&$nodeInfo['diff_disk']==1){
            $post_data['diff_disk'] = 1;
        }

        $post_data['max_memory_mb'] = $param['memory']*1024;
        $post_data['min_memory_mb'] = $param['memory_dynamic']==1?$param['ram_start']:0;
        $post_data['os_name'] = $param['file_name'].".vhdx";

        $post_data['os_min_iops'] = $param['os_disk_maxiops'];
        $post_data['os_max_iops'] = $param['os_disk_maxiops'];
        $post_data['max_iops'] = $param['data_disk_maxiops'];
        $post_data['min_iops'] = $param['data_disk_maxiops'];
        $post_data['data_size'] = $param['hard_disks'];
        if(isset($param['re_create'])){
            $post_data['re_create'] = $param['re_create'];
        }
        //是不是裸金属服务器
        if($param['metal']==2){
            $post_data['vir_extensions'] = true;
        }else{
            $post_data['vir_extensions'] = false;
        }

        //是否支持显卡
        if($param['resolution']!=0&&$param['gpu_capacity']!=0){
            $post_data['maximum_screen'] = $param['resolution'];
            $post_data['ram_size'] = $param['gpu_capacity'];
        }

        //是否集群架构
        if($nodeInfo['node_name']!=""&&$nodeInfo['mscluster_name']!=""){
            $post_data['node_name'] = $nodeInfo['node_name'];
            $post_data['mscluster_name'] = $nodeInfo['mscluster_name'];
	    }

        //网络
       // $param['network'] 二维数组 0为公网主ip 1为私网ip   ip gateway netmask dns1 dns2 band_width mac switch_name switch_name
        $network1['ip'] =$network['eth1']['ip'];
        $network1['gateway'] =$network['eth1']['gateway'];
        $network1['netmask'] =$network['eth1']['netmask'];
        $network1['dns1'] =$nodeInfo['dns1'];
        $network1['dns2'] =$nodeInfo['dns2'];
        $network1['band_width'] = $param['bandwidth'];
        $network1['mac'] =$network['eth1']['mac'];
        $network1['switch_name'] =$param['is_nat']==1?$nodeInfo['switch3']:$nodeInfo['switch1'];
        $network1['vlanid'] =$param['vlanid1'];
        $network1['inlimit'] = !empty($param['bandwidth_in'])?(int)$param['bandwidth_in']:$nodeInfo['bandwidth_in'];

        $network2['ip'] =$network['eth2']['ip'];
        $network2['gateway'] ='';
        $network2['netmask'] =$network['eth2']['netmask'];
        $network2['band_width'] = 0;
        $network2['mac'] =$network['eth2']['mac'];
        $network2['switch_name'] =$nodeInfo['switch2'];
        $network2['vlanid'] =$param['vlanid2'];

        $post_data['network'] = [$network1,$network2];
        $post_data['otherip'] = $network['otherip'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'create_vps','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'创建命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //更新一个云主机
    public function updateHost(array $nodeInfo=[],array $param=[],$taskid=null){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['vcpus'] = $param['cpu'];
        $post_data['cpu_limit'] = $param['cpu_limit'];

        $post_data['max_memory_mb'] = $param['memory']*1024;
        $post_data['min_memory_mb'] = $param['memory_dynamic']==1?$param['ram_start']:0;

        $post_data['max_iops'] = $param['data_disk_maxiops'];
        $post_data['min_iops'] = $param['data_disk_maxiops'];
        $post_data['data_size'] = $param['hard_disks'];
        $post_data['data_path'] = $param['host_name']."_data1.vhdx";

        $post_data['band_width'] = $param['bandwidth'];
        $post_data['inlimit'] = !empty($param['bandwidth_in'])?(int)$param['bandwidth_in']:$nodeInfo['bandwidth_in'];

        $post_data['os_min_iops'] = $param['os_disk_maxiops'];
        $post_data['os_max_iops'] = $param['os_disk_maxiops'];

        //是不是裸金属服务器
        if(isset($param['metal'])&&$param['metal']==2){
            $post_data['vir_extensions'] = true;
        }else{
            $post_data['vir_extensions'] = false;
        }

        //多余ip
        if(isset($param['add_ip'])&&strlen($param['add_ip'])>6){
            $post_data['otherip'] = $param['ip'].','.$param['add_ip'];
        }

        //是否支持显卡
        if(isset($param['resolution'])&&$param['resolution']!=0&&$param['gpu_capacity']!=0){
            $post_data['maximum_screen'] = $param['resolution'];
            $post_data['ram_size'] = $param['gpu_capacity'];
        }
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'update_vps','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'升级命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }

    }

    //删除一个云主机
    public function deleteHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['back_dir'] = $nodeInfo['backup_path'];
        if(isset($nodeInfo['del_type'])&&$nodeInfo['del_type'] ==1){
            $post_data['move'] = 1;
        }
        
        //del_type
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'remove_vps','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'升级命令已发送'];
                }
            }
        }catch (\InvalidArgumentException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //云主机监控
    public function monitorHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/MonitorHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 5
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //云主机运行图片
    public function thumbnailHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }


        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['width'] = 400;
        $post_data['height'] = 260;
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetThumbnailImageHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 5
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //设置Bios
    public function setBiosHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['first'] = strtoupper($param['bios'])=='CD'?'CD':'IDE';
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetVmBootOrderHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //云主机开机
    public function startHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['state'] = 2;
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetStateHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //关机
    public function closeHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['state'] = 4;
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetStateHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //断开电源
    public function powerHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['state'] = 3;
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetStateHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //重启
    public function restartHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $status = $this->getStateHost($nodeInfo,$param);
        if($status['code']!=200){
            return ['code'=>0,'msg'=>$status['msg']];
        }
        if($status['data']['state']=='Stopped'){ //如果是停止就启动
            return  $this->startHost($nodeInfo,$param);
        }
        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['state'] = 11;
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetStateHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //获取云主机唯一的guid
    public function guidHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetVmGuidHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    $guid = $result['data']['guid'];
                    ///?guid=258CFB3E-D3EC-405F-B4D9-1103968943F2&user=caiwu&host=localhost
                    $vnc_url ='http://'.$nodeInfo['vnc_url'].':8001/?guid='.$guid.'&user='.$param['host_name'].'&host=127.0.0.1';
                    $result['data']['url'] = $vnc_url;
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //获取云主机状态
    public function getStateHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetVmState",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //重新安装操作系统
    public function reinstallHost(array $nodeInfo=[],array $param=[],$network=[],$taskid){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['host_name'];
        $post_data['password'] = $param['os_password'];
        $post_data['template_path'] = $nodeInfo['template_path'];
        $post_data['vhd_path'] = $nodeInfo['data_path'];
        $post_data['os_type'] = $param['os_type'];
        //网络
        // $param['network'] 二维数组 0为公网主ip 1为私网ip   ip gateway netmask dns1 dns2 band_width mac switch_name switch_name
        $network1['ip'] =$network['eth1']['ip'];
        $network1['gateway'] =$network['eth1']['gateway'];
        $network1['netmask'] =$network['eth1']['netmask'];
        $network1['dns1'] =$nodeInfo['dns1'];
        $network1['dns2'] =$nodeInfo['dns2'];
        $network1['band_width'] = $param['bandwidth'];
        $network1['mac'] =$network['eth1']['mac'];
        $network1['switch_name'] =$param['is_nat']==1?$nodeInfo['switch3']:$nodeInfo['switch1'];

        $network2['ip'] =$network['eth2']['ip'];
        $network2['gateway'] ='';
        $network2['netmask'] =$network['eth2']['netmask'];
        $network2['band_width'] = 0;
        $network2['mac'] =$network['eth2']['mac'];
        $network2['switch_name'] =$nodeInfo['switch2'];
        $post_data['os_name'] = $param['file_name'].".vhdx";

        $post_data['network'] = [$network1,$network2];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'reinstall','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'升级命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //获取服务器目录iso文件
    public function getisoHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['iso_dir'] = $nodeInfo['iso_path'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetISOList",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //挂载或者卸载iso文件
    public function isoHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['iso_path'] = $param['iso']==''?'':$nodeInfo['iso_path'].'\\'.$param['iso'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/AttachISOHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //创建快照
    public function createSnapshotHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'create_snapshot','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }

    }

    //还原快照
    public function restoreSnapshotHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'restore_snapshot','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //删除快照
    public function removeSnapshotHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'remove_snapshot','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //创建备份
    public function createBackupHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        $post_data['back_dir'] = $nodeInfo['backup_path'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'create_backup','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //还原备份
    public function restoreBackupHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        $post_data['back_dir'] = $nodeInfo['backup_path'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'restore_backup','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //删除备份
    public function removeBackupHost(array $nodeInfo=[],array $param=[],$taskid=0){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        $post_data['back_dir'] = $nodeInfo['backup_path'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/CreateHyperVTask",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => ['data'=>$post_data,'action'=>'remove_backup','callback_param'=>(string)$taskid,'state'=>'1'],
                'timeout' => 1200
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'命令已发送'];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //添加策略
    function addFirewallHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];

        if($param['method']=='accept'){
            $post_data['action'] = '1';
        }else{
            $post_data['action'] = '2';
        }
        if($param['direction']=='in'){
            $post_data['direction'] = '1';
        }else{
            $post_data['direction'] = '2';
        }
        $post_data['remoteIPAddress'] = $param['start_ip'];
        $post_data['localPort'] = $param['start_port'];
        $post_data['protocol'] = $param['protocol'];
        $post_data['weight'] = $param['priority'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/AddAclExtendedHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }
    //删除策略
    function removeFirewallHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        $post_data['name'] = $param['name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/RemoveAclExtendedHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\GuzzleHttp\Exception\RequestException $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //挂机宝端口映射
    //添加端口
    public function addForwardPort(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['dport'] =  strval($param['dport']); //小鸡内网端口
        $post_data['sport'] = strval($param['sport']); //映射服务器公网端口
        $post_data['dip'] = $param['dip'];
        $post_data['vm_name'] = $param['host_name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/addPort",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //删除端口
    public function removeForwardPort(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['dport'] = $param['dport']; //小鸡内网端口
        $post_data['sport'] = $param['sport']; //映射服务器公网端口
        $post_data['dip'] = $param['dip'];
        $post_data['vm_name'] = $param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/delPort",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //添加域名白名单
    public function addForwardDomain(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }
        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $forward_url = $this->forward_url?$this->forward_url:$nodeInfo['forward_url'];
        $post_data = [];
        $post_data['domain'] = $param['domain'];
        $post_data['dip'] = $param['dip'];
        $post_data['vm_name'] = $param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$forward_url.':'.$this->forward_port."/api/Forward/AddDomain",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //删除域名白名单
    public function removeForwardDomain(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }
        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $forward_url = $this->forward_url?$this->forward_url:$nodeInfo['forward_url'];
        $post_data = [];
        $post_data['domain'] = $param['domain'];
        $post_data['dip'] = $param['dip'];
        $post_data['vm_name'] = $param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$forward_url.':'.$this->forward_port."/api/Forward/DelDomain",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //修改系统密码
    public function updatePasswordHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['password'] = $param['password'];
        $post_data['vm_name'] = $param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetPasswordHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //同步物理机器时间
    public function syncTimeHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['state'] = $param['state'];
        $post_data['vm_name'] = $param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SyncTimeHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //获取流量
    public function GetVMFlow(array $nodeInfo=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;


        $post_data = [];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetVMFlow",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }
    //获取流量
    public function GetNetworkMonitoring(array $nodeInfo=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;


        $post_data = [];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetNetworkMonitoring",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);

            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //月初清除流量
    public function clearNetworkFlowHost(array $nodeInfo=[],$param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;


        $post_data = [];
        $post_data['vm_name'] = $param['host_name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/ClearNetworkFlowHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 10
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //断网或者恢复网络 state 1打开2关闭
    public function setNetworkStateHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['state'] = $param['state'];
        $post_data['vm_name'] = $param['host_name'];
        //$post_data['switch_name'] = empty($param['is_nat'])?$nodeInfo['switch1']:$nodeInfo['switch3'];
        $post_data['vlanid'] = isset($param['vlanid1'])?(string)$param['vlanid1']:'';

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/SetVmNicsStateHyperV",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

     //批量删除端口
    public function batDeletePortHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['sport'] = $param['sport'];
        $post_data['dport'] = $param['dport'];
        $post_data['dip'] = $param['ip'];
        $post_data['type_'] = $param['port_type'];
        $post_data['vm_name'] =$param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/delPortBat",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //批量删除域名
    public function batDeleteDomainHost(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }
        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $forward_url = $this->forward_url?$this->forward_url:$nodeInfo['forward_url'];
        $post_data = [];
        $post_data['domain'] = $param['domain'];
        $post_data['vm_name'] = $param['host_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$forward_url.':'.$this->forward_port."/api/Forward/DelDomainBat",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //批量设置ip
    public function batsetip(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];
        $post_data['vm_name'] = $param['vm_name'];
        $post_data['ip'] = $param['ip'];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/UpdateOrAddIpHyperVBat",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //监控母鸡信息
    public function monitorCompany(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;


        $post_data = [];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetCompanyInfo",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    //监控母鸡信息
    public function getMemoryAndDisk(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }

        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = [];

        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/GetMemoryAndDisk",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }

    public function resetNetwork(array $nodeInfo=[],array $param=[]){
        if($this->apikey==""&&$nodeInfo['apikey']==""){
            return ['code'=>0,'msg'=>'通讯密钥错误'];
        }
        if($this->node_url==""&&$nodeInfo['node_ip']==""){
            return ['code'=>0,'msg'=>'节点通讯地址为空'];
        }


        $node_ip = $nodeInfo['node_ip'];
        $node_ip_arr = explode(":",$nodeInfo['node_ip']);
        if (count($node_ip_arr)>1){
            $this->port = $node_ip_arr[1];
            $node_ip = $node_ip_arr[0];
        }

        $apikey = $this->apikey?$this->apikey:$nodeInfo['apikey'];
        $node_url = $this->node_url?$this->node_url:$node_ip;

        $post_data = $param;
        try {
            $Client = new Client();
            $res = $Client->post('http://'.$node_url.':'.$this->port."/api/qzcloud/ResetNetwork",[
                'headers' => ['Content-Type' => 'application/json','apikey'=>$apikey],
                'http_errors' => false,
                'json'    => $post_data,
                'timeout' => 20
            ]);
            if($res->getStatusCode()!=200){
                return ['code'=>0,'msg'=>$res->getBody()->getContents()];
            }else{
                $body = $res->getBody();
                $result = \GuzzleHttp\json_decode($body,true);
                if($result['code']!=200){
                    return ['code'=>0,'msg'=>$result['msg']];
                }else{
                    return ['code'=>200,'msg'=>'success','data'=>$result['data']];
                }
            }
        }catch (\Exception $e){
            return ['code'=>0,'msg'=>$e->getMessage()];
        }
    }


}
?>









