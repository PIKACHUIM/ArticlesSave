<?php
namespace qzcloud;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\ConnectException;
use think\Log;
set_time_limit(0);
class Virhost
{
    public $apikey = "";
    public $node_url = "";
    public $port = '8000';
    //创建一个站点
    public function openSite($nodeInfo = [], $param = [])
    {
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['ftpname'] = $param['ftpname'];
        $post_data['ftppasswd'] = $param['ftppasswd'];
        $post_data['wwwroot'] = $nodeInfo['wwwroot'];
        $post_data['domain'] = $param['domain'];
        $post_data['asp'] = $param['asp'];
        $post_data['php_ver'] = $param['php_ver'];
        $post_data['pool32'] = $param['pool32'];
        $post_data['net_ver'] = $param['net_ver'];
        $post_data['poolmodule'] = $param['poolmodule'];
        $post_data['spacenum'] = $param['spacenum'];
        $post_data['defaultdoc'] = $param['defaultdoc'];
        $post_data['iisnum'] = $param['iisnum'];
        $post_data['cpu'] = $param['cpu'];
        $post_data['bandwidth'] = $param['bandwidth'];

        $post_data['mysql_enable'] = 0;
        if(isset($param['mysql_enable'])&&$param['mysql_enable']==1){
            $post_data['mysql_enable'] = 1;
            $post_data['rootpasswd'] = $param['rootpasswd'];
            $post_data['mysql_account'] = $param['mysql_account'];
            $post_data['mysql_passwd'] = $param['mysql_passwd'];
            $post_data['mysql_dataname'] = $param['mysql_account'];
        }

        $post_data['mssql_enable'] = 0;
        if(isset($param['mssql_enable'])&&$param['mssql_enable']==1){
            $post_data['mssql_enable'] = 1;
            $post_data['sapasswd'] = $param['sapasswd'];
            $post_data['mssql_account'] = $param['mssql_account'];
            $post_data['mssql_passwd'] = $param['mssql_passwd'];
            $post_data['mssql_dataname'] = $param['mssql_account'];
            $post_data['mssql_spacenum'] = $param['mssql_spacenum'];
            $post_data['mssql_data_path'] = $param['mssql_data_path'];

        }

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/CreateSite", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //编辑一个站点
    public function modifySite($nodeInfo = [], $param = [])
    {
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['ftpname'] = $param['ftpname'];
        $post_data['ftppasswd'] = $param['ftppasswd'];
        $post_data['domain'] = $param['domain'];
        $post_data['asp'] = $param['asp'];
        $post_data['php_ver'] = $param['php_ver'];
        $post_data['net_ver'] = $param['net_ver'];
        $post_data['poolmodule'] = $param['poolmodule'];
        $post_data['spacenum'] = $param['spacenum'];
        $post_data['defaultdoc'] = $param['defaultdoc'];
        $post_data['iisnum'] = $param['iisnum'];
        $post_data['cpu'] = $param['cpu'];
        $post_data['bandwidth'] = $param['bandwidth'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifySite", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //删除一个站点
    public function removeSite($nodeInfo = [], $param = [])
    {
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RemoveSite", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //创建一个mysql
    public function createMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootpasswd'] = $param['rootpasswd'];
        $post_data['dataname'] = $param['dataname'];
        $post_data['datapasswd'] = $param['datapasswd'];
        $post_data['database'] = $param['dataname'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/CreateMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //创建一个Mssql
    public function createMssql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['sapasswd'] = $param['sapasswd'];
        $post_data['dataname'] = $param['dataname'];
        $post_data['datapasswd'] = $param['datapasswd'];
        $post_data['database'] = $param['dataname'];
        $post_data['datapath'] = $param['datapath'];
        $post_data['spacenum'] = $param['spacenum'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/CreateMssql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //编辑一个mysql
    public function modifyMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootpasswd'] = $param['rootpasswd'];
        $post_data['dataname'] = $param['dataname'];
        $post_data['datapasswd'] = $param['datapasswd'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifyMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //编辑一个Mssql
    public function modifyMssql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['sapasswd'] = $param['sapasswd'];
        $post_data['dataname'] = $param['dataname'];
        $post_data['datapasswd'] = $param['datapasswd'];
        $post_data['spacenum'] = $param['spacenum'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifyMssql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //删除一个mysql
    public function removeMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootpasswd'] = $nodeInfo['rootpasswd'];
        $post_data['dataname'] = $param['dataname'];
        $post_data['database'] = $param['dataname'];
        $post_data['rootdir'] = $nodeInfo['ftp_wwwroot'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RemoveMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //删除一个Mssql
    public function removeMssql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['sapasswd'] = $nodeInfo['sapasswd'];
        $post_data['dataname'] = $param['dataname'];
        $post_data['database'] = $param['dataname'];
        $post_data['rootdir'] = $nodeInfo['ftp_wwwroot'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RemoveMssql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改站点运行目录
    public function runningDir($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }
        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['dir'] = $param['dir'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifySiteRunningDir", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //绑定域名
    public function bindDomain($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['domain'] = $param['domain'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/BindingDomain", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //导入证书
    public function importCertificate($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['ssl_passwd'] = $param['ssl_passwd'];
        $post_data['ssl'] = $param['ssl'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ImportCertificate", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //绑定ssl
    public function bindSSL($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['domain'] = $param['domain'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/WebSiteBindingSSL", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改ftp密码
    public function ModifyFtpAccount($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['ftppasswd'] = $param['ftppasswd'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifyFtpAccount", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改默认文档
    public function DefaultDoc($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['default_doc'] = $param['defaultdoc'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/DefaultDoc", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改状态
    public function SetState($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['site_state'] = $param['site_state'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/SetState", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改php版本
    public function SetPHPVer($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['php_path'] = $param['php_path'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/SetPHPVer", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改默认文档
    public function HttpErrors($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['status_code'] = 404;
        $post_data['html_name'] = $param['http_errors'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/HttpErrors", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //301重定向
    public function Redirect($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['redirect_url'] = $param['redirect_url'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/SetHttpRedirectSettings", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //脚本映射
    public function AddMimeMap($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['file_extension'] = $param['file_extension'];
        $post_data['mime_type'] = $param['mime_type'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/AddMimeMap", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //删除脚本映射
    public function RemoveMimeMap($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['file_extension'] = $param['file_extension'];
        $post_data['mime_type'] = $param['mime_type'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RemoveMimeMap", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //伪静态
    public function Rewrite($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['rewrite'] = $param['rewrite'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/Rewrite", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //回收程序
    public function Recycle($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RecyclePool", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //启动32位程序池
    public function Appmode($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['pool32'] = (bool)$param['appmode'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifyPoolAppModel", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //net版本切换
    public function NetVer($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['net_ver'] = $param['net_ver'];
        $post_data['pool_module'] = $param['poolmodule'];
 
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ModifyPoolNetV", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //ip限制访问
    public function IpSecurity($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['ip_security'] = $param['ip_security'];
        $post_data['ip_allowed'] = $param['ip_allowed'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/SetIpSecuritySettings", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //解压
    public function UnRar($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['rar_name'] = $param['rar_name'];
        $post_data['save_dir'] = $param['save_dir'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/Uzip", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //压缩
    public function Rar($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['site_name'] = $param['site_name'];
        $post_data['rar_name'] = $param['rar_name'];
        $post_data['source_dir'] = $param['source_dir'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/Zip", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //站点流量
    public function  IIsFlowList($nodeInfo = [], $param = []){
    if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
        return ['code' => 0, 'msg' => '通讯密钥错误'];
    }
    if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
        return ['code' => 0, 'msg' => '节点通讯地址为空'];
    }

    $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
    $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
    $post_data = [];
    $post_data['date'] = $param['date'];
    try {
        $Client = new Client();
        $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/IIsFlowList", [
            'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
            'http_errors' => false,
            'json' => $post_data,
            'timeout' => 1200
        ]);
        if ($res->getStatusCode() != 200) {
            return ['code' => 0, 'msg' => $res->getBody()->getContents()];
        } else {
            $body = $res->getBody();
            $result = json_decode($body, true);
            if ($result['code'] != 200) {
                return ['code' => 0, 'msg' => $result['msg']];
            } else {
                return ['code' => 200, 'msg' => '','data'=>$result['data']];
            }
        }
    } catch (\GuzzleHttp\Exception\RequestException $e) {
        return ['code' => 0, 'msg' => $e->getMessage()];
    }
}

    //mysql检查大小
    public function CheckMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['data'] = $param['data'];
        $post_data['rootpassword'] = $param['rootpasswd'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/CheckMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

    public function MysqlQuotaList($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['data'] = $param['data'];
        $post_data['rootpasswd'] = $nodeInfo['rootpasswd'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/MysqlQuotaList", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

    public function MssqlQuotaList($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['data'] = $param['data'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/MssqlQuotaList", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

    public function GrantMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['database'] = $param['database'];
        $post_data['rootpasswd'] = $nodeInfo['rootpasswd'];
        $post_data['grant'] = $param['grant'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/GrantMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //站点空间大小
    public function  QuotaUsedList($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/QuotaUsedList", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改mysql密码
    public function ChangeMysqlPasswd($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['dataname'] = $param['dataname'];
        $post_data['datapasswd'] = $param['password'];
        $post_data['rootpasswd'] = $nodeInfo['rootpasswd'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ChangeMysqlPasswd", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //修改mysql密码
    public function ChangeMssqlPasswd($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['dataname'] = $param['dataname'];
        $post_data['datapasswd'] = $param['password'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/ChangeMssqlPasswd", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //创建ftp
    public function CreateFTP($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootdir'] = $nodeInfo['ftp_wwwroot'];
        $post_data['user'] = $param['user'];
        $post_data['password'] = $param['password'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/CreateFtp", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //删除ftp
    public function RemoveFTP($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootdir'] = $nodeInfo['ftp_wwwroot'];
        $post_data['user'] = $param['user'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RemoveFtp", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
   //备份mysql
    public function BackupMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootpasswd'] = $nodeInfo['rootpasswd'];
        $post_data['backupdir'] = $nodeInfo['ftp_wwwroot'];
        $post_data['database'] = $param['database'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/BackupMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
   //备份mssql
    public function BackupMssql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['backupdir'] = $nodeInfo['ftp_wwwroot'];
        $post_data['database'] = $param['database'];
        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/BackupMssql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);
            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\GuzzleHttp\Exception\RequestException $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //还原mysql
    public function RestoreMysql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['rootpasswd'] = $nodeInfo['rootpasswd'];
        $post_data['backupdir'] = $nodeInfo['ftp_wwwroot'];
        $post_data['database'] = $param['database'];
        $post_data['backupfile'] = $param['filename'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RestoreMysql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\Exception $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }
    //还原mssql
    public function RestoreMssql($nodeInfo = [], $param = []){
        if ($this->apikey == "" && $nodeInfo['apikey'] == "") {
            return ['code' => 0, 'msg' => '通讯密钥错误'];
        }
        if ($this->node_url == "" && $nodeInfo['node_ip'] == "") {
            return ['code' => 0, 'msg' => '节点通讯地址为空'];
        }

        $apikey = $this->apikey ? $this->apikey : $nodeInfo['apikey'];
        $node_url = $this->node_url ? $this->node_url : $nodeInfo['node_ip'];
        $post_data = [];
        $post_data['backupdir'] = $nodeInfo['ftp_wwwroot'];
        $post_data['database'] = $param['database'];
        $post_data['backupfile'] = $param['filename'];

        try {
            $Client = new Client();
            $res = $Client->post('http://' . $node_url . ':' . $this->port . "/api/qzhost/RestoreMssql", [
                'headers' => ['Content-Type' => 'application/json', 'apikey' => $apikey],
                'http_errors' => false,
                'json' => $post_data,
                'timeout' => 1200
            ]);

            if ($res->getStatusCode() != 200) {
                return ['code' => 0, 'msg' => $res->getBody()->getContents()];
            } else {
                $body = $res->getBody();
                $result = json_decode($body, true);
                if ($result['code'] != 200) {
                    return ['code' => 0, 'msg' => $result['msg']];
                } else {
                    return ['code' => 200, 'msg' => '','data'=>$result['data']];
                }
            }
        } catch (\Exception $e) {
            return ['code' => 0, 'msg' => $e->getMessage()];
        }
    }

}
?>