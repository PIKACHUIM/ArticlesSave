﻿function ListFile(path) {
	if (path == "") {
		$(".fileposition span").empty().append("/");
		$(".fileposition").find("a").hide();
	} else {
		$(".fileposition span").empty().append(path);
		$(".fileposition").find("a").show();
	}
	$.jBox.tip('正在获取远程文件列表，请稍候...', 'loading');
	$.getJSON("/vhost/FileManagerHandler.ashx?act=SelectDir&t=" + Math.random(), { path: path }, function (data) {
		var html = '';
		if (parseInt(data.status) == 1) {
			$(data.info).each(function (i) {
				if (data.info[i].IsDirectory == true) {
					var t = path + "/" + data.info[i].Name;
					html += '<tr><td style="text-align:left;"><img src="/images/folder.png" align="absmiddle" /> <a href="javascript:ListFile(\'' + t + '\');">' + data.info[i].Name + '</a> <span><a href="javascript:Rename(\'' + path + "/" + data.info[i].Name + '\');">改名</a> <a href="javascript:SetSecurity(\'' + path + "/" + data.info[i].Name + '\');">设置权限</a> <a href="javascript:DeleteFile(\'' + path + "/" + data.info[i].Name + '\');">删除</a></span></td><td style="text-align:left;">' + data.info[i].Size + '</td><td style="text-align:left;">' + data.info[i].Created + '</td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
				} else {
				    html += '<tr><td style="text-align:left;"><img src="/images/unknown.png" align="absmiddle" /> <a href="javascript:EditFile(\'' + path + "/" + data.info[i].Name + '\');">' + data.info[i].Name + '</a> <span><a href="javascript:Rename(\'' + path + "/" + data.info[i].Name + '\');">改名</a> <a href="javascript:SetSecurity(\'' + path + "/" + data.info[i].Name + '\');">设置权限</a> <a href="javascript:DeleteFile(\'' + path + "/" + data.info[i].Name + '\');">删除</a></span></td><td style="text-align:left;">' + parseInt(data.info[i].Size / 1024) + ' KB</td><td style="text-align:left;">' + data.info[i].Created + '</td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
				}
			});
		} else {
			html += '<tr><td colspan="4">获取远程文件列表失败。' + data.msg + '</td></tr>';
		}
		$.jBox.closeTip();
		$("#ListResult").empty().append(html);
	});
}

function EditFile(path) {
	//return false;
	$.jBox.open("正在加载文件", "修改文件", 680, 460, {
		id: "editfiledialog",
		buttons: { "保存": 0 },
		submit: function (v, h, f) {
		    if (v == 0) {
		        $.jBox.tip('正在保存，请稍候...', 'loading');
		        $.post("/vhost/FileManagerHandler.ashx?act=SetFileContent&t=" + Math.random(), { path: path, content: $('[name="filecontent"]').val() }, function (data) {
		            data = $.parseJSON(data);
		            $.jBox.closeTip();
		            if (parseInt(data.status) == 1) {
		                $.jBox.success("保存成功！");
		                return true;
		            } else {
		                $.jBox.error("保存失败！<br>" + data.msg);
		                return false;
		            }
		        });
			}
		}
	});
	$.get("/vhost/FileManagerHandler.ashx?act=GetFileContent&t=" + Math.random(), { path: path }, function (data) {
	    var html = '<textarea name="filecontent" style="width:670px; height:386px; margin:0px auto;">';
	    html += data + "</textarea>";
		$.jBox.setContent(html);
	});
}

function Rename(FilePath) {
    var html = "<div style='padding:10px;'>请输入新的文件名：<input type='text' id='dstfilename' name='dstfilename' /></div>";
    var submit = function (v, h, f) {
        if (f.dstfilename == '') {
            $.jBox.tip("请输入新的文件名。", 'error', { focusId: "dstfilename" });
            return false;
        }
        $.jBox.tip('正在重命名，请稍候...', 'loading');
        $.post("/vhost/FileManagerHandler.ashx?act=Rename&t=" + Math.random(), { SrcFilePath: FilePath, NewFileName: f.dstfilename }, function (data) {
            data = $.parseJSON(data);
            $.jBox.closeTip();
            if (parseInt(data.status) == 1) {
                $.jBox.success("重命名成功！");
                var FolderPath = FilePath.substring(0, FilePath.lastIndexOf("/"));
                ListFile(FolderPath);
                return true;
            } else {
                $.jBox.error("重命名失败！<br>" + data.msg);
                return false;
            }
        });
        return true;
    };
    $.jBox(html, { title: "重命名", submit: submit });
}

function DeleteFile(FilePath) {
    $.jBox.tip('正在删除，请稍候...', 'loading');
    $.post("/vhost/FileManagerHandler.ashx?act=DeleteFile&t=" + Math.random(), { FilePath: FilePath }, function (data) {
        data = $.parseJSON(data);
        $.jBox.closeTip();
        if (parseInt(data.status) == 1) {
            $.jBox.success("删除成功！");
            var FolderPath = FilePath.substring(0, FilePath.lastIndexOf("/"));
            ListFile(FolderPath);
        } else {
            $.jBox.error("删除失败！<br>" + data.msg);
        }
    });
    return false;
}

function SetSecurity(FilePath) {
    var html = "<div style='padding:10px;'><label><input type='radio' name='security' value='16' />只读</label> <label><input type='radio' name='security' value='3' />可读可写</label> <label><input type='radio' name='security' value='0' />恢复默认</label></div>";
    var submit = function (v, h, f) {
        if (f.security == '') {
            $.jBox.tip("请选择权限。", 'error');
            return false;
        }
        $.jBox.tip('正在设置，请稍候...', 'loading');
        $.post("/vhost/FileManagerHandler.ashx?act=SetSecurity&t=" + Math.random(), { Path: FilePath, security: f.security }, function (data) {
            data = $.parseJSON(data);
            $.jBox.closeTip();
            if (parseInt(data.status) == 1) {
                $.jBox.success("设置成功！");
                var FolderPath = FilePath.substring(0, FilePath.lastIndexOf("/"));
                ListFile(FolderPath);
                return true;
            } else {
                $.jBox.error("设置失败！<br>" + data.msg);
                return false;
            }
        });
        return true;
    };
    $.jBox(html, { title: "设置权限", submit: submit });
}