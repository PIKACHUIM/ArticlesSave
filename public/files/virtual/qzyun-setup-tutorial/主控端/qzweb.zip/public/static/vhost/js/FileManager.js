﻿function SelectDir(path, inputname,basepath) {
    $.jBox.open("正在获取远程文件列表", "选择文件夹", 680, 460, {
        id: "selectdirdialog",
        buttons: { "上一级": 1, "确定": 0 },
        submit: function (v, h, f) {
            if (v == 0) {
                if (basepath != undefined && basepath != '') {
                    var regexp = new RegExp(basepath, "g");
                    $('input[name="' + inputname + '"]').val($("#select").val().replace(regexp, ""));
                } else {
                    $('input[name="' + inputname + '"]').val($("#select").val());
                }
                /*if (needroot == undefined || needroot == true) {
                    $('input[name="' + inputname + '"]').val($("#select").val().replace(/wwwroot/, ""));
                } else {
                    $('input[name="' + inputname + '"]').val($("#select").val());
                }*/
                return true;
            } else {
                var localpath = $("#select").val();
                SelectDir(localpath.substr(0, localpath.lastIndexOf('/')), inputname);
                return false;
            }
        }
    });
    $.getJSON("/vhost/FileManagerHandler.ashx?act=SelectDir&t="+Math.random(), { path: path }, function (data) {
        var html = '<input type="hidden" id="select" value="' + path + '" /><div class="rightitem"><table><thead><tr><th>名称</th><th>修改时间</th></tr></thead><tbody>';
        if (parseInt(data.status) == 1) {
            $(data.info).each(function (i) {
                if (data.info[i].IsDirectory == true) {
                    var t = path + "/" + data.info[i].Name;
                    html += '<tr><td style="text-align:left;"><img src="/images/folder.png" align="absmiddle" /> <a href="javascript:SelectDir(\'' + t + '\',\'' + inputname + '\',\'' + basepath + '\');">' + data.info[i].Name + '</a></td><td>' + data.info[i].Changed + '</td></tr>';
                }
            });
        } else {
            html += '<tr><td colspan="2">获取远程文件列表失败。' + data.msg + '</td></tr>';
        }
        html += '</tbody></table></div>';
        $.jBox.setContent(html);
    });
}

function SelectFile(path, inputname) {
    $.jBox.open("正在获取远程文件列表", "选择文件", 680, 460, {
        id: "selectdirdialog",
        buttons: { "上一级": 1, "确定": 0 },
        submit: function (v, h, f) {
            if (v == 0) {
                $('input[name="' + inputname + '"]').val($("#select").val() + "/" + $("#selectfile").val());
                return true;
            } else {
                var localpath = $("#select").val();
                SelectFile(localpath.substr(0, localpath.lastIndexOf('/')), inputname);
                return false;
            }
        }
    });
    $.getJSON("/vhost/FileManagerHandler.ashx?act=SelectDir&t="+Math.random(), { path: path }, function (data) {
        var html = '<input type="hidden" id="select" value="' + path + '" /><input type="hidden" id="selectfile" value="" /><div class="rightitem"><table><thead><tr><th style="text-align:left;">名称</th><th style="text-align:left; width:180px;">修改时间</th></tr></thead><tbody>';
        if (parseInt(data.status) == 1) {
            $(data.info).each(function (i) {
                if (data.info[i].IsDirectory == true) {
                    var t = path + "/" + data.info[i].Name;
                    html += '<tr><td style="text-align:left;"><img src="/images/folder.png" align="absmiddle" /> <a href="javascript:SelectFile(\'' + t + '\',\'' + inputname + '\');">' + data.info[i].Name + '</a></td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
                } else {
                    html += '<tr><td style="text-align:left;"><img src="/images/unknown.png" align="absmiddle" /> <a href="javascript:Return(\'' + inputname + '\',\'' + data.info[i].Name + '\');">' + data.info[i].Name + '</a></td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
                }
            });
        } else {
            html += '<tr><td colspan="2">获取远程文件列表失败。' + data.msg + '</td></tr>';
        }
        html += '</tbody></table></div>';
        $.jBox.setContent(html);
    });
}

function SelectBakFile(path, inputname) {
    $.jBox.open("正在获取远程文件列表", "选择文件", 680, 460, {
        id: "selectdirdialog",
        buttons: { "上一级": 1, "确定": 0 },
        submit: function (v, h, f) {
            if (v == 0) {
                $('input[name="' + inputname + '"]').val($("#select").val() + "/" + $("#selectfile").val());
                return true;
            } else {
                var localpath = $("#select").val();
                SelectBakFile(localpath.substr(0, localpath.lastIndexOf('/')), inputname);
                return false;
            }
        }
    });
    $.getJSON("/vhost/FileManagerHandler.ashx?act=SelectBakDir&t=" + Math.random(), { path: path }, function (data) {
        var html = '<input type="hidden" id="select" value="' + path + '" /><input type="hidden" id="selectfile" value="" /><div class="rightitem"><table><thead><tr><th style="text-align:left;">名称</th><th style="text-align:left; width:180px;">修改时间</th></tr></thead><tbody>';
        if (parseInt(data.status) == 1) {
            $(data.info).each(function (i) {
                if (data.info[i].IsDirectory == true) {
                    var t = path + "/" + data.info[i].Name;
                    html += '<tr><td style="text-align:left;"><img src="/images/folder.png" align="absmiddle" /> <a href="javascript:SelectBakFile(\'' + t + '\',\'' + inputname + '\');">' + data.info[i].Name + '</a></td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
                } else {
                    html += '<tr><td style="text-align:left;"><img src="/images/unknown.png" align="absmiddle" /> <a href="javascript:Return(\'' + inputname + '\',\'' + data.info[i].Name + '\');">' + data.info[i].Name + '</a></td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
                }
            });
        } else {
            html += '<tr><td colspan="2">获取远程文件列表失败。' + data.msg + '</td></tr>';
        }
        html += '</tbody></table></div>';
        $.jBox.setContent(html);
    });
}

function SelectYunBakFile(path, inputname) {
    $.jBox.open("正在获取远程文件列表", "选择文件", 680, 460, {
        id: "selectdirdialog",
        buttons: { "上一级": 1, "确定": 0 },
        submit: function (v, h, f) {
            if (v == 0) {
                $('input[name="' + inputname + '"]').val($("#select").val() + "/" + $("#selectfile").val());
                return true;
            } else {
                var localpath = $("#select").val();
                SelectYunBakFile(localpath.substr(0, localpath.lastIndexOf('/')), inputname);
                return false;
            }
        }
    });
    $.getJSON("/vhost/FileManagerHandler.ashx?act=SelectYunBakDir&t=" + Math.random(), { path: path }, function (data) {
        var html = '<input type="hidden" id="select" value="' + path + '" /><input type="hidden" id="selectfile" value="" /><div class="rightitem"><table><thead><tr><th style="text-align:left;">名称</th><th style="text-align:left; width:180px;">修改时间</th></tr></thead><tbody>';
        if (data && parseInt(data.status) == 1) {
            $(data.info).each(function (i) {
                if (data.info[i].IsDirectory == true) {
                    var t = path + "/" + data.info[i].Name;
                    html += '<tr><td style="text-align:left;"><img src="/images/folder.png" align="absmiddle" /> <a href="javascript:SelectYunBakFile(\'' + t + '\',\'' + inputname + '\');">' + data.info[i].Name + '</a></td><td style="text-align:left;"> </td></tr>';
                } else {
                    html += '<tr><td style="text-align:left;"><img src="/images/unknown.png" align="absmiddle" /> <a href="javascript:Return(\'' + inputname + '\',\'' + data.info[i].Name + '\');">' + data.info[i].Name + '</a></td><td style="text-align:left;">' + data.info[i].Changed + '</td></tr>';
                }
            });
        } else {
            var msg = '';
            if (data && data.msg) {
                msg = data.msg;
            }
            html += '<tr><td colspan="2">获取远程文件列表失败。' + msg + '</td></tr>';
        }
        html += '</tbody></table></div>';
        $.jBox.setContent(html);
    });
}

function Return(inputname, filename) {
    $('input[name="' + inputname + '"]').val($("#select").val() + "/" + filename);
    $.jBox.close(true);
}