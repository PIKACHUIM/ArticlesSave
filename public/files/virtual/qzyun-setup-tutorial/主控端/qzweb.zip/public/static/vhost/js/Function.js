﻿document.onkeydown = function (event) {
    e = event ? event : (window.event ? window.event : null);
    if (e.keyCode == 13) {
        document.form1.submit();
    }
}

function ShowMenu(locate) {
    if (locate != "" && locate != null && !isNaN(locate)) {
        locate = parseInt(locate);

        for (var i = 1; i <= 6; i++) {
            var obj = document.getElementById("menu" + i + "_1");
            var obj2 = document.getElementById("menu" + i + "_2");

            if (i == locate) {
                obj.className = "li_hover";
                obj2.className = "sel";
            }
            else {
                obj.className = "";
                obj2.className = "";
            }
        }

        switch (locate) {
            case 1:
                document.getElementById("pdtcls").value = "dme";
                document.getElementById("acc").innerHTML = "域名：";
                break;
            case 2:
                document.getElementById("pdtcls").value = "hst";
                document.getElementById("acc").innerHTML = "FTP名称：";
                break;
            case 3:
                document.getElementById("pdtcls").value = "cdn";
                document.getElementById("acc").innerHTML = "CDN用户名：";
                break;
            case 4:
                document.getElementById("pdtcls").value = "mssql";
                document.getElementById("acc").innerHTML = "MSSQL用户名：";
                break;
            case 5:
                document.getElementById("pdtcls").value = "cld";
                document.getElementById("acc").innerHTML = "云主机名称：";
                break;
            case 6:
                document.getElementById("pdtcls").value = "mysql";
                document.getElementById("acc").innerHTML = "Mysql用户名：";
                break;
            case 7:
                document.getElementById("pdtcls").value = "dns";
                document.getElementById("acc").innerHTML = "智能DNS管理：";
                break;
            case 8:
                document.getElementById("pdtcls").value = "edm";
                document.getElementById("acc").innerHTML = "EDM管理：";
                break;

            case 9:
                document.getElementById("pdtcls").value = "et1";
                document.getElementById("acc").innerHTML = "DNS转入管理：";
                break;
        }

    }

}

function lgnfrm() {
    var objusr = document.getElementById("usr");
    var objpwd = document.getElementById("pwd");
    var objtag = document.getElementById("pdtcls");

    if (objusr.value == "") {
        alert("用户名为空！请填写用户名！");
        objusr.focus();
        return false;
    }

    if (objpwd.value == "") {
        alert("登录密码不能为空！请填写登录密码！");
        objpwd.focus();
        return false;
    }

    if (objtag.value == "") {
        alert("页面错误，请重新刷新页面登录！");
        return false;
    }

    //switch (objtag.value) {
    //    case "dme":
    //        document.form1.action = "/domain/login.asp";
    //        break;
    //    case "hst":
    //        document.form1.action = "/host/login.asp";
    //        break;
    //    case "eml":
    //        document.form1.action = "/mail/login.asp";
    //        break;
    //    case "data":
    //        document.form1.action = "/mssql/login.asp";
    //        break;
    //    case "dns":
    //        document.form1.action = "/ot1/login.asp";
    //        break;
    //    case "ot5":
    //        document.form1.action = "/sitestar/login.asp";
    //        break;
    //    case "cld":
    //        document.form1.action = "/cld/checklong.aspx";
    //        break;
    //    case "edm":
    //        document.form1.action = "/edm/login.asp";
    //        break;
    //    case "et1":
    //        document.form1.action = "/dns/login.asp";
    //        break;
    //}

    document.form1.submit();
}

function CheckDMInfo() {
    var obj = document.getElementsByTagName("input");
    var tag = true;

    for (var i = 0; i < obj.length; i++) {
        if (obj[i].type === "text" && obj[i].value === "") {
            tag = false;
            break;
        }
    }

    if (tag) {
        return true;
    }
    else {
        alert("Please Fill all the blank!");
        obj[i].focus();
        return false;
    }

}