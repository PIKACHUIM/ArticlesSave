<?php
namespace qzCloud;

class qzCloud
{
    public $url = NULL;
    protected $accesshash = NULL;
    protected $serverport = NULL;
    protected $extData = NULL;
    protected $masterID = NULL;
    public $result = "";
    public $rawResult = "";
    public $ipaddress = NULL;
    protected $params = array(  );
    protected $configOption = NULL;
    protected $serviceid = NULL;
    protected $pid = NULL;

    public function __construct($params, $debug = false)
    {
        if( $debug === true )
        {
            ini_set("display_errors", 1);
            ini_set("display_startup_errors", 1);
            error_reporting(E_ALL);
        }
        if( is_array($params) )
        {
            $this->params = $params;
        }
        $this->masterID = $this->getParam("serverid");
        $row = \Illuminate\Database\Capsule\Manager::table("tblservers")->where("id", $this->masterID)->first();
        $this->accesshash = $row->accesshash;
        $this->serverport = $row->serverport;
        $this->url = "http://" . $row->hostname.":".$row->port . "/api/whmcs/";
        $this->configOption = $this->getParam("configoptions");
        $this->ipaddress = $row->ipaddress;
        $this->serviceid = $this->getParam("serviceid");
        $this->pid = $this->getParam("pid");
    }

    public function getParam($name)
    {
        if( isset($this->params[$name]) )
        {
            return $this->params[$name];
        }

        return "";
    }

    public function getExtData($name)
    {
        if( isset($this->extData[$name]) )
        {
            return $this->extData[$name];
        }

        return "";
    }

    private function createNonceStr($length = 32)
    {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $str = "";
        for( $i = 0; $i < $length; $i++ )
        {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }

    private function arithmetic($timeStamp, $randomStr, $token)
    {
        $arr["timeStamp"] = $timeStamp;
        $arr["randomStr"] = $randomStr;
        $arr["token"] = $token;
        sort($arr, SORT_STRING);
        $str = implode($arr);
        $signature = md5($str);
        $signature = strtoupper($signature);
        return $signature;
    }

    public function signature($token)
    {
        $timeStamp = time();
        $randomStr = $this->createNonceStr();
        $signature = $this->arithmetic($timeStamp, $randomStr, $token);
        return array( "time" => $timeStamp, "random" => $randomStr, "signature" => $signature );
    }

    public function TestConnection($ipaddr, $token)
    {
        $url = $this->url."line";
        $client = new \GuzzleHttp\Client(array( "verify" => false,'headers' => ['apikey' => $this->accesshash] ));
        $result = $client->get($url);
        $result = json_decode($result->getBody());
        return $result;
    }

    public function noVNC($vmID)
    {

        return $this->url . "vnc_view?host_id=" . $vmID . "&signature=" .md5($this->accesshash.$vmID);
    }

    public function apiCall($action = "POST", $faction, $postVars = array(  ))
    {
        $this->jsonResult = "";
        $this->result = "";
        try
        {
            $client = new \GuzzleHttp\Client(array( "base_uri" => $this->url, "verify" => false,'headers' => ['apikey' => $this->accesshash] ));
            if( $action == "GET" )
            {
                $result = $client->get($faction);
            }
            else
            {

                $postArry = array( "form_params" => $postVars );
                $result = $client->request($action, $faction, $postArry);
            }

            $result->result = json_decode($result->getBody());

        }
        catch( RequestException $e )
        {
            return $e->getRequest();
        }
        return $result;
    }

    public function serverExtra($mServer = array(  ))
    {
        if( !isset($mServer["master"]) )
        {
            return array(  );
        }

        $results = array(  );
        $masterPart = explode("-", $mServer["master"]);
        $row = \Illuminate\Database\Capsule\Manager::table("tblservers")->where("id", $masterPart[0])->first();
        if( $row )
        {
            $data = htmlspecialchars_decode($row->accesshash);
            $results = $this->sortReturn($data);
        }

        if( !is_array($results) )
        {
            return array(  );
        }

        return $results;
    }

    public function passwordGen($length = 10, $chars = "abcdefghijklmnopqrstuvwxyzABCEFGHIJKLMNOPQRSTUVWXYZ1234567890")
    {
        $chars_length = strlen($chars) - 1;
        $string = $chars[rand(0, $chars_length)];
        $i = 1;
        while( $i < $length )
        {
            $r = $chars[rand(0, $chars_length)];
            if( $r != $string[$i - 1] )
            {
                $string .= $r;
            }

            $i = strlen($string);
        }
        return $string;
    }

    public function getBuildOS()
    {
        $configType = "os";
        if( !isset($this->configOption[$configType]) )
        {

            $buildOperatingSystem = $this->getParam("configoption2");
        }
        else
        {
            $ossplit = explode("|", $this->configOption[$configType]);
            $buildOperatingSystem = $ossplit[0];
        }

        return $buildOperatingSystem;
    }

    public function getCPU()
    {

        $configType = "cpu";
        if( !isset($this->configOption[$configType]) )
        {

            $cpu = $this->getParam("configoption3");
        }
        else
        {
            $cpusplit = explode("|", $this->configOption[$configType]);
            $cpu = $cpusplit[0];
        }

        return $cpu;

    }

    public function getMemory()
    {

        $configType = "memory";
        if( !isset($this->configOption[$configType]) )
        {

            $memory = $this->getParam("configoption4");
        }
        else
        {
            $memorysplit = explode("|", $this->configOption[$configType]);
            $memory = $memorysplit[0];
        }

        return $memory;

    }

    public function getBandwidth()
    {

        $configType = "bandwidth";
        if( !isset($this->configOption[$configType]) )
        {

            $bandwidth = $this->getParam("configoption5");
        }
        else
        {
            $bandwidthsplit = explode("|", $this->configOption[$configType]);
            $bandwidth = $bandwidthsplit[0];
        }

        return $bandwidth;

    }
    public function getHardDisks()
    {

        $configType = "hard_disks";
        if( !isset($this->configOption[$configType]) )
        {

            $disks = $this->getParam("configoption6");
        }
        else
        {
            $diskssplit = explode("|", $this->configOption[$configType]);
            $disks = $diskssplit[0];
        }

        return $disks;

    }


    public function getPortnum()
    {

        $configType = "port";
        if( !isset($this->configOption[$configType]) )
        {

            $portnum = $this->getParam("configoption8");
        }
        else
        {
            $portnumsplit = explode("|", $this->configOption[$configType]);
            $portnum = $portnumsplit[0];
        }

        return $portnum;

    }

    public function getSnapshotNum()
    {

        $configType = "snapshot";
        if( !isset($this->configOption[$configType]) )
        {

            $snapshot = $this->getParam("configoption9");
        }
        else
        {
            $snapshotsplit = explode("|", $this->configOption[$configType]);
            $snapshot = $snapshotsplit[0];
        }

        return $snapshot;

    }

    public function getBackupNum()
    {

        $configType = "backup";
        if( !isset($this->configOption[$configType]) )
        {

            $backup = $this->getParam("configoption10");
        }
        else
        {
            $backupsplit = explode("|", $this->configOption[$configType]);
            $backup = $backupsplit[0];
        }

        return $disks;

    }

    public function getIpNum()
    {

        $configType = "ip";
        if( !isset($this->configOption[$configType]) )
        {

            $ip = $this->getParam("configoption7");
        }
        else
        {
            $ipsplit = explode("|", $this->configOption[$configType]);
            $ip = $ipsplit[0];
        }

        return $ip;

    }
    public function getLinesid()
    {
        $configType = "lines";
        if( !isset($this->configOption[$configType]) )
        {
            $splitlines = explode("|", $this->getParam("configoption1"));
            $line = $splitlines[0];
        }
        else
        {
            $splitlines = explode("|", $this->configOption[$configType]);
            $line = $splitlines[0];
        }

        return $line;
    }

    public function getNewDataPassword()
    {
        if( $this->getParam("password") == "auto-generated" || $this->getParam("password") == "" )
        {
            $this->params["password"] = $this->passwordGen();
            $passwordenc = encrypt($this->params["password"]);
            \Illuminate\Database\Capsule\Manager::table("tblhosting")->where("id", $this->serviceid)->update(array( "password" => $passwordenc ));
        }

        $newData = \Illuminate\Database\Capsule\Manager::table("tblhosting")->where("id", $this->serviceid)->first();
        $newDataPassword = decrypt($newData->password);
        return $newDataPassword;
    }

    public function removeipTerminatedProduct()
    {
        if( $this->getExtData("removeip-terminated-product") != "no" )
        {
            \Illuminate\Database\Capsule\Manager::table("tblhosting")->where("id", $this->serviceid)->update(array( "dedicatedip" => "", "assignedips" => "" ));
        }

    }

    public function removesnapshotTerminatedProduct()
    {
        $customFields = $this->getParam("customfields");
        $data = array( "id" => $customField["qzhost_id"] );
        $result = $this->apiCall("panel_delete_snapshot", $data)->result;
    }

    public function removebackupsTerminatedProduct()
    {
        $customFields = $this->getParam("customfields");
        $data = array( "id" => $customField["qzhost_id"] );
        $result = $this->apiCall("panel_delete_fullbackup", $data)->result;
    }

    public function removeqzhost_idTerminatedProduct()
    {
        if( $this->getExtData("removeqzhost_id-terminated-product") != "no" )
        {
            $this->setCustomfieldsValue("qzhost_id", "");
        }

    }

    public function setCustomfieldsValue($field, $value)
    {
        $value = (string) $value;
        $res = \Illuminate\Database\Capsule\Manager::table("tblcustomfields")->where("relid", $this->pid)->where("fieldname", $field)->first();
        if( $res )
        {
            $fieldValue = \Illuminate\Database\Capsule\Manager::table("tblcustomfieldsvalues")->where("relid", $this->serviceid)->where("fieldid", $res->id)->first();
            if( $fieldValue )
            {
                if( $fieldValue->value !== $value )
                {
                    \Illuminate\Database\Capsule\Manager::table("tblcustomfieldsvalues")->where("relid", $this->serviceid)->where("fieldid", $res->id)->update(array( "value" => $value ));
                }

            }
            else
            {
                \Illuminate\Database\Capsule\Manager::table("tblcustomfieldsvalues")->insert(array( "relid" => $this->serviceid, "fieldid" => $res->id, "value" => $value ));
            }

        }

    }

    public static function validateRootPassword($newRootPassword)
    {
        $is_valid = false;
        if( 5 < strlen($newRootPassword) && preg_match("/^[a-zA-Z0-9\\-_]{0,50}\$/i", $newRootPassword) )
        {
            $is_valid = true;
        }

        return $is_valid;
    }

    public static function validateVNCPassword($newVNCPassword)
    {
        $is_valid = false;
        if( 5 < strlen($newVNCPassword) && preg_match("/^[a-zA-Z0-9\\-_]{0,50}\$/i", $newVNCPassword) )
        {
            $is_valid = true;
        }

        return $is_valid;
    }

    public static function getParamsFromServiceID($servid, $uid = NULL)
    {
        $ownerRow = \Illuminate\Database\Capsule\Manager::table("tblhosting")->where("id", $servid)->where("userid", $uid)->first();
        if( !$ownerRow )
        {
            return false;
        }

        if( !is_null($uid) && $uid != $ownerRow->userid )
        {
            return false;
        }

        $vserverFieldRow = \Illuminate\Database\Capsule\Manager::table("tblcustomfields")->where("relid", $ownerRow->packageid)->where("fieldname", "qzhost_id")->first();
        if( !$vserverFieldRow )
        {
            return false;
        }

        $vserverValueRow = \Illuminate\Database\Capsule\Manager::table("tblcustomfieldsvalues")->where("fieldid", $vserverFieldRow->id)->where("relid", $ownerRow->id)->first();
        if( !$vserverValueRow )
        {
            return false;
        }

        if( !is_numeric($vserverValueRow->value) )
        {
            return false;
        }

        $serverid = $ownerRow->server;
        if( $serverid == "0" || $serverid == "" )
        {
            $productRow = \Illuminate\Database\Capsule\Manager::table("tblproducts")->where("id", $ownerRow->packageid)->first();
            $masterPart = explode("|", $productRow->configoption1);
            $serverid = $masterPart[0];
        }

        return array( "serverid" => $serverid, "vserver" => $vserverValueRow->value, "serviceid" => $vserverValueRow->relid, "pid" => $vserverFieldRow->relid );
    }


    public function bwFormat($size)
    {
        $bytes = array( " KB", " MB", " GB", " TB" );
        $resVal = "";
        foreach( $bytes as $val )
        {
            $resVal = $val;
            if( 1024 <= $size )
            {
                $size = $size / 1024;
            }
            else
            {
                break;
            }

        }
        return round($size, 1) . $resVal;
    }

    public function formatSize($size)
    {
        $sizes = array( " Bytes", " KB", " MB", " GB", " TB" );
        if( empty($size) || $size == "0.0" || $size == "0.00" || $size == "0" )
        {
            return "n/a";
        }

        return round($size / pow(1024, $i = floor(log($size, 1024))), 2) . $sizes[$i];
    }

    public function setHostname($newhostname)
    {
        if( !empty($this->serviceid) )
        {
            \Illuminate\Database\Capsule\Manager::table("tblhosting")->where("id", $this->serviceid)->update(array( "domain" => $newhostname ));
        }

    }

    public static function loadLang($lang = NULL)
    {
        global $_LANG;
        global $CONFIG;
        $langDir = __DIR__ . "/../lang/";
        $availableLangsFullPath = glob($langDir . "*.php");
        $availableLangs = array(  );
        foreach( $availableLangsFullPath as $availableLang )
        {
            $availableLangs[] = strtolower(basename($availableLang));
        }
        if( empty($lang) )
        {
            if( isset($_SESSION["Language"]) )
            {
                $language = $_SESSION["Language"];
            }
            else
            {
                if( isset($_SESSION["adminlang"]) )
                {
                    $language = $_SESSION["adminlang"];
                }
                else
                {
                    $language = $CONFIG["Language"];
                }

            }

        }
        else
        {
            $language = $lang;
        }

        $language = strtolower($language) . ".php";
        if( !in_array($language, $availableLangs) )
        {
            $language = "english.php";
        }

        require_once($langDir . $language);
    }

}
?>