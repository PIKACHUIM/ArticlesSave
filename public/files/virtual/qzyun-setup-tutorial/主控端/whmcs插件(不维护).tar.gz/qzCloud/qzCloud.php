<?php
require_once(__DIR__ . "/lib/qzCloud.php");
if( !defined("WHMCS") )
{
    exit( "This file cannot be accessed directly" );
}

qzCloud\qzCloud::loadLang();
function qzCloud_MetaData()
{
    return array( "DisplayName" => "qzCloud", "APIVersion" => "1.0", "RequiresServer" => true );
}

function qzCloud_initConfigOption()
{
    if( !isset($_POST["id"]) )
    {
        $data = Illuminate\Database\Capsule\Manager::table("tblproducts")->where("servertype", "qzCloud")->where("id", $_GET["id"])->get();
    }
    else
    {
        $data = Illuminate\Database\Capsule\Manager::table("tblproducts")->where("servertype", "qzCloud")->where("id", $_POST["id"])->get();
    }

    $packageconfigoption = array(  );
    if( is_array($data) && 0 < count($data) )
    {
        list($packageconfigoption[1]) = explode("|", $data[0]->configoption1);
        list($packageconfigoption[2]) = explode("|", $data[0]->configoption2);
        list($packageconfigoption[3]) = explode("|", $data[0]->configoption3);
    }

    return $packageconfigoption;
}

function qzCloud_ConfigOptions()
{
    try
    {
        $packageconfigoption = qzcloud_initconfigoption();
        $master = Illuminate\Database\Capsule\Manager::table("tblservers")->where("type", "qzCloud")->first();
        $qzcloud = new qzCloud\qzCloud(array( "serverid" => $master->id ));
        $lines = $qzcloud->apiCall("GET", "line")->result->data;
        $lines =(array)$lines;
        foreach( $lines as $key => $val)
        {
            $line[] = $val->id. "|" . $val->line_name;
        }
        $lines = implode(",", $line);


        $configarray = array(
            "线路" => array( "Type" => "dropdown", "Size" => "30", "Options" => (string) $lines,"Description" => "<style>.module-settings select { min-width: 180px;display: block;margin-bottom: 5px;}</style>所属线路" ),
            "默认镜像" => array( "Type" => "text", "Size" => "30", "Description" => "默认镜像标识，节点计算机必须存在此镜像","Default"=>"centos7" ),
            "CPU" => array( "Type" => "text", "Size" => "30", "Description" => "CPU核心数","Default"=>"2" ),
            "内存" => array( "Type" => "text", "Size" => "30", "Description" => "内存GB","Default"=>"2" ),
            "带宽" => array( "Type" => "text", "Size" => "30", "Description" => "带宽MB","Default"=>"2" ),
            "硬盘" => array( "Type" => "text", "Size" => "30", "Description" => "硬盘GB","Default"=>"10" ),
            "IP" => array( "Type" => "text", "Size" => "30", "Description" => "IP个数，云主机可填写0","Default"=>"1" ),
            "备份数量" => array( "Type" => "text", "Size" => "30", "Description" => "","Default"=>"1" ),
            "快照数量" => array( "Type" => "text", "Size" => "30", "Description" => "","Default"=>"1" ),
        );
        return $configarray;
    }
    catch( Exception $e )
    {
        logModuleCall("Config Options", "qzCloud_ConfigOptions", "", $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_CreateAccount($params)
{
    try
    {
        $qzcloud = new qzCloud\qzCloud($params);
        $userid = $qzcloud->getParam("userid");
        $serviceid = $qzcloud->getParam("serviceid");
        $clientsdetails = $qzcloud->getParam("clientsdetails");
        $customField = $qzcloud->getParam("customfields");
        $newDataPassword = $qzcloud->getNewDataPassword();


        $line_id = $qzcloud->getLinesid();

        $os = $qzcloud->getBuildOS();
        // $productid = $qzcloud->getProductid();
        $cpu =  $qzcloud->getCPU();
        $memory =  $qzcloud->getMemory();
        $bandwidth =  $qzcloud->getBandwidth();
        $disks =  $qzcloud->getHardDisks();
        $ip =  $qzcloud->getIpNum();
        $nextduedate = $params['model']->nextduedate;
        $portnum = $qzcloud->getPortnum();
        $snapshot = $qzcloud->getSnapshotNum();
        $backup = $qzcloud->getBackupNum();


        $noVps = "";
        $r = array(  );
        if( empty($customField["qzhost_id"]) )
        {
            $noVps = "success";
        }
        else
        {
            $VMid = $customField["qzhost_id"];
            $result = $qzcloud->apiCall("GET", "hostinfo?host_id=" . $VMid);
            $r = $result->result;
        }

        if(!empty($r->data))
        {
            return "云主机 qzhost_id 已存在！";
        }

        $callArray = array(
            "users_id" => $userid,
            "username" => $clientsdetails["email"],
            "line_id" => $line_id,
            "os" =>$os,
            "sys_pwd" => $newDataPassword,
            "vnc_pwd" => $qzcloud->passwordGen(),
            "expire_time" => $nextduedate ,
            "cpu"=>$cpu,
            "memory"=>$memory,
            "bandwidth"=>$bandwidth,
            "hard_disks"=>$disks,
            "ipnum"=>$ip,
            "port_num"=>$portnum,
            "snapshot_num"=>$snapshot,
            "backup_num"=>$backup,
        );

        logModuleCall("create virtual", "", $callArray, $callArray, "");
        $result = $qzcloud->apiCall("POST", "create_host", $callArray);
        $r = $result->result;
        if( $r->code == "1" )
        {
            $qzcloud->setCustomfieldsValue("qzhost_id", $r->data->host_id);
            $mainip = $r->data->ip;
            $qzcloud->setHostname($r->data->host_name);

            Illuminate\Database\Capsule\Manager::table("tblhosting")->where("id", $serviceid)->update(array( "dedicatedip" => $mainip ));
            $result = "success";
        }
        else
        {
            $result = $r->msg;
        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("Create Virtual", "qzCloud_CreateAccount", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}
 
function qzCloud_Renew($params = ""){
    global $_LANG;
    try
    {
        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $nextduedate = $params['model']->nextduedate;
        
        $results = $qzcloud->apiCall("GET", "renew?host_id=" . $VMid.'&nextduedate='.$nextduedate)->result;
        if( $call->code == "1" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $call->msg;
        }
 
        logModuleCall("hosting Renew", "qzCloud_Renew", $params, $result, "");
        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("hosting Renew", "qzCloud_Renew", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}
function qzCloud_Custom_Reinstall($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $templateID = $postParam["templateID"];
    $password = $postParam["newpassword"];
    $VMid = $customField["qzhost_id"];
    $call = $qzcloud->apiCall("GET", "reset_os?host_id=" . $VMid . "&template_id=" . $templateID."&password=".$password);
 
    if( $call->result->code == "1" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg );
    exit( json_encode($result) );
}

function qzCloud_SuspendAccount($params)
{
    try
    {
        if( function_exists("qzCloud_suspend_pre") )
        {
            qzCloud_suspend_pre($params);
        }

        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $results = $qzcloud->apiCall("GET", "lock?host_id=" . $VMid)->result;
        if( $results->code == "1" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $results->msg;
        }

        if( $result == "success" )
        {
            if( function_exists("qzCloud_suspend_post_success") )
            {
                qzCloud_suspend_post_success($params);
            }

        }
        else
        {
            if( function_exists("qzCloud_suspend_post_error") )
            {
                qzCloud_suspend_post_error($params);
            }

        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("Suspend Account", "qzCloud_SuspendAccount", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_UnsuspendAccount($params)
{
    try
    {
        if( function_exists("qzCloud_unsuspend_pre") )
        {
            qzCloud_unsuspend_pre($params);
        }

        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $results = $qzcloud->apiCall("GET", "unlock?host_id=" . $VMid)->result;
        if( $results->code == "1" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $results->msg;
        }

        if( $result == "success" )
        {
            if( function_exists("qzCloud_unsuspend_post_success") )
            {
                qzCloud_unsuspend_post_success($params);
            }

        }
        else
        {
            if( function_exists("qzCloud_unsuspend_post_error") )
            {
                qzCloud_unsuspend_post_error($params);
            }

        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("Unsuspend Account", "qzCloud_UnsuspendAccount", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_TerminateAccount($params)
{
    try
    {
        if( function_exists("qzCloud_terminate_pre") )
        {
            qzCloud_terminate_pre($params);
        }

        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $results = $qzcloud->apiCall("get", "delete?host_id=" . $VMid)->result;
        if( $results->code == "1" )
        {
            $qzcloud->removeipTerminatedProduct();
            $qzcloud->removeqzhost_idTerminatedProduct();
            $result = "success";
        }
        else
        {
            $result = (string) $results->msg;
        }

        if( $result == "success" )
        {
            if( function_exists("qzCloud_terminate_post_success") )
            {
                qzCloud_terminate_post_success($params);
            }

        }
        else
        {
            if( function_exists("qzCloud_terminate_post_error") )
            {
                qzCloud_terminate_post_error($params);
            }

        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("Terminate Account", "qzCloud_TerminateAccount", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_ChangePackage($params)
{
    global $_LANG;
    try
    {
      
     // var_dump($params);
        if( function_exists("qzCloud_changepackage_pre") )
        {
            $res = qzCloud_changepackage_pre($params);
            if( $res["cancel_process"] === true )
            {
                return $_LANG["qzcloud_cancel_custom_package_change_process"];
            }

        }
/*var_dump($params);die;
        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $productid = $qzcloud->getProductid();
        $callArray = array( "product_id" => $productid,"host_id"=>$VMid);
        $call = $qzcloud->apiCall("post", "updatehost", $callArray)->result;
        if( $call->code == "1" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $call->msg;
        }
*/
        logModuleCall("Change Package", "qzCloud_ChangePackage", $params, $result, "");
        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("Change Package", "qzCloud_ChangePackage", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_Custom_ChangePassword($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $newPassword = $postParam["newpassword"];
    $callArray = array( "type" => "system", "password" => $newPassword );
    $result = $qzcloud->apiCall("post", "reset_password?host_id=" . $VMid, $callArray);
    $r = $result->result;
    if( $r->code == "1" )
    {
        $message = $_LANG["qzcloud_passwordUpdated"];
        $result = (object) array( "status" => "success", "message" => $r->msg, "newpassword" => $newPassword );
    }
    else
    {
        $result = (object) array( "status" => "error", "message" => $r->msg );
    }

    exit( json_encode($result) );
}

function qzCloud_Custom_actionSnapshot($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $snapshotID = $postParam["sID"];
    switch( $postParam["request"] )
    {
        case "Create":
            $call = $qzcloud->apiCall("GET", "snapshot_add?host_id=".$VMid);
            break;
        case "Restore":
            $call = $qzcloud->apiCall("GET", "snapshot_restore?host_id=".$VMid."&id=".$snapshotID);
            break;
        case "Delete":
            $call = $qzcloud->apiCall("GET", "snapshot_del?host_id=".$VMid."&id=".$snapshotID);
            break;
        default:
            break;
    }
    if( $call->result->code == "0" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg, "data" => $call->result->data );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg );
    exit( json_encode($result) );
}

function qzCloud_Custom_actionBackups($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $sID = $postParam["sID"];
    switch( $postParam["request"] )
    {
        case "Create":
            $call = $qzcloud->apiCall("GET", "backups_add?host_id=".$VMid);
            break;
        case "Restore":
            $call = $qzcloud->apiCall("GET", "backups_restore?host_id=".$VMid."&id=".$sID);
            break;
        case "Delete":
            $call = $qzcloud->apiCall("GET", "backups_del?host_id=".$VMid."&id=".$sID);
            break;
        default:
            break;
    }
    if( $call->result->code == "1" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg, "data" => $call->result->data );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg );
    exit( json_encode($result) );
}

function qzCloud_Custom_actionCdRom($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $type = $postParam["type"];
    $iso = $postParam["iso"];
    if($type=="mount"){
        $iso=="";
    }
    $call = $qzcloud->apiCall("GET", "mountiso?host_id=" . $VMid . "&iso=" . $iso);
    if( $call->result->code == "1" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg );
    exit( json_encode($result) );
}

function qzCloud_Custom_createSecurityAcl($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $callArray = array( "hostid" => $VMid, "direction" => $postParam["direction"],"method"=> $postParam["method"],"priority" => $postParam["priority"], "protocol" => $postParam["type"], "port" => $postParam["port"],  "ip" => $postParam["ip"]);
    $call = $qzcloud->apiCall("POST", "security_acl_add", $callArray);
    if( $call->result->code == "1" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg, "data" => $call->result->data );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg);
    exit( json_encode($result) );
}

function qzCloud_Custom_switchSecurityAcl($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $enable  = $postParam["enable"];
    $call = $qzcloud->apiCall("GET", "firewallswitch?host_id=".$VMid."&enable=" . $enable);
    if( $call->result->code == "1" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg );
    exit( json_encode($result) );
}

function qzCloud_Custom_deleteSecurityAcl($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $aclID = $postParam["aid"];
    $call = $qzcloud->apiCall("GET", "security_acl_del?host_id=".$VMid."&id=" . $aclID);
    if( $call->result->code == "1" )
    {
        $result = (object) array( "status" => "success", "message" => $call->result->msg );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $call->result->msg );
    exit( json_encode($result) );
}

function qzCloud_Custom_addForwardPort($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $dport = $postParam["dport"];
    $name = $postParam["name"];
   
    $callArray = array("host_id"=>$VMid,"dport"=>$dport,"name"=>$name );
    logModuleCall("addForwardPort", "", $callArray, $callArray, "");
    $result = $qzcloud->apiCall("POST", "add_port_host", $callArray);
   
    if( $result->result->code == "0" )
    {
        $result = (object) array( "status" => "success", "message" => $result->result->msg, "data" => $result->result->data );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "error", "message" => $result->result->msg );
    exit( json_encode($result) );
}

function qzCloud_Custom_delForwardPort($params = "")
{
    global $_LANG;
    $qzcloud = new qzCloud\qzCloud($params);
    $customField = $qzcloud->getParam("customfields");
    $postParam = $qzcloud->getParam("POST");
    $VMid = $customField["qzhost_id"];
    $forwardId = $postParam["sid"];
    $result = $qzcloud->apiCall("GET", "remove_port_host?hostid=".$VMid."&id=".$forwardId);
    if( $result->result->code == "0" )
    {
        $result = (object) array( "status" => "error", "message" => $result->result->msg, "data" => $result->result->data );
        exit( json_encode($result) );
    }

    $result = (object) array( "status" => "success", "message" => $result->result->msg );
    exit( json_encode($result) );
}

function qzCloud_AdminCustomButtonArray()
{
    global $_LANG;
    return array( $_LANG["qzcloud_boot"] => "boot", $_LANG["qzcloud_reboot"] => "reboot", $_LANG["qzcloud_shutdown"] => "shutdown" );
}

function qzCloud_ClientAreaCustomButtonArray()
{
    return array();
    //global $_LANG;
    //return array( $_LANG["qzcloud_boot"] => "boot", $_LANG["qzcloud_reboot"] => "reboot", $_LANG["qzcloud_shutdown"] => "shutdown" );
}

function qzCloud_boot($params)
{
    try
    {
        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $call = $qzcloud->apiCall("GET", "start?host_id=" . $VMid );
         
        if( $call->result->code == "1" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $call->result->msg;
        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("boot", "qzCloud_boot", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_reboot($params)
{
    try
    {
        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $call = $qzcloud->apiCall("GET", "reboot?host_id=" . $VMid );
        if( $call->result->code == "1" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $call->result->msg;
        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("reboot", "qzCloud_reboot", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_shutdown($params)
{
    try
    {
        $qzcloud = new qzCloud\qzCloud($params);
        $customField = $qzcloud->getParam("customfields");
        $VMid = $customField["qzhost_id"];
        $call = $qzcloud->apiCall("GET", "shutdown?host_id=" . $VMid );
        if( $call->result->code == "0" )
        {
            $result = "success";
        }
        else
        {
            $result = (string) $call->result->message;
        }

        return $result;
    }
    catch( Exception $e )
    {
        logModuleCall("shutdown", "qzCloud_shutdown", $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }
}

function qzCloud_ClientArea($params)
{
    global $_LANG;
    $qzcloud = new \qzCloud\qzCloud($params);
    $status = $qzcloud->getParam('status');
    $customField = $qzcloud->getParam('customfields');
    $VMid = $customField['qzhost_id'];
    $userid = $qzcloud->getParam('userid');
   
    if (isset($_GET['modop']) && $_GET['modop'] == 'custom') {
        if (isset($_GET['a'])) {
            if(!in_array($_GET['a'], array( "boot", "reboot", "shutdown" ))){
                $functionName = 'qzCloud_' . 'Custom_' . $_GET['a'];
            }else{
                $functionName = 'qzCloud_' . $_GET['a'];
            }
            $params['POST'] = $_POST;
            if (function_exists($functionName)) {
                $result = $functionName($params);
                if($result!='success'){
                    $result = (object) array('success' => false, 'msg' => $result);
                    exit(json_encode($result));
                }
            }
            else {
                $result = (object) array('success' => false, 'msg' => '命令：' . $functionName . ' 不存在');
                exit(json_encode($result));
            }
        }
    }

    if (isset($_GET['getVNC'])) {
        $result = $qzcloud->noVNC($VMid);
        exit(json_encode($result));
    }

    if (isset($_GET['getChart'])) {
        $monitor = $qzcloud->apiCall('GET', 'monitor?host_id=' . $VMid)->result->data;
        exit(json_encode($monitor));
    }

    try {
        if ($status != 'Active') {
            $lang = 'clientarea' . strtolower($status);
            $result = array('status' => 'error', 'message' => '您的产品状态为：' . Lang::trans($lang));
        }

        $info = $qzcloud->apiCall('GET', 'hostinfo?host_id=' . $VMid)->result;
 
        if ($info->code == '0') {
            $result = array('status' => 'error', 'message' => $info->msg);
        }
       
        else if (!in_array($info->data->state,[1,2,3,5,4,6,8])) {
            $result = array('status' => 'error', 'message' => '请联系管理员');
        }
        else {
            $result = array('status' => 'success');

            $info = $info->data;
            switch ($info->state) {
                case '1':
                    $info->status = 'Creating';
                    break;

                case '2':
                    $info->status = 'Running';
                    break;

                case '5':
                    $info->status = 'Poweroff';
                    break;

                case '4':
                    $info->status = 'Pending';
                    break;
                case '8':
                    $info->status = 'Reinstalling';
                    break;
                default:
                    $info->status = 'offline';
                    break;
            }
            

            $backups = $qzcloud->apiCall('GET', 'backups_list?host_id=' . $VMid)->result->data;
             

            $mirror_image = $qzcloud->apiCall('GET', 'mirror_image?host_id='.$VMid)->result->data;
 
           
            $templates=[];
         
            foreach ($mirror_image as $key => $value) {
                $templates[$value->type][$key]->id = $value->id;
                $templates[$value->type][$key]->name = $value->name;
            }
 
            $snapshots = $qzcloud->apiCall('GET', 'snapshot_list?host_id=' . $VMid)->result->data;
            $securitys = $qzcloud->apiCall('GET', 'security_acl_list?host_id=' . $VMid)->result->data;
             
      
            $cd_rom = $qzcloud->apiCall('GET', 'cdrom?host_id='.$VMid)->result->data;
            $forwardPort = $qzcloud->apiCall('GET', 'nat_acl_list?host_id=' . $VMid)->result->data;
           
       
        }
    }
    catch (Exception $e) {
        logModuleCall('Client Area', 'qzCloud_ClientArea', $params, $e->getMessage(), $e->getTraceAsString());
        return $e->getMessage();
    }

    if (isset($_GET['json'])) {
        exit(json_encode($info));
    }
    
    if ($result['status'] == 'success') {
        return array(
            'overrideDisplayTitle'           => $productName,
            'tabOverviewReplacementTemplate' => 'templates/clientarea.tpl',
            'vars'                           => array('id'=>$_GET['id'],'status' => $status, 'info' => $info, 'cd_rom' => $cd_rom, 'backups' => $backups, 'snapshots' => $snapshots, 'securitys' => $securitys, 'templates' => $templates, 'forwardPort' => $forwardPort,'forwardDomain' => $forwardDomain, '_LANG' => $_LANG)
        );
    }
    return array(
        'overrideDisplayTitle'           => $productName,
        'tabOverviewReplacementTemplate' => 'templates/error.tpl',
        'vars'                           => array('result' => $result, '_LANG' => $_LANG)
    );
}

function qzCloud_TestConnection($params)
{
    try
    {
        $master = Illuminate\Database\Capsule\Manager::table("tblservers")->where("type", "qzCloud")->first(); 
        $params['serverid']=$master->id;
        $qzcloud = new qzCloud\qzCloud($params);
        $data = $qzcloud->TestConnection($params["serverip"], $params["serveraccesshash"]);
        if( $data->code == 1 )
        {
            $success = true;
            $errorMsg = "";
        }
        else
        {
            $success = false;
            $errorMsg = $data->msg;
        }

    }
    catch( Exception $e )
    {
        logModuleCall("provisioningmodule", "qzCloud_TestConnection", $params, $e->getMessage(), $e->getTraceAsString());
        $success = false;
        $errorMsg = $e->getMessage();
    }
    return array( "success" => $success, "error" => $errorMsg );
}
?>