var cloud =
    {
        os : 'Linux',
        check_ip : function(ip) //验证ip
        {
            var reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/;
            return reg.test(ip);
        },
        check_ips : function(ips)//验证ip段
        {
            var reg = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(\/\d{1,2})?$/;
            return reg.test(ip);
        },
        check_url : function(url) //验证url
        {
            var reg = /^((https|http|ftp|rtsp|mms)?:\/\/)[^\s]+/;
            return reg.test(url);
        },
        check_port : function(port)
        {
            var reg = /^([1-9]|[1-9]\d|[1-9]\d{2}|[1-9]\d{3}|[1-5]\d{4}|6[0-4]\d{3}|65[0-4]\d{2}|655[0-2]\d|6553[0-5])$/;
            return reg.test(port);
        },
        check_chinese : function(str)
        {
            var reg = /[\u4e00-\u9fa5]/;
            return reg.test(str);
        },
        check_domain : function(domain) //验证域名
        {
            var reg = /^([\w\-\*]{1,100}\.){1,4}([\w\-]{1,24}|[\w\-]{1,24}\.[\w\-]{1,24})$/;
            return reg.test(bt.strim(domain));
        },
        check_img : function(fileName) //验证是否图片
        {
            var exts = ['jpg','jpeg','png','bmp','gif','tiff','ico'];
            var check =  bt.check_exts(fileName,exts);
            return check;
        },
        check_zip : function(fileName)
        {
            var ext = fileName.split('.');
            var extName = ext[ext.length-1].toLowerCase();
            if( extName == 'zip') return 0;
            if( extName == 'rar') return 2;
            if( extName == 'gz' || extName == 'tgz') return 1;
            return -1;
        },
        check_text : function(fileName)
        {
            var exts = ['rar','zip','tar.gz','gz','iso','xsl','doc','xdoc','jpeg','jpg','png','gif','bmp','tiff','exe','so','7z','bz'];
            return bt.check_exts(fileName,exts)?false:true;
        },
        check_exts : function(fileName,exts)
        {
            var ext = fileName.split('.');
            if(ext.length < 2) return false;
            var extName = ext[ext.length-1].toLowerCase();
            for(var i=0;i<exts.length;i++){
                if(extName == exts[i]) return true;
            }
            return false;
        },
        replace_all:function(str,old_data,new_data){
            var reg_str = "/("+old_data+"+)/g"
            var reg = eval(reg_str);
            return str.replace(reg,new_data);
        },
        get_file_ext : function(fileName)
        {
            var text = fileName.split(".");
            var n = text.length-1;
            text = text[n];
            return text;
        },
        get_file_path : function(filename)
        {
            var arr = filename.split('/');
            path = filename.replace('/'+arr[arr.length-1],"");
            return path;
        },
        get_date:function(a){
            var dd = new Date();
            dd.setTime(dd.getTime() + (a == undefined || isNaN(parseInt(a)) ? 0 : parseInt(a)) * 86400000);
            var y = dd.getFullYear();
            var m = dd.getMonth() + 1;
            var d = dd.getDate();
            return y + "-" + (m < 10 ? ('0' + m) : m) + "-" + (d < 10 ? ('0' + d) : d);
        },
        ltrim:function(str,r){
            var reg_str = "/(^\\"+r+"+)/g"
            var reg = eval(reg_str);
            str = str.replace(reg,"");
            return str;
        },
        rtrim:function(str,r){
            var reg_str = "/(\\"+r+"+$)/g"
            var reg = eval(reg_str);
            str = str.replace(reg,"");
            return str;
        },
        strim: function (str) {
            var reg_str = "/ /g"
            var reg = eval(reg_str);
            str = str.replace(reg, "");
            return str;
        },
        contains : function(str,substr){
            if(str){
                return str.indexOf(substr) >= 0;
            }
            return false;
        },
        format_size : function(bytes ,is_unit,fixed, end_unit) //kb转换，到指定单位结束 is_unit：是否显示单位  fixed：小数点位置 end_unit：结束单位
        {
            if (bytes == undefined) return 0;

            if(is_unit==undefined) is_unit = true;
            if(fixed==undefined) fixed = 2;
            if (end_unit == undefined) end_unit = '';

            if(typeof bytes == 'string') bytes = parseInt(bytes);
            var unit = ['KB',' MB',' GB','TB'];
            var c = 1024;
            for(var i=0;i<unit.length;i++){
                var cUnit = unit[i];
                if(end_unit)
                {
                    if(cUnit.trim() == end_unit.trim())
                    {
                        var val = i == 0 ? bytes : fixed==0? bytes:bytes.toFixed(fixed)
                        if(is_unit){
                            return  val + cUnit;
                        }
                        else{
                            val = parseFloat(val);
                            return val;
                        }
                    }
                }
                else{
                    if(bytes < c){
                        var val = i == 0 ? bytes : fixed==0? bytes:bytes.toFixed(fixed)
                        if(is_unit){
                            return  val + cUnit;
                        }
                        else{
                            val = parseFloat(val);
                            return val;
                        }
                    }
                }

                bytes /= c;
            }
        },
        format_data : function(tm,format)
        {
            if(format==undefined) format = "yyyy/MM/dd hh:mm:ss";
            tm  = tm.toString();
            if(tm.length > 10){
                tm = tm.substring(0,10);
            }
            var data = new Date(parseInt(tm) * 1000);
            var o = {
                "M+" : data.getMonth()+1, //month
                "d+" : data.getDate(),    //day
                "h+" : data.getHours(),   //hour
                "m+" : data.getMinutes(), //minute
                "s+" : data.getSeconds(), //second
                "q+" : Math.floor((data.getMonth()+3)/3),  //quarter
                "S" : data.getMilliseconds() //millisecond
            }
            if(/(y+)/.test(format)) format=format.replace(RegExp.$1,
                (data.getFullYear()+"").substr(4 - RegExp.$1.length));
            for(var k in o)if(new RegExp("("+ k +")").test(format))
                format = format.replace(RegExp.$1,
                    RegExp.$1.length==1 ? o[k] : ("00"+ o[k]).substr((""+ o[k]).length));

            return format;
        },
        format_path:function(path){
            var reg = /(\\)/g;
            path = path.replace(reg,'/');
            return path;
        },
        get_random : function(len)
        {
            len = len || 32;
            var $chars = 'AaBbCcDdEeFfGHhiJjKkLMmNnPpRSrTsWtXwYxZyz2345678'; // 默认去掉了容易混淆的字符oOLl,9gq,Vv,Uu,I1
            var maxPos = $chars.length;
            var pwd = '';
            for (i = 0; i < len; i++) {
                pwd += $chars.charAt(Math.floor(Math.random() * maxPos));
            }
            return pwd;
        },
        refresh_pwd : function(length,obj)
        {
            if(obj==undefined) obj = 'MyPassword';
            var _input = $("#"+obj);
            if(_input.length>0){
                _input.val(bt.get_random(length))
            }
            else{
                $("."+obj).val(bt.get_random(length))
            }
        },
        get_random_num : function(min,max) //生成随机数
        {
            var range = max - min;
            var rand = Math.random();
            var num = min + Math.round(rand * range); //四舍五入
            return num;
        },
        set_cookie : function(key,val)
        {
            var Days = 30;
            var exp = new Date();
            exp.setTime(exp.getTime() + Days*24*60*60*1000);
            document.cookie = key + "="+ escape (val) + ";expires=" + exp.toGMTString();
        },
        get_cookie : function(key)
        {
            var arr,reg=new RegExp("(^| )"+key+"=([^;]*)(;|$)");
            if(arr=document.cookie.match(reg))
            {
                var val = unescape(arr[2]);
                return val== 'undefined'?'':val;
            }
            else{
                return null;
            }
        }

    };

 cloud.control = {
    format_option:function(obj,type){
        option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'cross'
                },
                formatter: obj.formatter
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: obj.tData,
                axisLine:{
                    lineStyle:{
                        color:"#666"
                    }
                }
            },
            yAxis: {
                type: 'value',
                name: obj.unit,
                boundaryGap: [0, '100%'],
                min:0,
                splitLine:{
                    lineStyle:{
                        color:"#ddd"
                    }
                },
                axisLine:{
                    lineStyle:{
                        color:"#666"
                    }
                }
            },
            dataZoom: [{
                type: 'inside',
                start: 0,
                zoomLock:true
            }, {
                start: 0,
                handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                handleSize: '80%',
                handleStyle: {
                    color: '#fff',
                    shadowBlur: 3,
                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                    shadowOffsetX: 2,
                    shadowOffsetY: 2
                }
            }],
            series: []
        };
        if(obj.legend) option.legend = obj.legend;
        if(obj.dataZoom) option.dataZoom = obj.dataZoom;

        for (var i=0;i<obj.list.length;i++)
        {
            var item = obj.list[i];
            series = {
                name : item.name,
                type : item.type?item.type:'line',
                smooth : item.smooth ? item.smooth : true,
                symbol : item.symbol ? item.symbol : 'none',
                showSymbol:item.showSymbol?item.showSymbol:false,
                sampling : item.sampling ? item.sampling : 'average',
                areaStyle : item.areaStyle ? item.areaStyle : {},
                lineStyle : item.lineStyle ? item.lineStyle : {},
                itemStyle : item.itemStyle ? item.itemStyle : { normal:{ color: 'rgb(0, 153, 238)'}},
                symbolSize:6,
                symbol: 'circle',
                data :  item.data
            }
            option.series.push(series);
        }
        return option;
    }
};
function RandomNum(Min, Max) {
    var Range = Max - Min;
    var Rand = Math.random();
    var num = Min + Math.floor(Rand * Range);  //舍去
    return num;
}
var interval_stop = false;
var index = {
    vmid:0,
    interval: {
        limit: 10,
        count: 0,
        task_id: 0,
        start: function () {
            var _this = this;
            _this.count = 0;
            _this.task_id = setInterval(function () {
                if (_this.count >= _this.limit) {
                    _this.reload();
                    return;
                }
                _this.count++;
                if (!interval_stop) index.get_data_info();
            }, 3000)
        },
        reload: function () {
            var _this = this;
            if (_this) clearInterval(_this.task_id);
            _this.start();
        }
    },
    get_data_info:function(){
        var vmid =index.vmid
        $.post('/clientarea.php?action=productdetails&getChart&id='+vmid,{vmid:vmid},function(data){
           // data=data.data;
            index.net.flush(data);
            index.cpu.flush(data.CpuStats);
            index.memory.flush(data.MemoryStats);
            if(data.vol==undefined){
                data.vol=0;
            }
           // $('#usedData').html(data.vol+"GB");
         
        },'json')
         
    },
    net: {
        table: null,
        data: {
            uData: [],
            dData: [],
            aData: []
        },
        init: function () {
            //流量图表

            index.net.table = echarts.init(document.getElementById('NetImg'));
            var obj = {};
            obj.dataZoom = [];
            obj.unit = '单位:KB/s';
            obj.tData = index.net.data.aData;
//rgba(255, 140, 0,0.5)
            obj.list = [];
            obj.list.push({ name: '上行', data: index.net.data.uData, circle: 'circle', itemStyle: { normal: { color: '#52a9ff' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#52a9ff' }, { offset: 1, color: '#52a9ff' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
            obj.list.push({ name: '下行', data: index.net.data.dData, circle: 'circle', itemStyle: { normal: { color: '#89d8af' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: '#89d8af' }, { offset: 1, color: '#89d8af' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
            option = cloud.control.format_option(obj)
            index.net.table.setOption(option);
            window.addEventListener("resize", function () {
                index.net.table.resize();
            });
        },
        add: function (up, down) {
            var _net = this;
            var limit = 8;
            var d = new Date()

            if (_net.data.uData.length >= limit) _net.data.uData.splice(0, 1);
            if (_net.data.dData.length >= limit) _net.data.dData.splice(0, 1);
            if (_net.data.aData.length >= limit) _net.data.aData.splice(0, 1);

            _net.data.uData.push(up);
            _net.data.dData.push(down);
            _net.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
        },
        flush:function (net_data){
            //$("#upSpeed").html(net_data.up + ' KB');
            //$("#downSpeed").html(net_data.down + ' KB');
            var networkStats = net_data.NetworkStats;
            var traffic = net_data.Traffic;
            $("#trafficin").html((traffic.TrafficIn)+"MB");
            $("#trafficout").html((traffic.TrafficOut)+"MB");
            index.net.add(networkStats.BytesSentPersec, networkStats.BytesReceivedPersec);
            if (index.net.table) index.net.table.setOption({ xAxis: { data: index.net.data.aData }, series: [{ name: '上行', data: index.net.data.uData }, { name: '下行', data: index.net.data.dData }] });
        }

    },
    cpu: {
        table: null,
        data: {
            data: [],
            aData: []
        },
        init: function () {
            //cpu图表

            index.cpu.table = echarts.init(document.getElementById('CPU'));
            var obj = {};
            obj.dataZoom = [];
            obj.unit = '单位:%';
            obj.tData = index.cpu.data.aData;

            obj.list = [];
            obj.list.push({ name: 'cpu', data: index.cpu.data.data, circle: 'circle', itemStyle: { normal: { color: '#52a9ff' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(30, 144, 255,0.5)' }, { offset: 1, color: 'rgba(30, 144, 255,0.8)' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
            option = cloud.control.format_option(obj)
            index.cpu.table.setOption(option);
            window.addEventListener("resize", function () {
                index.cpu.table.resize();
            });
        },
        add: function (cpu_data) {
            var _cpu = this;
            var limit = 8;
            var d = new Date()

            if (_cpu.data.data.length >= limit) _cpu.data.data.splice(0, 1);
            if (_cpu.data.aData.length >= limit) _cpu.data.aData.splice(0, 1);

            _cpu.data.data.push(cpu_data);
            _cpu.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
        },
        flush:function (cpu_data){
            index.cpu.add(cpu_data);
            if (index.cpu.table) index.cpu.table.setOption({ xAxis: { data: index.cpu.data.aData }, series: { name: 'cpu', data: index.cpu.data.data }});
        }

    },
    memory: {
        table: null,
        data: {
            data: [],
            aData: []
        },
        init: function () {
            //memory图表
            index.memory.table = echarts.init(document.getElementById('memory'));
            var obj = {};
            obj.dataZoom = [];
            obj.unit = '单位:%';
            obj.tData = index.memory.data.aData;

            obj.list = [];
            obj.list.push({ name: '内存', data: index.memory.data.data, circle: 'circle', itemStyle: { normal: { color: '#52a9ff' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(30, 144, 255,0.5)' }, { offset: 1, color: 'rgba(30, 144, 255,0.8)' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
            option = cloud.control.format_option(obj)
            index.memory.table.setOption(option);
            window.addEventListener("resize", function () {
                index.memory.table.resize();
            });
        },
        add: function (memory_data) {
            var _memory = this;
            var limit = 8;
            var d = new Date()

            if (_memory.data.data.length >= limit) _memory.data.data.splice(0, 1);
            if (_memory.data.aData.length >= limit) _memory.data.aData.splice(0, 1);

            _memory.data.data.push(memory_data);
            _memory.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
        },
        flush:function (memory_data){
            index.memory.add(memory_data);
            if (index.memory.table) index.memory.table.setOption({ xAxis: { data: index.memory.data.aData }, series: { name: '内存', data: index.memory.data.data }});
        }

    },
   
    io: {
        table: null,
        data: {
            data: [],
            aData: []
        },
        init: function () {
            //IO图表

            index.io.table = echarts.init(document.getElementById('IO'));
            var obj = {};
            obj.dataZoom = [];
            obj.unit = '单位:%';
            obj.tData = index.io.data.aData;

            obj.list = [];
            obj.list.push({ name: 'IO', data: index.io.data.data, circle: 'circle', itemStyle: { normal: { color: '#52a9ff' } }, areaStyle: { normal: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(30, 144, 255,0.5)' }, { offset: 1, color: 'rgba(30, 144, 255,0.8)' }], false) } }, lineStyle: { normal: { width: 1, color: '#aaa' } } });
            option = cloud.control.format_option(obj)
            index.io.table.setOption(option);
            window.addEventListener("resize", function () {
                index.io.table.resize();
            });
        },
        add: function (io_data) {
            var _io = this;
            var limit = 8;
            var d = new Date()

            if (_io.data.data.length >= limit) _io.data.data.splice(0, 1);
            if (_io.data.aData.length >= limit) _io.data.aData.splice(0, 1);

            _io.data.data.push(io_data);
            _io.data.aData.push(d.getHours() + ':' + d.getMinutes() + ':' + d.getSeconds());
        },
        flush:function (io_data){
            index.io.add(io_data);
            if (index.io.table) index.io.table.setOption({ xAxis: { data: index.io.data.aData }, series: { name: 'IO', data: index.io.data.data }});
        }

    }
}
