<?php

function qzvps_MetaData()
{
	return ["DisplayName" => "轻舟VPS模块", "APIVersion" => "1.0.0", "HelpDoc" => "http://www.7i24.com/"];
}
function qzvps_ConfigOptions()
{
	return [
		["type" => "text", "name" => "线路ID", "description" => "线路ID", "key" => "line_id"],
		["type" => "text", "name" => "节点ID", "description" => "节点ID", "key" => "nodes_id"],
		["type" => "text", "name" => "核心数", "description" => "核心数", "key" => "cpu_default"],
		["type" => "text", "name" => "内存", "description" => "内存", "key" => "memory_default"],
		["type" => "text", "name" => "硬盘", "description" => "硬盘", "key" => "disk_default"],
		["type" => "text", "name" => "带宽", "description" => "带宽", "key" => "band_width_default"],
		["type" => "text", "name" => "IP数量", "description" => "ip数量,填-1代表是nat,", "key" => "ipnum"],
		[
			'type'=>'yesno', 
			'name'=>'开启嵌套虚拟化', 
			'description'=>'勾选则表示开启嵌套虚拟化', 
			'default'=>'0',
			'key'=>'metal',
		],
		[
			'type'=>'yesno', 
			'name'=>'开启显卡', 
			'description'=>'勾选则表示显卡云', 
			'default'=>'0',
			'key'=>'open_gpu',
		],
		[
			'type'=>'text', 
			'name'=>'显卡序号', 
			'description'=>'可为空', 
			'default'=>'1',
			'key'=>'mdevid',
		],
	];
}

function qzvps_TestLink($params)
{
	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}
	$md5 = md5($params["accesshash"] . "7i24.com");
	$api_url = $secure . $params["server_host"] . "/api/cloudapi.asp";
	$data = ["action" => "getinfo", "userstr" => $md5];
	$post_data = http_build_query($data);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $api_url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	$api_data = curl_exec($ch);
	curl_close($ch);
	if ($api_data == "ret=err") {
		$result["status"] = 200;
		$result["data"]["server_status"] = 1;
	} else {
		$result["status"] = 200;
		$result["data"]["server_status"] = 0;
		$result["data"]["msg"] = $res["message"];
	}
	return $result;
}
function qzvps_CreateAccount($params)
{

	if (empty($params["password"])) {
		$sys_pwd = randStr(8);
	} else {
		$sys_pwd = $params["password"];
	}
	$expire_time = date("Y-m-d H:i:s", $params['nextduedate']);;

	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}

	$md5 = md5($params["accesshash"] . "7i24.com");
	$api_url = $secure . $params["server_host"] . "/api/whmcs/create_host";
	// $data = ["action" => "activate", "userstr" => $md5, "idc" => $params["configoptions"]["idc"], "productid" => $params["configoptions"]["pid"], "userid" => $vos, "vpsname" => $params["domain"], "VPSpassword" => $sys_pwd, "year" => $cycle];
	$headers = ["apikey: " . $params["accesshash"]];
	$ipnum = 1;
	if ($params["configoptions"]["ipnum"] == -1) {
		$ipnum = 0;
	}
	if (isset($params["configoptions"]["ipnum"]) && $params["configoptions"]["ipnum"] > 0) {
		$ipnum = $params["configoptions"]["ipnum"];
	}
	$cpu = $params["configoptions"]["cpu_default"];

	if ($params["configoptions"]["cpu"]) {
		$cpu = $params["configoptions"]["cpu"];
	}

	$memory = $params["configoptions"]["memory_default"];
	if ($params["configoptions"]["mem"]) {
		$memory = $params["configoptions"]["mem"];
	}
	
	
	$metal = isset($params["configoptions"]["metal"])?$params["configoptions"]["metal"]:0;
 
	$bandwidth = $params["configoptions"]["band_width_default"];
	if ($params["configoptions"]["band"]) {
		$bandwidth = $params["configoptions"]["band"];
	}

	$disk = $params["configoptions"]["disk_default"];
	if (isset($params["configoptions"]["disk"])) {
		$disk = $params["configoptions"]["disk"];
	}

	$data = [
		"line_id" => $params["configoptions"]["line_id"],
		"nodes_id" => $params["configoptions"]["nodes_id"],
		"cpu" => $cpu,
		"memory" => $memory,
		"hard_disks" => $disk,
		"bandwidth" => $bandwidth,
		"os" => $params["configoptions"]["os"],
		"host_name" => $params["domain"],
		"expire_time" => $expire_time,
		"sys_pwd" => $sys_pwd,
		"ipnum" => $ipnum,
		"vnc_pwd" => $sys_pwd,
		"metal"=>($metal==1?2:0),
	];

	if (isset($params["configoptions"]["snapshot"]) && $params["configoptions"]["snapshot"]) {
		$data['snapshot'] = $params["configoptions"]["snapshot"];
	}

	if (isset($params["configoptions"]["backup"]) && $params["configoptions"]["backup"]) {
		$data['backups'] = $params["configoptions"]["backup"];
	}

	if (isset($params["configoptions"]["port"]) && $params["configoptions"]["port"]) {
		$data['port_num'] = $params["configoptions"]["port"];
	}
	
	if (isset($params["configoptions"]["open_gpu"]) && $params["configoptions"]["open_gpu"]) {
		$data['open_gpu'] = $params["configoptions"]["open_gpu"];
	}

	$api_data = qzvps_Curl($api_url, $data, $headers);
	
	$notes = "";

	if (isset($api_data['code']) && $api_data['code'] == 1 && isset($api_data['data'])) {
		$ip = $api_data['data']['ip'];
		// 存入产品自定义字段
		$customid = Db::name('customfields')
			->where('type', 'product')
			->where('relid', $params['productid'])
			->where('fieldname', 'vserverid')
			->value('id');
		if (empty($customid)) {
			// 添加自定义字段
			$customfields = [
				'type' => 'product',
				'relid' => $params['productid'],
				'fieldname' => 'vserverid',
				'fieldtype' => 'text',
				'adminonly' => 1,
				'create_time' => time()
			];
			$customid = Db::name('customfields')->insertGetId($customfields);
		}
		$exist = Db::name('customfieldsvalues')
			->where('fieldid', $customid)
			->where('relid', $params['hostid'])
			->find();
		if (empty($exist)) {
			$data = [
				'fieldid' => $customid,
				'relid' => $params['hostid'],
				'value' => $api_data['data']['host_id'],
				'create_time' => time()
			];
			Db::name('customfieldsvalues')->insert($data);
		} else {
			Db::name('customfieldsvalues')->where('id', $exist['id'])->update(['value' => $api_data['data']['host_id']]);
		}
	}

	if (isset($api_data['code']) && $api_data['code'] != 1) {
		return ['status' => 500, 'message' => 'CURL ERROR:' . $api_data['msg']];
	}
	if ($api_data == null) {
		return ['status' => 500, 'message' => '响应错误'];
	}

	$update["domainstatus"] = "Active";
	$update["username"] = 'root/administrator';
	$update["dedicatedip"] = $ip;
	$update["password"] = cmf_encrypt($sys_pwd);
	$update['domain'] = $params["domain"];

	Db::name("host")->where("id", $params["hostid"])->update($update);
	return ['status' => 'success'];
}

/**
 * 续费
 */
function qzvps_Renew($params)
{
	$host = qzvps_GetServerid($params);
	$nextduedate = date("Y-m-d H:i:s", $params['nextduedate']);

	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}

	$api_url = $secure . $params["server_host"] . "/api/whmcs/renew";
	$headers = ["apikey: " . $params["accesshash"]];

	$data = [
		'host_id' => $host,
		'nextduedate' => $nextduedate,
	];

	$api_data = qzvps_Curl($api_url, $data, $headers);
}

// 获取自定义字段value
function qzvps_GetServerid($params){
	return (int)$params['customfields']['vserverid'];
}

function qzvps_Operation($params, $operation)
{
	$host = qzvps_GetServerid($params);

	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}

	$api_url = $secure . $params["server_host"] . "/api/whmcs/" . $operation;
	$headers = ["apikey: " . $params["accesshash"]];

	$data = [
		'host_id' => $host,
	];

	$api_data = qzvps_Curl($api_url, $data, $headers);
}

/**
 * 暂停（锁定）
 */
function qzvps_SuspendAccount($params)
{
	$operation = 'lock';
	return qzvps_Operation($params, $operation);
}

/**
 * 取消暂停（取消锁定）
 */
function qzvps_UnsuspendAccount($params)
{
	$operation = 'unlock';
	return qzvps_Operation($params, $operation);
}

/**
 * 删除
 */
function qzvps_TerminateAccount($params)
{
	$operation = 'delete';
	return qzvps_Operation($params, $operation);
}

// 开机
function qzvps_On($params)
{
	$operation = 'start';
	return qzvps_Operation($params, $operation);
}

// 关机
function qzvps_Off($params)
{
	$operation = 'shutdown';
	return qzvps_Operation($params, $operation);
}

//重启
function qzvps_Reboot($params)
{
	$operation = 'reboot';
	return qzvps_Operation($params, $operation);
}

// 重装系统
function qzvps_Reinstall($params)
{
	$host = qzvps_GetServerid($params);

	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}

	$api_url = $secure . $params["server_host"] . "/api/whmcs/reset_os";
	$headers = ["apikey: " . $params["accesshash"]];
    //$passwd = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$$$!!!@@@";
	$data = [
		'host_id' => $host,
		'template_id' => $params['reinstall_os'],
		'password' => $params['password'],
	];
 
	$api_data = qzvps_Curl($api_url, $data, $headers);
	return ['status' => 'success', 'msg' => "重装成功"];
}

function qzvps_ChangePackage($params)
{
	return ['status' => 500, 'message' => '产品暂不支持升降级'];
}



function qzvps_ClientArea($params)
{

	return ["info" => ["name" => "产品信息"]];
}
function qzvps_ClientAreaOutput($params, $key)
{
	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}
	
	if ($params["secure"]) {
		$secure = "https://";
	} else {
		$secure = "http://";
	}
    $hostid = $params['customfields']['vserverid'];
	$api_url = $secure . $params["server_host"] . "/api/whmcs/hostinfo";
	$headers = ["apikey: " . $params["accesshash"]];

	$data = [
		'host_id' => $hostid,
	];

	$api_data = qzvps_Curl($api_url, $data, $headers);
	
	$pnel_password = "";
   if (isset($api_data['data'])) {
        $panel_password = $api_data['data']['panel_password'];
   }
   
   $login_url = $secure . $params["server_host"] . "/control/ecs/login.html?host_name=" . $params["domain"] . "&panel_password=" . $panel_password;
   $update["password"] = cmf_encrypt($api_data['data']['os_password']);

	Db::name("host")->where("id", $params["hostid"])->update($update);
	
	if ($key == "info") {
		return ["template" => "templates/info.html", "vars" => ["login_url" => $login_url, "panel_url" => $panel, "ip" => $params["dedicatedip"], "root" => $root, "domain" => $params["domain"], "password" => $api_data['data']['os_password'],'remote_ip'=>$api_data['data']['remote_ip'],"is_nat"=>$api_data['data']['is_nat'],'os_password'=>$api_data['data']['os_password']]];
	}
}


function qzvps_Curl($url = '', $data = [], $header = [], $request = 'POST', $timeout = 30)
{
	$curl = curl_init();
	if ($request == 'GET') {
		$s = '';
		if (!empty($data)) {
			foreach ($data as $k => $v) {
				$s .= $k . '=' . urlencode($v) . '&';
			}
		}
		if ($s) {
			$s = '?' . trim($s, '&');
		}
		curl_setopt($curl, CURLOPT_URL, $url . $s);
	} else {
		curl_setopt($curl, CURLOPT_URL, $url);
	}
	curl_setopt($curl, CURLOPT_TIMEOUT, $timeout);
	curl_setopt($curl, CURLOPT_USERAGENT, 'WHMCS');
	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($curl, CURLOPT_HEADER, 0);
	//curl_setopt($curl, CURLOPT_COOKIESESSION, 1);
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
	if (strtoupper($request) == 'GET') {
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_HTTPGET, 1);
	}
	if (strtoupper($request) == 'POST') {
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_POST, 1);
		if (is_array($data)) {
			curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
		} else {
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
	}
	if (strtoupper($request) == 'PUT' || strtoupper($request) == 'DELETE') {
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_CUSTOMREQUEST, strtoupper($request));
		if (is_array($data)) {
			curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
		} else {
			curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		}
	}
	if (!empty($header)) {
		curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
	}
	$res = curl_exec($curl);
	$error = curl_error($curl);
	if (!empty($error)) {
		return ['status' => 500, 'message' => 'CURL ERROR:' . $error];
	}
	$info = curl_getinfo($curl);
	curl_close($curl);
	return json_decode($res, true);
}